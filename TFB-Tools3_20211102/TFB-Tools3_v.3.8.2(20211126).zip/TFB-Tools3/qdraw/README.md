QDRAW

The purpose of this plugin is to make drawing easier in QGis.
It adds new tools to draw simple shapes that will be added to the Map Registry as memory layers.
