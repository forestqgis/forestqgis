# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\RCHSS_GIS\Desktop\Q_Plugins\TFB-Tools\gpx2shp_dia.ui'
#
# Created: Mon May 14 18:12:44 2018
#      by: PyQt4 UI code generator 4.10.2
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog_7(object):
    def setupUi(self, Dialog_7):
        Dialog_7.setObjectName(_fromUtf8("Dialog_7"))
        Dialog_7.resize(391, 372)
        self.pushButton = QtGui.QPushButton(Dialog_7)
        self.pushButton.setGeometry(QtCore.QRect(140, 320, 91, 35))
        self.pushButton.setObjectName(_fromUtf8("pushButton"))
        self.groupBox_4 = QtGui.QGroupBox(Dialog_7)
        self.groupBox_4.setGeometry(QtCore.QRect(10, 20, 361, 181))
        self.groupBox_4.setObjectName(_fromUtf8("groupBox_4"))
        self.groupBox_3 = QtGui.QGroupBox(self.groupBox_4)
        self.groupBox_3.setGeometry(QtCore.QRect(10, 60, 331, 101))
        self.groupBox_3.setObjectName(_fromUtf8("groupBox_3"))
        self.radioButton_5 = QtGui.QRadioButton(self.groupBox_3)
        self.radioButton_5.setGeometry(QtCore.QRect(100, 60, 81, 20))
        self.radioButton_5.setObjectName(_fromUtf8("radioButton_5"))
        self.radioButton_4 = QtGui.QRadioButton(self.groupBox_3)
        self.radioButton_4.setGeometry(QtCore.QRect(20, 60, 81, 20))
        self.radioButton_4.setChecked(False)
        self.radioButton_4.setObjectName(_fromUtf8("radioButton_4"))
        self.radioButton_3 = QtGui.QRadioButton(self.groupBox_3)
        self.radioButton_3.setGeometry(QtCore.QRect(190, 30, 81, 20))
        self.radioButton_3.setObjectName(_fromUtf8("radioButton_3"))
        self.radioButton_2 = QtGui.QRadioButton(self.groupBox_3)
        self.radioButton_2.setGeometry(QtCore.QRect(100, 30, 81, 20))
        self.radioButton_2.setObjectName(_fromUtf8("radioButton_2"))
        self.radioButton = QtGui.QRadioButton(self.groupBox_3)
        self.radioButton.setGeometry(QtCore.QRect(20, 30, 81, 20))
        self.radioButton.setChecked(True)
        self.radioButton.setObjectName(_fromUtf8("radioButton"))
        self.label = QtGui.QLabel(self.groupBox_4)
        self.label.setGeometry(QtCore.QRect(10, 20, 71, 21))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Times New Roman"))
        font.setPointSize(9)
        self.label.setFont(font)
        self.label.setObjectName(_fromUtf8("label"))
        self.lineEdit = QtGui.QLineEdit(self.groupBox_4)
        self.lineEdit.setEnabled(False)
        self.lineEdit.setGeometry(QtCore.QRect(90, 20, 221, 25))
        self.lineEdit.setObjectName(_fromUtf8("lineEdit"))
        self.toolButton = QtGui.QToolButton(self.groupBox_4)
        self.toolButton.setGeometry(QtCore.QRect(320, 20, 25, 25))
        self.toolButton.setObjectName(_fromUtf8("toolButton"))
        self.groupBox_5 = QtGui.QGroupBox(Dialog_7)
        self.groupBox_5.setGeometry(QtCore.QRect(10, 210, 361, 101))
        self.groupBox_5.setObjectName(_fromUtf8("groupBox_5"))
        self.comboBox = QtGui.QComboBox(self.groupBox_5)
        self.comboBox.setGeometry(QtCore.QRect(160, 60, 131, 25))
        self.comboBox.setObjectName(_fromUtf8("comboBox"))
        self.comboBox.addItem(_fromUtf8(""))
        self.comboBox.addItem(_fromUtf8(""))
        self.label_3 = QtGui.QLabel(self.groupBox_5)
        self.label_3.setGeometry(QtCore.QRect(20, 60, 131, 21))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Times New Roman"))
        font.setPointSize(9)
        self.label_3.setFont(font)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.label_2 = QtGui.QLabel(self.groupBox_5)
        self.label_2.setGeometry(QtCore.QRect(20, 20, 71, 21))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Times New Roman"))
        font.setPointSize(9)
        self.label_2.setFont(font)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.lineEdit_2 = QtGui.QLineEdit(self.groupBox_5)
        self.lineEdit_2.setEnabled(False)
        self.lineEdit_2.setGeometry(QtCore.QRect(100, 20, 221, 25))
        self.lineEdit_2.setObjectName(_fromUtf8("lineEdit_2"))
        self.toolButton_2 = QtGui.QToolButton(self.groupBox_5)
        self.toolButton_2.setGeometry(QtCore.QRect(330, 20, 25, 25))
        self.toolButton_2.setObjectName(_fromUtf8("toolButton_2"))

        self.retranslateUi(Dialog_7)
        QtCore.QMetaObject.connectSlotsByName(Dialog_7)

    def retranslateUi(self, Dialog_7):
        Dialog_7.setWindowTitle(_translate("Dialog_7", "GPX to shapefile", None))
        self.pushButton.setText(_translate("Dialog_7", "開始轉換", None))
        self.groupBox_4.setTitle(_translate("Dialog_7", "輸入", None))
        self.groupBox_3.setTitle(_translate("Dialog_7", "請選擇要增加的向量類型", None))
        self.radioButton_5.setText(_translate("Dialog_7", "track", None))
        self.radioButton_4.setText(_translate("Dialog_7", "route", None))
        self.radioButton_3.setText(_translate("Dialog_7", "track_point", None))
        self.radioButton_2.setText(_translate("Dialog_7", "route_point", None))
        self.radioButton.setText(_translate("Dialog_7", "waypoint", None))
        self.label.setText(_translate("Dialog_7", "輸入GPX", None))
        self.toolButton.setText(_translate("Dialog_7", "...", None))
        self.groupBox_5.setTitle(_translate("Dialog_7", "輸出", None))
        self.comboBox.setItemText(0, _translate("Dialog_7", "WGS 84", None))
        self.comboBox.setItemText(1, _translate("Dialog_7", "TWD 97", None))
        self.label_3.setText(_translate("Dialog_7", "請選擇輸出檔案坐標系統", None))
        self.label_2.setText(_translate("Dialog_7", "輸出SHP", None))
        self.toolButton_2.setText(_translate("Dialog_7", "...", None))

