# -*- coding: utf-8 -*-

"""
/***************************************************************************
 TFB_Tool
                                 A QGIS plugin
 Initializer of the plugin.
                             -------------------
        begin                : 2017-11-30
        author               : kuma
        email                : kumahl@gmail.com
 ***************************************************************************/
/***************************************************************************
 *       
 *   This plugin is free softwart,                                                                   *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 3 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""


from PyQt4.QtCore import *
from PyQt4.QtGui import *
from PyQt4 import QtCore, QtGui
from qgis.core import *
from qgis.gui import *

#import TFB-Tools
TFB_Tools = __import__('TFB-Tools')

import getpass
import urllib
import urllib2
from xml.dom.minidom import *
from xml.dom import minidom
import json

import codecs
import io
import os
import os.path
import sys 
import base64
import csv
import glob
from osgeo import ogr
from osgeo import osr, gdal
from gdalconst import *
from PyQt4 import uic


import DataOperationGUI
import getImg

########################################################
#                                                      #
# global var:                                          #
#                                                      #
# rootPath: the path of your computer's root path      #
# dataPath: the path of gis data                       #
# filePathList: recode DefaultFilePath.csv             #
#                                                      #
########################################################

rootPath = 'C:\\Users\\' + getpass.getuser() + '\\.qgis2\\python\\plugins\\TFB-Tools\\'
dataPath = ''
filePathList = []




class DataOperationPlugin: 

  def __init__(self, iface):

    ########################################################
    #                                                      #
    # save reference to the QGIS interface                 #
    #                                                      #
    ########################################################    
    self.iface = iface
    self.canvas = iface.mapCanvas()


    ########################################################
    #                                                      #
    # define dialog from DataOperationGUI.py               #
    #                                                      #
    ######################################################## 

    self.mainDia = DataOperationGUI.mainGUI(self.iface)    

    #self.main_mainWindow= DataOperationGUI.main_mainWindowGUI(self.iface)    
    
    self.positioningDia = DataOperationGUI.positioningGUI(self.iface)
    self.csv2shpDia = DataOperationGUI.csv2shpGUI(self.iface)
    self.cadastreDia = DataOperationGUI.cadastreGUI(self.iface)
    self.WMTSDia = DataOperationGUI.WMTSGUI(self.iface)
    self.gpx2shpDia = DataOperationGUI.gpx2shpGUI(self.iface)
    self.exportSHPDia = DataOperationGUI.exportSHPGUI(self.iface)
    self.wmsDia = DataOperationGUI.wmsGUI(self.iface)
    self.addWMTSDia = DataOperationGUI.addWMTSGUI(self.iface)
    self.inforDia = DataOperationGUI.inforGUI(self.iface)    
    #self.msgBox_cadastreDia = DataOperationGUI.msgBox_cadastreGUI(self.iface)

    #self.dockDia = DataOperationGUI.dockGUI(self.iface)    
    '''
    filePath = rootPath + 'version.csv' 
    filePathfile = open(filePath, 'r')   
    csvCursor = csv.reader(filePathfile)
    version = []
    for row in csvCursor:
        version.append(row)
    title = "林務局圖資操作工具" + version[0][1]
    self.mainDia.setWindowTitle(title.decode('utf-8'))
    '''
    qApp.setStyleSheet("QMessageBox { messagebox-text-interaction-flags: 5; }");
    mainTitle = '林務局圖資操作工具' + TFB_Tools.version()
    self.mainDia.setWindowTitle(mainTitle.decode('utf-8'))

    self.getImg = getImg.getImgFromFrame(self.iface)





    #reload(sys)
    #sys.setdefaultencoding('utf8')
    
  def initGui(self):
    # create action that will start plugin configuration
    self.action = QAction(u'圖資操作工具', self.iface.mainWindow())
    #self.action = QAction(_translate("", u'圖資操作工具'.decode('utf-8'), None), self.iface.mainWindow())
        
    self.action.setWhatsThis(TFB_Tools.description())
    self.action.setStatusTip(TFB_Tools.name())
    self.iface.addPluginToMenu(TFB_Tools.description(), self.action) 
    #self.action.setWhatsThis("TFB_Tool_v1.31_plugin")
    #self.action.setStatusTip("TFB_Tool_v1.31")
    self.iface.addToolBarIcon(self.action)
    #self.iface.addPluginToMenu("&TFB_Tool_v1.31_plugin", self.action) 

    filePath = rootPath + 'DefaultFilePath.csv' 
    filePathfile = open(filePath, 'r')   
    csvCursor = csv.reader(filePathfile)
    filePathList = []
    for row in csvCursor:
        filePathList.append(row)

    self.mainDia.lineEdit.setText(filePathList[0][1].decode('utf-8'))



    QObject.connect(self.action, SIGNAL("activated()"), self.start)

    ########################################################
    #                                                      #
    # define action of main dialog                         #
    #                                                      #
    ######################################################## 

    QObject.connect(self.mainDia.pushButton, SIGNAL("clicked()"), self.load_25000)
    QObject.connect(self.mainDia.pushButton_2, SIGNAL("clicked()"), self.load_5000)


    QObject.connect(self.mainDia.pushButton_3, SIGNAL("clicked()"), self.wms_show)    
    QObject.connect(self.mainDia.pushButton_4, SIGNAL("clicked()"), self.csv2shp_show)
    QObject.connect(self.mainDia.pushButton_5, SIGNAL("clicked()"), self.gpx2shp_show)    
    QObject.connect(self.mainDia.pushButton_6, SIGNAL("clicked()"), self.exportSHP_show)    
    QObject.connect(self.mainDia.pushButton_7, SIGNAL("clicked()"), self.openQGS)
    QObject.connect(self.mainDia.pushButton_8, SIGNAL("clicked()"), self.openWMTSDia)
    QObject.connect(self.mainDia.pushButton_9, SIGNAL("clicked()"), self.desideDataPath)
    QObject.connect(self.mainDia.pushButton_10, SIGNAL("clicked()"), self.positioning_lyr)
    QObject.connect(self.mainDia.pushButton_11, SIGNAL("clicked()"), self.cadastre_show)    
    QObject.connect(self.mainDia.pushButton_12, SIGNAL("clicked()"), self.inforDia_show)    
    QObject.connect(self.mainDia.pushButton_13, SIGNAL("clicked()"), self.helpDia_show)        

    QObject.connect(self.inforDia.pushButton, SIGNAL("clicked()"), self.edit_filePath)
    QObject.connect(self.inforDia.pushButton_6, SIGNAL("clicked()"), self.edit_serverIP)
    QObject.connect(self.inforDia.pushButton_8, SIGNAL("clicked()"), self.edit_wmsAccount)
    QObject.connect(self.inforDia.pushButton_2, SIGNAL("clicked()"), self.save_filePath)
    QObject.connect(self.inforDia.pushButton_5, SIGNAL("clicked()"), self.save_serverIP)
    QObject.connect(self.inforDia.pushButton_7, SIGNAL("clicked()"), self.save_wmsAccount)
    #QObject.connect(self.inforDia.comboBox, SIGNAL("activated(int)"), self.reloadFilePath)    
            


    #QObject.connect(self.mainDia, SIGNAL("rejected()"), self.writeDefaultPath)    

    #地籍圖
    QObject.connect(self.cadastreDia.comboBox, SIGNAL("activated(int)"), self.countyToTown)
    QObject.connect(self.cadastreDia.comboBox_2, SIGNAL("activated(int)"), self.townToCadastre)
    QObject.connect(self.cadastreDia.comboBox_3, SIGNAL("activated(int)"), self.cadastreToNo)
    QObject.connect(self.cadastreDia.comboBox_4, SIGNAL("activated(int)"), self.changeCRS)
    QObject.connect(self.cadastreDia.comboBox_5, SIGNAL("activated(int)"), self.updateCadastreInfo)    
    QObject.connect(self.cadastreDia.pushButton, SIGNAL("clicked()"), self.loadWFS)
    #QObject.connect(self.cadastreDia.pushButton_4, SIGNAL("clicked()"), self.cadastrePosition)
    QObject.connect(self.cadastreDia.pushButton_4, SIGNAL("clicked()"), self.loadMultiCadastre)
    QObject.connect(self.cadastreDia.checkBox, SIGNAL("clicked()"), self.changeQueryMode)
    #QObject.connect(self.cadastreDia.checkBox_2, SIGNAL("clicked()"), self.loadMulti)
    QObject.connect(self.cadastreDia.pushButton_3, SIGNAL("clicked()"), self.loadWFS_XY_Position)
    QObject.connect(self.cadastreDia.pushButton_2, SIGNAL("clicked()"), self.copyForm)
    QObject.connect(self.cadastreDia.listWidget, SIGNAL("itemClicked(QListWidgetItem *)"), self.cadastreItemClicked)
    QObject.connect(self.cadastreDia.listWidget_2, SIGNAL("itemClicked(QListWidgetItem *)"), self.cadastreItemDel)
    QObject.connect(self.cadastreDia.pushButton_5, SIGNAL("clicked()"), self.addCadastreItem)
    QObject.connect(self.cadastreDia, SIGNAL("rejected()"), self.resetCadastreDia)


    QObject.connect(self.wmsDia.pushButton_2, SIGNAL("clicked()"), self.getID5000)
    QObject.connect(self.wmsDia.pushButton_3, SIGNAL("clicked()"), self.getWMSList)
    QObject.connect(self.wmsDia.pushButton, SIGNAL("clicked()"), self.addWMS)    
    QObject.connect(self.wmsDia.comboBox, SIGNAL("activated(int)"), self.wmsDia_comboBox_change)


    #QObject.connect(self.WMTSDia.pushButton, SIGNAL("clicked()"), self.loadWMTS)
    QObject.connect(self.WMTSDia.pushButton_2, SIGNAL("clicked()"), self.getWMTSList)
    QObject.connect(self.WMTSDia.pushButton_3, SIGNAL("clicked()"), self.addToList)
    QObject.connect(self.WMTSDia.pushButton_4, SIGNAL("clicked()"), self.loadWMTS_2)
    QObject.connect(self.WMTSDia.pushButton_6, SIGNAL("clicked()"), self.rmItem) 
    QObject.connect(self.WMTSDia.pushButton_8, SIGNAL("clicked()"), self.rmService)
    QObject.connect(self.WMTSDia.pushButton_7, SIGNAL("clicked()"), self.showaddWMTSDia)

    QObject.connect(self.addWMTSDia.pushButton, SIGNAL("clicked()"), self.addWMTSto)    
    
    #QObject.connect(self.WMTSDia.pushButton_5, SIGNAL("clicked()"), self.saveToWMTSList)
    QObject.connect(self.WMTSDia, SIGNAL("rejected()"), self.saveToWMTSList) 
    QObject.connect(self.WMTSDia.comboBox_2, SIGNAL("activated(int)"), self.WMTScls) 

    QObject.connect(self.gpx2shpDia.toolButton, SIGNAL("clicked()"), self.getGPXName)    
    QObject.connect(self.gpx2shpDia.toolButton_2, SIGNAL("clicked()"), self.getGPX2SHPName)
    QObject.connect(self.gpx2shpDia.pushButton, SIGNAL("clicked()"), self.gpx2shp)
  
    QObject.connect(self.csv2shpDia.toolButton, SIGNAL("clicked()"), self.getCSVName)
    QObject.connect(self.csv2shpDia.toolButton_2, SIGNAL("clicked()"), self.getSHPName)
    QObject.connect(self.csv2shpDia.pushButton, SIGNAL("clicked()"), self.csv2shp)

    QObject.connect(self.exportSHPDia.pushButton, SIGNAL("clicked()"), self.exportSHP)


    QObject.connect(self.positioningDia.comboBox_19, SIGNAL("activated(int)"), self.switchPositioningDia)
    QObject.connect(self.positioningDia, SIGNAL("rejected()"), self.reconncetion_positioningButton)
    #QObject.connect(self.cadastreDia, SIGNAL("rejected()"), self.reconnection_loginButton)
    #QObject.connect(self.cadastreDia, SIGNAL("rejected()"), self.reconnection_loginButton)
    QObject.connect(self.wmsDia, SIGNAL("rejected()"), self.clearSel)
    

    
    QObject.connect(self.positioningDia.comboBox_18, SIGNAL("activated(int)"), self.zoomTo_comboBox_18)
    QObject.connect(self.positioningDia.comboBox_18, SIGNAL("popupAboutToBeShown()"), self.addlayer_comboBox_18)
    QObject.connect(self.positioningDia.comboBox_17, SIGNAL("activated(int)"), self.zoomTo_comboBox_17)
    QObject.connect(self.positioningDia.comboBox_17, SIGNAL("popupAboutToBeShown()"), self.addlayer_comboBox_17)
    QObject.connect(self.positioningDia.comboBox_16, SIGNAL("activated(int)"), self.zoomTo_comboBox_16)
    QObject.connect(self.positioningDia.comboBox_16, SIGNAL("popupAboutToBeShown()"), self.addlayer_comboBox_16)
    QObject.connect(self.positioningDia.comboBox_15, SIGNAL("activated(int)"), self.zoomTo_comboBox_15)
    QObject.connect(self.positioningDia.comboBox_15, SIGNAL("popupAboutToBeShown()"), self.addlayer_comboBox_15)
    QObject.connect(self.positioningDia.comboBox_14, SIGNAL("activated(int)"), self.zoomTo_comboBox_14)
    QObject.connect(self.positioningDia.comboBox_14, SIGNAL("popupAboutToBeShown()"), self.addlayer_comboBox_14)
    QObject.connect(self.positioningDia.comboBox_13, SIGNAL("activated(int)"), self.zoomTo_comboBox_13)
    QObject.connect(self.positioningDia.comboBox_13, SIGNAL("popupAboutToBeShown()"), self.addlayer_comboBox_13)
    QObject.connect(self.positioningDia.comboBox_4, SIGNAL("activated(int)"), self.zoomTo_comboBox_4)
    QObject.connect(self.positioningDia.comboBox_4, SIGNAL("popupAboutToBeShown()"), self.addlayer_comboBox_4)
    QObject.connect(self.positioningDia.comboBox_20, SIGNAL("activated(int)"), self.zoomTo_comboBox_20)
    QObject.connect(self.positioningDia.comboBox_20, SIGNAL("popupAboutToBeShown()"), self.addlayer_comboBox_20)

    QObject.connect(self.positioningDia.pushButton_2, SIGNAL("clicked()"), self.queryNo)
    
    QObject.connect(self.positioningDia.comboBox_5, SIGNAL("activated(int)"), self.ComboBox_5_change)
    QObject.connect(self.positioningDia.comboBox_6, SIGNAL("activated(int)"), self.ComboBox_6_change)
    QObject.connect(self.positioningDia.comboBox_7, SIGNAL("activated(int)"), self.ComboBox_7_change)
    QObject.connect(self.positioningDia.comboBox_8, SIGNAL("activated(int)"), self.ComboBox_8_change)
    QObject.connect(self.positioningDia.comboBox_9, SIGNAL("activated(int)"), self.ComboBox_9_change)

    #保安林
    QObject.connect(self.positioningDia.comboBox_10, SIGNAL("activated(int)"), self.ComboBox_10_change)
    QObject.connect(self.positioningDia.comboBox_11, SIGNAL("activated(int)"), self.ComboBox_11_change)
    QObject.connect(self.positioningDia.comboBox_12, SIGNAL("activated(int)"), self.ComboBox_12_change)

    #轄管定位
    QObject.connect(self.positioningDia.comboBox, SIGNAL("activated(int)"), self.ComboBox_change)

    #self.combo.popupAboutToBeShown.connect(self.populateConbo)
    QObject.connect(self.positioningDia.comboBox_2, SIGNAL("activated(int)"), self.ComboBox_2_change)
    QObject.connect(self.positioningDia.comboBox_3, SIGNAL("activated(int)"), self.ComboBox_3_change)



    self.positioningDia.comboBox_11.hide()
    self.positioningDia.comboBox_12.hide()
    self.positioningDia.label_8.hide()
    self.positioningDia.label_9.hide()
    

    # add toolbar button and menu item

    #tool = PointTool(self.iface.mapCanvas())
    #self.iface.mapCanvas().setMapTool(tool)
    self.pointEmitter = QgsMapToolEmitPoint(self.iface.mapCanvas())
    self.iface.mapCanvas().setMapTool( self.pointEmitter ) 



    ########################################################
    #                                                      #
    # show and edit Default load file                      #
    #                                                      #
    ########################################################

  def helpDia_show(self):
    QMessageBox.about(self.iface.mainWindow(), "HELP", "<a href='http://qgislearn.forest.gov.tw'>點我看說明文件</a>".decode('utf-8'))

  def inforDia_show(self):

    filePath = rootPath + 'filePath.csv' 
    filePathfile = open(filePath, 'r')   
    csvCursor = csv.reader(filePathfile)
    filePathList = []
    for row in csvCursor:
        filePathList.append(row)

    for i in range(len(filePathList)):
      self.inforDia.comboBox.insertItem(i, filePathList[i][2].decode('utf-8'))

    filePath = rootPath + 'cadastreService.csv' 
    filePathfile = open(filePath, 'r')   
    csvCursor = csv.reader(filePathfile)
    filePathList = []
    for row in csvCursor:
        filePathList.append(row)

    self.inforDia.lineEdit_3.setText(filePathList[0][1].decode('utf-8'))

    filePath = rootPath + 'wmsAccount.csv' 
    filePathfile = open(filePath, 'r')   
    csvCursor = csv.reader(filePathfile)
    filePathList = []
    for row in csvCursor:
        filePathList.append(row)

    usrPw = filePathList[0][1].decode('utf-8') + ':' + filePathList[1][1].decode('utf-8')


    self.inforDia.lineEdit_4.setText(usrPw)

    self.inforDia.show()

  def reloadFilePath(self):
    filePath = rootPath + 'filePath.csv' 
    filePathfile = open(filePath, 'r')   
    csvCursor = csv.reader(filePathfile)
    filePathList = []
    for row in csvCursor:
        filePathList.append(row)

    self.inforDia.comboBox.clear()
    for i in range(len(filePathList)):
      self.inforDia.comboBox.insertItem(i, filePathList[i][2].decode('utf-8'))



  def edit_filePath(self):
    if self.inforDia.pushButton.isChecked() == True:
      self.inforDia.comboBox.setEditable(True)
      self.inforDia.pushButton_2.setEnabled(True)

    else:
      self.save_filePath()        
      self.inforDia.comboBox.setEditable(False)
      self.inforDia.pushButton_2.setEnabled(False)



  def edit_serverIP(self):
    if self.inforDia.pushButton_6.isChecked() == True:
      self.inforDia.lineEdit_3.setEnabled(True)
      self.inforDia.pushButton_5.setEnabled(True)


    else:
      self.inforDia.lineEdit_3.setEnabled(False)
      self.inforDia.pushButton_5.setEnabled(False)
      self.save_serverIP()

  def edit_wmsAccount(self):
    if self.inforDia.pushButton_8.isChecked() == True:
      self.inforDia.lineEdit_4.setEnabled(True)
      self.inforDia.pushButton_7.setEnabled(True)      
    else:
      self.inforDia.lineEdit_4.setEnabled(False)
      self.inforDia.pushButton_7.setEnabled(False) 
      self.save_wmsAccount()

  def save_filePath(self):

   reply = QMessageBox.question(self.iface.mainWindow(), '確定修改?'.decode('utf-8'), '任意修改以下資訊將可能造成程式無法運作!!\n確定要修改?'.decode('utf-8'), QMessageBox.Yes, QMessageBox.No)
   if reply == QtGui.QMessageBox.Yes:

    filePathList = []

    for i in range(self.inforDia.comboBox.count()):
      if i == self.inforDia.comboBox.currentIndex():
        newfilePath = [i, self.inforDia.comboBox.currentText().encode('utf-8')[self.inforDia.comboBox.currentText().encode('utf-8').find('\\')+1:len(self.inforDia.comboBox.currentText().encode('utf-8'))], self.inforDia.comboBox.currentText().encode('utf-8')]
      else:
        newfilePath = [i, self.inforDia.comboBox.itemText(i).encode('utf-8')[self.inforDia.comboBox.itemText(i).encode('utf-8').find('\\')+1:len(self.inforDia.comboBox.itemText(i).encode('utf-8'))],self.inforDia.comboBox.itemText(i).encode('utf-8')] 

      filePathList.append(newfilePath)      
      #QMessageBox.information(self.iface.mainWindow(), "X", self.inforDia.comboBox.itemText(i).encode('utf-8'))

    filePath = rootPath + 'filePath.csv'
    #QMessageBox.information(self.iface.mainWindow(), "X", filePath)
    file = open(filePath, 'w')
    w = csv.writer(file)
    w.writerows(filePathList)
    file.close()   

    self.reloadFilePath()

   else:
     pass       


  def save_serverIP(self):

   reply = QMessageBox.question(self.iface.mainWindow(), '確定修改?'.decode('utf-8'), '任意修改以下資訊將可能造成程式無法運作!!\n確定要修改?'.decode('utf-8'), QMessageBox.Yes, QMessageBox.No)
   if reply == QtGui.QMessageBox.Yes:
    filePathList = []

    newfilePath = [0, self.inforDia.lineEdit_3.text().encode('utf-8')]
    filePathList.append(newfilePath)      
      #QMessageBox.information(self.iface.mainWindow(), "X", self.inforDia.comboBox.itemText(i).encode('utf-8'))

    #QMessageBox.information(self.iface.mainWindow(), "X", filePathList[1])
    filePath = rootPath + 'cadastreService.csv'
    #QMessageBox.information(self.iface.mainWindow(), "X", filePath)
    file = open(filePath, 'w')
    w = csv.writer(file)
    w.writerows(filePathList)
    file.close() 

    self.inforDia.lineEdit_3.setEnabled(False)
    self.inforDia.pushButton_5.setEnabled(False)
    self.inforDia.pushButton_6.setChecked(False)

   else:
     pass       




  def save_wmsAccount(self):
   reply = QMessageBox.question(self.iface.mainWindow(), '確定修改?'.decode('utf-8'), '任意修改以下資訊將可能造成程式無法運作!!\n確定要修改?'.decode('utf-8'), QMessageBox.Yes, QMessageBox.No)

   if reply == QtGui.QMessageBox.Yes:
    filePathList = []

    newfilePath = [0, self.inforDia.lineEdit_4.text().encode('utf-8')[0:self.inforDia.lineEdit_4.text().encode('utf-8').find(':')]]
    filePathList.append(newfilePath)      

    newfilePath = [1, self.inforDia.lineEdit_4.text().encode('utf-8')[self.inforDia.lineEdit_4.text().encode('utf-8').find(':')+1: len(self.inforDia.lineEdit_4.text().encode('utf-8'))-1]]
    filePathList.append(newfilePath)          

    filePath = rootPath + 'wmsAccount.csv'

    file = open(filePath, 'w')
    w = csv.writer(file)
    w.writerows(filePathList)
    file.close() 

    self.inforDia.lineEdit_4.setEnabled(False)
    self.inforDia.pushButton_7.setEnabled(False)
    self.inforDia.pushButton_8.setChecked(False)

   else:
     pass      

  
  def writeDefaultPath(self):
    ########################################################
    #                                                      #
    # save Default Path when mainDia close                 #
    #                                                      #
    ########################################################

    
    newfilePath = [0, self.mainDia.lineEdit.text().encode('utf-8')]
    filePathList = []
    filePathList.append(newfilePath)

    #QMessageBox.information(self.iface.mainWindow(), "X", filePathList[1])
    filePath = rootPath + 'DefaultFilePath.csv'
    #QMessageBox.information(self.iface.mainWindow(), "X", filePath)
    file = open(filePath, 'w')
    w = csv.writer(file)
    w.writerows(filePathList)
    file.close()      

  def start(self):
    #self.mainDia.setGeometry(0, 0, 3572, 3524)
    self.iface.addDockWidget( Qt.RightDockWidgetArea, self.mainDia )
    #n = TFB_Tools.name()
    #QMessageBox.information(self.iface.mainWindow(), "Xname", n)
    #self.mainDia.show()
    #self.dockDia.show()
    #self.main_mainWindow.show()

    #self.dockwidget = uic.loadUi( os.path.join( rootPath, "testDock.ui" ) )
    #QMessageBox.information(self.iface.mainWindow(), "X", rootPath)
    #self.dockwidget = QtGui.QDockWidget(self.main_mainWindow)
    #self.iface.addDockWidget(Qt.LeftDockWidgetArea, self.dockwidget)
    #filePathName = self.mainDia.lineEdit.text() + filePathList[11][2].decode('utf-8')
    #newUrl = [self.addWMTSDia.lineEdit_4.text().encode('utf-8'), self.addWMTSDia.lineEdit_5.text().encode('utf-8')]
    #WMTSURLList.append(newUrl)
    #WMTSURLListfile.close()




  def desideDataPath(self):
    dataPath = QFileDialog.getExistingDirectory(None, u"請選擇資料路徑", "", QFileDialog.ShowDirsOnly)
    if dataPath != "":
      self.mainDia.lineEdit.clear()

      if dataPath[len(dataPath)-1] != "\\":
          dataPath = dataPath + "\\"
    #QMessageBox.information(self.iface.mainWindow(), "X", dataPath[len(dataPath)-1])
      self.mainDia.lineEdit.insert(dataPath)


  def load_25000(self):
    QMessageBox.information(self.iface.mainWindow(), "提示".decode('utf-8'), "請保持1/25000圖框可見並請勿移除!!\n直接點選即可載入該圖框之經建版地形圖\n若中途使用其他地圖工具或圖框圖層已移除，\n請再點選一次「1/25000經建版地形圖」按鈕".decode('utf-8'))    
    self.getImg.load_25000_img(self.mainDia.lineEdit.text())

  def load_5000(self):
    QMessageBox.information(self.iface.mainWindow(), "提示".decode('utf-8'), "請保持1/5000圖框可見並請勿移除!!\n直接點選即可載入該圖框之正射影像\n若中途使用其他地圖工具或圖框圖層已移除，\n請再點選一次「正射影像」按鈕".decode('utf-8'))    
    self.getImg.load_5000_img(self.mainDia.lineEdit.text())



  

  def clickNow_2(self, event):
    layers = self.canvas.layers()
    filePath = rootPath + 'filePath.csv'
    #QMessageBox.information(self.iface.mainWindow(), "X", filePath)
    filePathfile = open(filePath, 'r')
    csvCursor = csv.reader(filePathfile)
    filePathList = []
    for row in csvCursor:
      filePathList.append(row)

    filePathName = self.mainDia.lineEdit.text() + filePathList[11][2].decode('utf-8')

    if os.path.isfile(filePathName) :      
      #QMessageBox.information(self.iface.mainWindow(), "mes", filePathName)
      if len(QgsMapLayerRegistry.instance().mapLayersByName(filePathList[11][1].decode('utf-8'))) == 0:
        i=0
        self.iface.addVectorLayer(filePathName, "", "ogr")  

      for each_layer in layers:
        #if each_layer.source() == 'C:/data/frameData/1_5000圖幅接合圖.shp'.decode('utf-8'):
        if each_layer.source() == filePathName:
          parish_layer = each_layer
          break
      rect = QgsRectangle(event.x() - 0.000001,
                        event.y() - 0.000001,
                        event.x() + 0.000001,
                        event.y() + 0.000001)
      rect = self.iface.mapCanvas().mapRenderer().mapToLayerCoordinates(parish_layer, rect)
      parish_layer.selectByRect(rect)
      selected_features = parish_layer.selectedFeatures()
      #QMessageBox.information(self.iface.mainWindow(), "X", str(selected_features))
      if (selected_features != []):
        #QMessageBox.information(self.iface.mainWindow(), "ID5000", str(selected_features[0]["ID5000"]))
        self.wmsDia.comboBox.clear()
        self.wmsDia.comboBox.insertItem(0, str(selected_features[0]["ID5000"]))

    else:
      msg = "找不到\" ".decode('utf-8') + filePathName + " \"圖層".decode('utf-8') + "\n請確認路徑".decode('utf-8') 
      QMessageBox.information(self.iface.mainWindow(), "錯誤".decode('utf-8'), msg) 


    
  def load_1_5000(self):
    self.iface.mapCanvas().unsetMapTool( self.pointEmitter )

    filePath = rootPath + 'filePath.csv'
    #QMessageBox.information(self.iface.mainWindow(), "X", filePath)
    filePathfile = open(filePath, 'r')
    csvCursor = csv.reader(filePathfile)
    filePathList = []
    for row in csvCursor:
      filePathList.append(row)

    filePathName = self.mainDia.lineEdit.text() + filePathList[11][2].decode('utf-8')

    if os.path.isfile(filePathName) :    
      #QMessageBox.information(self.iface.mainWindow(), "mes", filePathName)
      if len(QgsMapLayerRegistry.instance().mapLayersByName(filePathList[11][1].decode('utf-8'))) == 0:
        i=0
        self.iface.addVectorLayer(filePathName, "", "ogr")  

        global styleFilePath_5000    
        styleFilePath_5000 = rootPath + 'style/noFillBlueLine.qml'
        self.iface.activeLayer().loadNamedStyle(styleFilePath_5000)        

    #if len(QgsMapLayerRegistry.instance().mapLayersByName('1_5000圖幅接合圖'.decode('utf-8'))) == 0:
      #self.iface.addVectorLayer('C:/data/frameData/1_5000圖幅接合圖.shp'.decode('utf-8'), "", "ogr")
      self.setSourceEncode()

      legend = self.iface.legendInterface()
      registry = QgsMapLayerRegistry.instance()
      #self.positioningDia.comboBox_2.currentText() + '事業區林班圖'.decode('utf-8')

      target_layer = registry.mapLayersByName( filePathList[11][1].decode('utf-8') )[0]
      #target_layer = registry.mapLayersByName( '第二輪檢訂事業區圖'.decode('utf-8') )[0]
      self.iface.setActiveLayer(target_layer)    
      legend.setLayerVisible(target_layer, True) 

      self.pointEmitter = QgsMapToolEmitPoint(self.iface.mapCanvas())
      QObject.connect( self.pointEmitter, SIGNAL("canvasClicked(const QgsPoint, Qt::MouseButton)"), self.clickNow_2)
      self.iface.mapCanvas().setMapTool( self.pointEmitter )     
      #self.start()    

    else:
      msg = "找不到\" ".decode('utf-8') + filePathName + " \"圖層".decode('utf-8') + "\n請確認路徑".decode('utf-8') 
      QMessageBox.information(self.iface.mainWindow(), "錯誤".decode('utf-8'), msg) 

    #else:
      #msg = "找不到\" ".decode('utf-8') + filePathName_5000 + " \"圖層".decode('utf-8') + "\n請確認路徑".decode('utf-8') 
      #QMessageBox.information(self.iface.mainWindow(), "錯誤".decode('utf-8'), msg)  







  def clearSel(self):
    #self.iface.activeLayer().removeSelection()    
    self.wmsDia.comboBox.clear()

  def wms_show(self):

    filePath = rootPath + 'filePath.csv'
    #QMessageBox.information(self.iface.mainWindow(), "X", filePath)
    filePathfile = open(filePath, 'r')
    csvCursor = csv.reader(filePathfile)
    filePathList = []
    for row in csvCursor:
      filePathList.append(row)

    filePathName = self.mainDia.lineEdit.text() + filePathList[11][2].decode('utf-8')

    self.wmsDia.comboBox.clear()
    self.wmsDia.comboBox_2.clear()
    
    if os.path.isfile(filePathName) :    
      self.load_1_5000()            
      self.wmsDia.show()
    else:
      msg = "找不到\" ".decode('utf-8') + filePathName + " \"圖層".decode('utf-8') + "\n請確認路徑".decode('utf-8') 
      QMessageBox.information(self.iface.mainWindow(), "錯誤".decode('utf-8'), msg)     


  def addWMS(self):
    
    if self.wmsDia.radioButton.isChecked():
      url = 'http://owms.afasi.gov.tw/asofb/'
    if self.wmsDia.radioButton_2.isChecked():
      url = 'http://10.51.231.101/asofb/owms/'

    filePath = rootPath + 'wmsAccount.csv'
    #QMessageBox.information(self.iface.mainWindow(), "X", filePath)
    filePathfile = open(filePath, 'r')
    csvCursor = csv.reader(filePathfile)
    accountList = []
    for row in csvCursor:
        accountList.append(row)

    username = accountList[0][1]
    password = accountList[1][1]
    #username = "sinica1gov"
    #password = "gov1sinica104AP"

    urlWithParams = 'contextualWMSLegend=0&crs=EPSG:3826&dpiMode=7&featureCount=10&format=image/png&styles=&url=' + url + self.wmsDia.comboBox.currentText() + '/wms?&username=' + username + '&layers=' + self.wmsDia.comboBox_2.currentText() + '&password=' + password
    #QMessageBox.information(self.iface.mainWindow(), "X", urlWithParams)    
    #urlWithParams = self.WMTSDia.tableWidget_4.item(self.WMTSDia.tableWidget_4.currentRow(), 2).text()
    rlayer = QgsRasterLayer(urlWithParams, self.wmsDia.comboBox_2.currentText(), 'wms')
    QgsMapLayerRegistry.instance().addMapLayer(rlayer) 

    root = QgsProject.instance().layerTreeRoot()

    filePath = rootPath + 'filePath.csv'
    filePathfile = open(filePath, 'r')
    csvCursor = csv.reader(filePathfile)

    global filePathList_5000
    filePathList_5000 = []
    for row in csvCursor:
      filePathList_5000.append(row)

    global defaultDir_5000
    defaultDir_5000 = self.mainDia.lineEdit.text()
    global filePathName_5000
    filePathName_5000 = defaultDir_5000 + filePathList_5000[11][2].decode('utf-8')


    layers = self.canvas.layers()  
    for each_layer in layers:
      if each_layer.source() == filePathName_5000:        
        parish_layer = each_layer
        break

    myalayer = root.findLayer(parish_layer.id())
    myClone = myalayer.clone()
    parent = myalayer.parent()
    parent.insertChildNode(0, myClone)
    parent.removeChildNode(myalayer)


  def getWMSList(self):

    filePath = rootPath + 'wmsAccount.csv'
    #QMessageBox.information(self.iface.mainWindow(), "X", filePath)
    filePathfile = open(filePath, 'r')
    csvCursor = csv.reader(filePathfile)
    accountList = []
    for row in csvCursor:
        accountList.append(row)

    username = accountList[0][1]
    password = accountList[1][1]
    url = "http://owms.afasi.gov.tw/asofb/" + self.wmsDia.comboBox.currentText() + "/wms?request=getcapabilities"
    #QMessageBox.information(self.iface.mainWindow(), "mes", url)
    request = urllib2.Request(url)
    base64string = base64.encodestring('%s:%s' % (username, password)).replace('\n', '')
    request.add_header("Authorization", "Basic %s" % base64string)
    response = urllib2.urlopen(request)

    #response = urllib2.urlopen('http://wms.afasi.gov.tw/asofb/wms?request=getcapabilities')  
    xmlDoc = xml.dom.minidom.parse(response)
    root = xmlDoc.documentElement
    layerList =  root.getElementsByTagName('Layer')
    #QMessageBox.information(self.iface.mainWindow(), "mes", layerList[0].childNodes[0].data)
    wmtsTitleList = []
    #wmtsIdentifierList = []
    #wmtsFormatList = []
    
    for layer in layerList:
      owsTitleList = layer.getElementsByTagName('Name')
      if layer.getAttribute("queryable") == '1':
        wmtsTitleList.append(owsTitleList[0].childNodes[0].data)
      #owsIdentifier = layer.getElementsByTagName('ows:Identifier')
      #imgformatList = layer.getElementsByTagName('Format')

      
      #wmtsIdentifierList.append(owsIdentifier[0].childNodes[0].data)
      #wmtsFormatList.append(imgformatList[0].childNodes[0].data)    
    #QMessageBox.information(self.iface.mainWindow(), "mes", wmtsTitleList[3])
    self.wmsDia.comboBox_2.clear()
    for i in range(0, len(wmtsTitleList), 1):
      self.wmsDia.comboBox_2.insertItem(i, wmtsTitleList[i])

  def wmsDia_comboBox_change(self):
    filePath = rootPath + 'filePath.csv'
    #QMessageBox.information(self.iface.mainWindow(), "X", filePath)
    filePathfile = open(filePath, 'r')
    csvCursor = csv.reader(filePathfile)
    filePathList = []
    for row in csvCursor:
      filePathList.append(row)

    registry = QgsMapLayerRegistry.instance()
    legend = self.iface.legendInterface()

    target_layer = registry.mapLayersByName( filePathList[11][1].decode('utf-8') )[0]
    self.iface.setActiveLayer(target_layer)
    legend.setLayerVisible(target_layer, True)

    expr = QgsExpression( " \"{}\" ='{}' ".format( 'ID5000', self.wmsDia.comboBox.currentText().encode('utf-8')))    

    it = target_layer.getFeatures( QgsFeatureRequest( expr ) )
    ids = [i.id() for i in it]
    
    self.iface.activeLayer().removeSelection()
    target_layer.setSelectedFeatures( ids )
    #self.canvas.zoomToSelected()

  def getID5000(self):

    self.wmsDia.comboBox.clear()
    self.wmsDia.comboBox_2.clear()

    self.load_1_5000()

    crs = QgsCoordinateReferenceSystem(3826)
    self.iface.mapCanvas().mapRenderer().setDestinationCrs(crs) 

    legend = self.iface.legendInterface()
    layers = self.canvas.layers()
    for each_layer in layers:
      legend.setLayerVisible(each_layer, False)
    registry = QgsMapLayerRegistry.instance()

    filePath = rootPath + 'filePath.csv'
    #QMessageBox.information(self.iface.mainWindow(), "X", filePath)
    filePathfile = open(filePath, 'r')
    csvCursor = csv.reader(filePathfile)
    filePathList = []
    for row in csvCursor:
      filePathList.append(row)

    #filePathName = self.mainDia.lineEdit.text() + filePathList[11][2].decode('utf-8')

    #target_layer = registry.mapLayersByName( '1_5000圖幅接合圖0931'.decode('utf-8') )[0]
    target_layer = registry.mapLayersByName( filePathList[11][1].decode('utf-8') )[0]
    self.iface.setActiveLayer(target_layer)
    legend.setLayerVisible(target_layer, True)
    #extent = target_layer.extent()
    #self.canvas.setExtent(extent)

    rect = self.canvas.extent()
    request = QgsFeatureRequest().setFilterRect(rect)
    it = target_layer.getFeatures( request )
    ids = [i.id() for i in it]
    
    self.iface.activeLayer().removeSelection()
    target_layer.setSelectedFeatures( ids )

    i=0
    features = self.iface.activeLayer().selectedFeatures()
    idx_1 = self.iface.activeLayer().fieldNameIndex('ID5000')

    self.wmsDia.comboBox.clear()
    for feat in features:
      attrs_1 = feat.attributes()[idx_1]
      self.wmsDia.comboBox.insertItem(i+1, str(attrs_1))
      i+=1    

  def addlayer_comboBox_16(self):
    # 自然保護區 comboBox_16
    
    filePath = rootPath + 'filePath.csv'
    #QMessageBox.information(self.iface.mainWindow(), "X", filePath)
    filePathfile = open(filePath, 'r')
    csvCursor = csv.reader(filePathfile)
    filePathList = []
    for row in csvCursor:
        filePathList.append(row)

    i=0

    filePathName = self.mainDia.lineEdit.text() + filePathList[3][2].decode('utf-8')

    #os.path.isfile(fname) 
    if os.path.isfile(filePathName) :

    #QMessageBox.information(self.iface.mainWindow(), "mes", filePathName)
      if len(QgsMapLayerRegistry.instance().mapLayersByName(filePathList[3][1].decode('utf-8'))) == 0:
        self.iface.addVectorLayer(filePathName, "", "ogr")
        self.setSourceEncode()
        self.positioningDia.comboBox_16.clear()
        self.positioningDia.comboBox_16.insertItem(0, '請選擇欲定位區位'.decode('utf-8'))

        features = self.iface.activeLayer().getFeatures()
        #idx_1 = self.iface.activeLayer().fieldNameIndex('NAME')
        idx_1 = self.iface.activeLayer().fieldNameIndex(filePathList[3][3].decode('utf-8'))
        
        for feat in features:
          attrs_1 = feat.attributes()[idx_1]
          self.positioningDia.comboBox_16.insertItem(i+1, attrs_1)
          i+=1

        self.positioningDia.comboBox_16.setCurrentIndex(0)

    else:
      msg = "找不到\" ".decode('utf-8') + filePathName + " \"圖層".decode('utf-8') + "\n請確認路徑".decode('utf-8') 
      QMessageBox.information(self.iface.mainWindow(), "錯誤".decode('utf-8'), msg)      


  def addlayer_comboBox_17(self):
    # 自然保留區 comboBox_17
    filePath = rootPath + 'filePath.csv'
    #QMessageBox.information(self.iface.mainWindow(), "X", filePath)
    filePathfile = open(filePath, 'r')
    csvCursor = csv.reader(filePathfile)
    filePathList = []
    for row in csvCursor:
        filePathList.append(row)

    i=0
    
    filePathName = self.mainDia.lineEdit.text() + filePathList[4][2].decode('utf-8')

    if os.path.isfile(filePathName) :    
    #QMessageBox.information(self.iface.mainWindow(), "mes", filePathName)
      if len(QgsMapLayerRegistry.instance().mapLayersByName(filePathList[4][1].decode('utf-8'))) == 0:
        self.iface.addVectorLayer(filePathName, "", "ogr")
        self.setSourceEncode()
        self.positioningDia.comboBox_17.clear()
        self.positioningDia.comboBox_17.insertItem(0, '請選擇欲定位區位'.decode('utf-8'))

        features = self.iface.activeLayer().getFeatures()
        #idx_1 = self.iface.activeLayer().fieldNameIndex('NAME')
        idx_1 = self.iface.activeLayer().fieldNameIndex(filePathList[4][3].decode('utf-8'))
        for feat in features:
          attrs_1 = feat.attributes()[idx_1]
          self.positioningDia.comboBox_17.insertItem(i+1, attrs_1)
          i+=1

        self.positioningDia.comboBox_17.setCurrentIndex(0)  

    else:
      msg = "找不到\" ".decode('utf-8') + filePathName + " \"圖層".decode('utf-8') + "\n請確認路徑".decode('utf-8') 
      QMessageBox.information(self.iface.mainWindow(), "錯誤".decode('utf-8'), msg)               


  def addlayer_comboBox_15(self):
    # 林業化園區 comboBox_15
    filePath = rootPath + 'filePath.csv'
    #QMessageBox.information(self.iface.mainWindow(), "X", filePath)
    filePathfile = open(filePath, 'r')
    csvCursor = csv.reader(filePathfile)
    filePathList = []
    for row in csvCursor:
        filePathList.append(row)

    i=0
    
    filePathName = self.mainDia.lineEdit.text() + filePathList[10][2].decode('utf-8')

    if os.path.isfile(filePathName) :    
    #QMessageBox.information(self.iface.mainWindow(), "mes", filePathName)
      if len(QgsMapLayerRegistry.instance().mapLayersByName(filePathList[10][1].decode('utf-8'))) == 0:
        self.iface.addVectorLayer(filePathName, "", "ogr")      
        self.setSourceEncode()
        self.positioningDia.comboBox_15.clear()
        self.positioningDia.comboBox_15.insertItem(0, '請選擇欲定位區位'.decode('utf-8'))

        features = self.iface.activeLayer().getFeatures()
        #idx_1 = self.iface.activeLayer().fieldNameIndex('NAME')
        idx_1 = self.iface.activeLayer().fieldNameIndex(filePathList[10][3].decode('utf-8'))
        for feat in features:
          attrs_1 = feat.attributes()[idx_1]
          self.positioningDia.comboBox_15.insertItem(i+1, attrs_1)
          i+=1

        self.positioningDia.comboBox_15.setCurrentIndex(0)

    else:
      msg = "找不到\" ".decode('utf-8') + filePathName + " \"圖層".decode('utf-8') + "\n請確認路徑".decode('utf-8') 
      QMessageBox.information(self.iface.mainWindow(), "錯誤".decode('utf-8'), msg)          

  def addlayer_comboBox_4(self):
    # 森林遊樂區範圍界 comboBox_4
    filePath = rootPath + 'filePath.csv'
    #QMessageBox.information(self.iface.mainWindow(), "X", filePath)
    filePathfile = open(filePath, 'r')
    csvCursor = csv.reader(filePathfile)
    filePathList = []
    for row in csvCursor:
        filePathList.append(row)

    i=0
    
    filePathName = self.mainDia.lineEdit.text() + filePathList[8][2].decode('utf-8')

    if os.path.isfile(filePathName) :    
      #QMessageBox.information(self.iface.mainWindow(), "mes", filePathName)
      if len(QgsMapLayerRegistry.instance().mapLayersByName(filePathList[8][1].decode('utf-8'))) == 0:
        self.iface.addVectorLayer(filePathName, "", "ogr")      
        self.setSourceEncode()
        self.positioningDia.comboBox_4.clear()
        self.positioningDia.comboBox_4.insertItem(0, '請選擇欲定位區位'.decode('utf-8'))

        features = self.iface.activeLayer().getFeatures()
        #idx_1 = self.iface.activeLayer().fieldNameIndex('NAME')
        idx_1 = self.iface.activeLayer().fieldNameIndex(filePathList[8][3].decode('utf-8'))
        #idx_2 = self.iface.activeLayer().fieldNameIndex('分區'.decode('utf-8'))
        for feat in features:
          attrs_1 = feat.attributes()[idx_1]
          #attrs_2 = feat.attributes()[idx_2]
          #if attrs_2 != NULL:
            #attr_str = attrs_1 + "_" + attrs_2
          #else:
            #attr_str = attrs_1
          self.positioningDia.comboBox_4.insertItem(i+1, attrs_1)
          i+=1

        self.positioningDia.comboBox_4.setCurrentIndex(0)

    else:
      msg = "找不到\" ".decode('utf-8') + filePathName + " \"圖層".decode('utf-8') + "\n請確認路徑".decode('utf-8') 
      QMessageBox.information(self.iface.mainWindow(), "錯誤".decode('utf-8'), msg)  


  def addlayer_comboBox_20(self):
    # 國家公園 comboBox_20
    filePath = rootPath + 'filePath.csv'
    #QMessageBox.information(self.iface.mainWindow(), "X", filePath)
    filePathfile = open(filePath, 'r')
    csvCursor = csv.reader(filePathfile)
    filePathList = []
    for row in csvCursor:
        filePathList.append(row)

    i=0
    
    filePathName = self.mainDia.lineEdit.text() + filePathList[7][2].decode('utf-8')
    #QMessageBox.information(self.iface.mainWindow(), "mes", filePathName)

    if os.path.isfile(filePathName) :    
      if len(QgsMapLayerRegistry.instance().mapLayersByName(filePathList[7][1].decode('utf-8'))) == 0:
        self.iface.addVectorLayer(filePathName, "", "ogr")      
        self.setSourceEncode()
        self.positioningDia.comboBox_20.clear()
        self.positioningDia.comboBox_20.insertItem(0, '請選擇欲定位區位'.decode('utf-8'))

        features = self.iface.activeLayer().getFeatures()
        #idx_1 = self.iface.activeLayer().fieldNameIndex('NAME')
        idx_1 = self.iface.activeLayer().fieldNameIndex(filePathList[7][3].decode('utf-8'))
        for feat in features:
          attrs_1 = feat.attributes()[idx_1]
          self.positioningDia.comboBox_20.insertItem(i+1, attrs_1)
          i+=1

        self.positioningDia.comboBox_20.setCurrentIndex(0)    

    else:
      msg = "找不到\" ".decode('utf-8') + filePathName + " \"圖層".decode('utf-8') + "\n請確認路徑".decode('utf-8') 
      QMessageBox.information(self.iface.mainWindow(), "錯誤".decode('utf-8'), msg)          


  def addlayer_comboBox_13(self):
    # 平地森林園區 comboBox_13
    filePath = rootPath + 'filePath.csv'
    #QMessageBox.information(self.iface.mainWindow(), "X", filePath)
    filePathfile = open(filePath, 'r')
    csvCursor = csv.reader(filePathfile)
    filePathList = []
    for row in csvCursor:
        filePathList.append(row)

    i=0
    
    filePathName = self.mainDia.lineEdit.text() + filePathList[9][2].decode('utf-8')
    if os.path.isfile(filePathName) :

      #QMessageBox.information(self.iface.mainWindow(), "mes", filePathName)
      if len(QgsMapLayerRegistry.instance().mapLayersByName(filePathList[9][1].decode('utf-8'))) == 0:
        self.iface.addVectorLayer(filePathName, "", "ogr")      
        self.setSourceEncode()
        self.positioningDia.comboBox_13.clear()
        self.positioningDia.comboBox_13.insertItem(0, '請選擇欲定位區位'.decode('utf-8'))

        features = self.iface.activeLayer().getFeatures()
        #idx_1 = self.iface.activeLayer().fieldNameIndex('NAME')
        idx_1 = self.iface.activeLayer().fieldNameIndex(filePathList[9][3].decode('utf-8'))
        for feat in features:
          attrs_1 = feat.attributes()[idx_1]
          self.positioningDia.comboBox_13.insertItem(i+1, attrs_1)
          i+=1

        self.positioningDia.comboBox_13.setCurrentIndex(0)

    else:
      msg = "找不到\" ".decode('utf-8') + filePathName + " \"圖層".decode('utf-8') + "\n請確認路徑".decode('utf-8') 
      QMessageBox.information(self.iface.mainWindow(), "錯誤".decode('utf-8'), msg)  


  def addlayer_comboBox_18(self):
    # 野生動物保護區 comboBox_18
    filePath = rootPath + 'filePath.csv'
    #QMessageBox.information(self.iface.mainWindow(), "X", filePath)
    filePathfile = open(filePath, 'r')
    csvCursor = csv.reader(filePathfile)
    filePathList = []
    for row in csvCursor:
        filePathList.append(row)

    i=0
    
    filePathName = self.mainDia.lineEdit.text() + filePathList[5][2].decode('utf-8')

    if os.path.isfile(filePathName) :    
      #QMessageBox.information(self.iface.mainWindow(), "mes", filePathName)
      if len(QgsMapLayerRegistry.instance().mapLayersByName(filePathList[5][1].decode('utf-8'))) == 0:
        self.iface.addVectorLayer(filePathName, "", "ogr")      
        self.setSourceEncode()
        self.positioningDia.comboBox_18.clear()
        self.positioningDia.comboBox_18.insertItem(0, '請選擇欲定位區位'.decode('utf-8'))

        features = self.iface.activeLayer().getFeatures()
        #idx_1 = self.iface.activeLayer().fieldNameIndex('NAME')
        #idx_2 = self.iface.activeLayer().fieldNameIndex('C_name')
        idx_1 = self.iface.activeLayer().fieldNameIndex(filePathList[5][3].decode('utf-8'))
        #idx_2 = self.iface.activeLayer().fieldNameIndex(filePathList[5][4].decode('utf-8'))        
        for feat in features:
          attrs_1 = feat.attributes()[idx_1]
          #attrs_2 = feat.attributes()[idx_2]
          #if attrs_2 != NULL:
            #attr_str = attrs_1 + "_" + attrs_2
          #else:
            #attr_str = attrs_1
          self.positioningDia.comboBox_18.insertItem(i+1, attrs_1)
          i+=1

        self.positioningDia.comboBox_18.setCurrentIndex(0)

    else:
      msg = "找不到\" ".decode('utf-8') + filePathName + " \"圖層".decode('utf-8') + "\n請確認路徑".decode('utf-8') 
      QMessageBox.information(self.iface.mainWindow(), "錯誤".decode('utf-8'), msg) 


  def addlayer_comboBox_14(self):
    #QMessageBox.information(self.iface.mainWindow(), "X", "it works")
    filePath = rootPath + 'filePath.csv'
    #QMessageBox.information(self.iface.mainWindow(), "X", filePath)
    filePathfile = open(filePath, 'r')
    csvCursor = csv.reader(filePathfile)
    filePathList = []
    for row in csvCursor:
        filePathList.append(row)

    i=0
    
    filePathName = self.mainDia.lineEdit.text() + filePathList[6][2].decode('utf-8')

    if os.path.isfile(filePathName) :    
      #QMessageBox.information(self.iface.mainWindow(), "mes", filePathName)
      if len(QgsMapLayerRegistry.instance().mapLayersByName(filePathList[6][1].decode('utf-8'))) == 0:
        self.iface.addVectorLayer(filePathName, "", "ogr")      
        self.setSourceEncode()
        self.positioningDia.comboBox_14.clear()
        self.positioningDia.comboBox_14.insertItem(0, '請選擇欲定位區位'.decode('utf-8'))

        features = self.iface.activeLayer().getFeatures()
        #idx_1 = self.iface.activeLayer().fieldNameIndex('NAME')
        #idx_2 = self.iface.activeLayer().fieldNameIndex('C_name')
        idx_1 = self.iface.activeLayer().fieldNameIndex(filePathList[6][3].decode('utf-8'))
        #idx_2 = self.iface.activeLayer().fieldNameIndex(filePathList[6][4].decode('utf-8'))        
        for feat in features:
          attrs_1 = feat.attributes()[idx_1]
          #attrs_2 = feat.attributes()[idx_2]
          #if attrs_2 != NULL:
            #attr_str = attrs_1 + "_" + attrs_2
          #else:
            #attr_str = attrs_1
          self.positioningDia.comboBox_14.insertItem(i+1, attrs_1)
          i+=1

        self.positioningDia.comboBox_14.setCurrentIndex(0)

    else:
      msg = "找不到\" ".decode('utf-8') + filePathName + " \"圖層".decode('utf-8') + "\n請確認路徑".decode('utf-8') 
      QMessageBox.information(self.iface.mainWindow(), "錯誤".decode('utf-8'), msg)         

  def exportSHP(self):
    # decide crs
    if self.exportSHPDia.comboBox.currentIndex()==0 : #twd97
      #crs = "point?crs=epsg:3826"
      crs=QgsCoordinateReferenceSystem("epsg:3826")
    if self.exportSHPDia.comboBox.currentIndex()==1 : #wgs84
      #crs = "point?crs=epsg:4326"    
      crs=QgsCoordinateReferenceSystem("epsg:4326")

    #self.iface.addVectorLayer(self.gpx2shpDia.lineEdit.text()+"?type=track_points", self.gpx2shpDia.lineEdit.text(), "gpx")
      #self.iface.addVectorLayer("C:/Users/rchss_/Desktop/dataOperation_v0.9/GPX/mGPX_20151216021510.gpx|layerid=4", self.gpx2shpDia.lineEdit.text(), "gpx")


      #QgsMapLayerRegistry.instance().addMapLayers([layer])
    registry = QgsMapLayerRegistry.instance()
    target_layer = registry.mapLayersByName( self.exportSHPDia.listWidget.currentItem().text() )[0]
    self.iface.setActiveLayer(target_layer)      
    #QMessageBox.information(self.iface.mainWindow(), u"轉換完成", self.exportSHPDia.listWidget.currentItem().text() )
    shpFileName = QFileDialog.getSaveFileName(None, u"圖層另存為", self.mainDia.lineEdit.text(), "SHP files (*.shp)")

    if self.exportSHPDia.checkBox.isChecked():
      _writer = QgsVectorFileWriter.writeAsVectorFormat(self.iface.activeLayer(), shpFileName, "UTF-8", crs, "ESRI Shapefile", True)
    else:
      _writer = QgsVectorFileWriter.writeAsVectorFormat(self.iface.activeLayer(), shpFileName, "UTF-8", crs, "ESRI Shapefile")

    outfile = "輸出檔案:".decode('utf-8') + shpFileName
    QMessageBox.information(self.iface.mainWindow(), u"匯出完成", outfile )
    layer=QgsVectorLayer(shpFileName , shpFileName, "ogr")
    QgsMapLayerRegistry.instance().addMapLayers([layer])

  def exportSHP_show(self):
    #legend = self.iface.legendInterface()
    self.exportSHPDia.checkBox.setChecked(True)

    names = []
    #for layer in QgsMapLayerRegistry.instance().mapLayers().values():
    for layer in self.iface.mapCanvas().layers():
        
      #QMessageBox.information(self.iface.mainWindow(), "layer.name()", layer.name())
      if layer.type() == QgsMapLayer.VectorLayer:
        names.append(layer.name())

    self.exportSHPDia.listWidget.clear()
    for i in range(len(names)):
      self.exportSHPDia.listWidget.addItem(names[i])
    self.exportSHPDia.show()

  def csv2shp_show(self):
    #QMessageBox.information(self.iface.mainWindow(), "X", "csv2shp")
    self.csv2shpDia.show()


  def openQGS(self):
    qgsFileName = QFileDialog.getOpenFileName(None, u"請選擇專案檔", self.mainDia.lineEdit.text(), "qgs files (*.qgs)")
    project = QgsProject.instance() 
    project.read(QFileInfo(qgsFileName))

  def internet_on(self):
    try:
        urllib2.urlopen('http://maps.nlsc.gov.tw/T09/pro/setCountry.jsp', timeout=1)
        return 1
    except urllib2.URLError as err: 
        return 0

  def cadastre_reset(self):
    self.cadastreDia.comboBox.setCurrentIndex(0)
    self.cadastreDia.comboBox_2.clear()
    self.cadastreDia.comboBox_3.clear()
    self.cadastreDia.listWidget.clear()
    #self.cadastreDia.lineEdit_4.clear()
    #self.cadastreDia.listWidget_2.clear()
    self.cadastreDia.listWidget.clear()
    self.cadastreDia.checkBox.setChecked(0)
    self.cadastreDia.tabWidget.setCurrentIndex(0)
    self.cadastreDia.lineEdit_2.setEnabled(True)
    self.cadastreDia.lineEdit_3.setEnabled(True)    
    self.cadastreDia.comboBox_5.clear()


  def resetCadastreDia(self):
    self.cadastre_reset()
    self.cadastreDia.tableWidget.clearContents()
    self.cadastreDia.tableWidget_2.clearContents()
    self.cadastreDia.tableWidget_3.clearContents()
    self.cadastreDia.tableWidget_4.clearContents()

  def cadastre_show(self):
    #self.loginDia.close()
    if self.internet_on()== 0:
      QMessageBox.information(self.iface.mainWindow(), "錯誤".decode('utf-8'), "請檢查網路連線狀態".decode('utf-8'))

    else:
      self.cadastreDia.comboBox.clear()
      self.cadastreDia.comboBox.insertItem(0, '請選擇縣市'.decode('utf-8'))

      getCountyUrl = 'http://maps.nlsc.gov.tw/T09/pro/setCountry.jsp'
      response = urllib2.urlopen(getCountyUrl)
      xmlDoc = xml.dom.minidom.parse(response)
      root = xmlDoc.documentElement
      countyL = []
      for i in range(0, len(root.getElementsByTagName('name')), 1):
        node = root.getElementsByTagName('name')[i]
        countyID = root.getElementsByTagName('id')[i]
        county = countyID.childNodes[0].data + '-' + node.childNodes[0].data
        countyL.append(county)
        #self.cadastreDia.comboBox.insertItem(i+1, county)

      filePath = rootPath + 'countySort.csv'
      countyListfile = open(filePath, 'r')
      #QMessageBox.information(self.iface.mainWindow(), "mes".decode('utf-8'), filePath)
      csvCursor = csv.reader(countyListfile)
      cL = []
      for row in csvCursor:
        cL.append(row)   
        #self.cadastreDia.comboBox.insertItem(i+1, countyList[i][1])
      
      cLD = []
      for i in range(0, len(cL), 1):
        cLD.append(cL[i][1].decode('utf-8'))
        #QMessageBox.information(self.iface.mainWindow(), "mes_0".decode('utf-8'), cL[i][1].decode('utf-8'))
      #QMessageBox.information(self.iface.mainWindow(), "mes".decode('utf-8'), countyList[10][1].decode('utf-8'))


      finalList=[]
      #if 7 in a:
      for i in range(0, len(cLD), 1):
        #QMessageBox.information(self.iface.mainWindow(), "mes".decode('utf-8'), cLD[i])
        if countyL.count(cLD[i]) == 1:
          finalList.append(cLD[i])
          #QMessageBox.information(self.iface.mainWindow(), "mes".decode('utf-8'), "t")
        #else:
          #QMessageBox.information(self.iface.mainWindow(), "mes".decode('utf-8'), countyL[i])
          #i+=1

      for i in range(0, len(finalList), 1):
        self.cadastreDia.comboBox.insertItem(i+1, finalList[i])
      #for i in range(0, len(countyList), 1):
        #self.cadastreDia.comboBox.insertItem(i+1, countyList[i][0].decode('utf-8'))

      self.cadastreDia.show()

  def saveToWMTSList(self):
    favoriteWMTSList = []
    for i in range(0, self.WMTSDia.tableWidget_4.rowCount(), 1):
      favoriteWMTSList.append([])
      str=self.WMTSDia.tableWidget_4.item(i, 0).text()
      favoriteWMTSList[i].append(str)
      str=self.WMTSDia.tableWidget_4.item(i, 1).text()
      favoriteWMTSList[i].append(str.encode('utf-8'))
      str=self.WMTSDia.tableWidget_4.item(i, 2).text()
      favoriteWMTSList[i].append(str)

    filePath = rootPath + 'DefaultWMTS_Layer.csv'
    file = open(filePath, 'w')
    #file = open('C:/data/DefaultWMTS_Layer.csv', 'w')
    w = csv.writer(file)
    w.writerows(favoriteWMTSList)
    file.close()

    self.WMTSDia.comboBox_2.setCurrentIndex(0)
    self.WMTSDia.comboBox.clear()

  def showaddWMTSDia(self):
    self.addWMTSDia.show()

  def addWMTSto(self):
    i=0
    filePath = rootPath + 'DefaultWMTS_Url.csv' 
    WMTSURLListfile = open(filePath, 'r')   
    #WMTSURLListfile = open('C:/data/DefaultWMTS_Url.csv', 'r')
    csvCursor = csv.reader(WMTSURLListfile)
    WMTSURLList = []
    for row in csvCursor:
        WMTSURLList.append(row)
    newUrl = [self.addWMTSDia.lineEdit_4.text().encode('utf-8'), self.addWMTSDia.lineEdit_5.text().encode('utf-8')]
    WMTSURLList.append(newUrl)
    WMTSURLListfile.close()

    self.addWMTSDia.close()
    self.addWMTSDia.lineEdit_4.clear()
    self.addWMTSDia.lineEdit_5.clear()

    self.WMTSDia.comboBox_2.clear()
    for i in range(len(WMTSURLList)):
      self.WMTSDia.comboBox_2.insertItem(i, WMTSURLList[i][0].decode('utf-8'))
    
    #filePath_2 = rootPath + 'DefaultWMTS_Url.csv' 
    file = open(filePath, 'w')
    w = csv.writer(file)
    w.writerows(WMTSURLList)
    file.close()      

  def rmItem(self):
    self.WMTSDia.tableWidget_4.removeRow(self.WMTSDia.tableWidget_4.currentRow())

  def rmService(self):

    i=0
    filePath = rootPath + 'DefaultWMTS_Url.csv' 
    WMTSURLListfile = open(filePath, 'r')
    #WMTSURLListfile = open('C:/data/DefaultWMTS_Url.csv', 'r')
    csvCursor = csv.reader(WMTSURLListfile)
    WMTSURLList = []
    for row in csvCursor:
      #QMessageBox.information(self.iface.mainWindow(), "mes".decode('utf-8'), str(self.WMTSDia.comboBox_2.currentIndex()))
      if i != self.WMTSDia.comboBox_2.currentIndex():
        WMTSURLList.append(row)
        #QMessageBox.information(self.iface.mainWindow(), "mes".decode('utf-8'), str(i))
      i+=1
    WMTSURLListfile.close()

    self.WMTSDia.comboBox_2.clear()
    for i in range(len(WMTSURLList)):
      self.WMTSDia.comboBox_2.insertItem(i, WMTSURLList[i][0].decode('utf-8'))

    file = open(filePath, 'w')
    #file = open('C:/data/DefaultWMTS_Url.csv', 'w')
    w = csv.writer(file)
    w.writerows(WMTSURLList)
    file.close()  

  def addToList(self):
    #QMessageBox.information(self.iface.mainWindow(), "mes".decode('utf-8'), str(self.WMTSDia.comboBox.currentIndex()))
    filePath = rootPath + 'DefaultWMTS_Url.csv'
    WMTSURLListfile = open(filePath, 'r')
   #WMTSURLListfile = open('C:/data/DefaultWMTS_Url.csv', 'r')
    csvCursor = csv.reader(WMTSURLListfile)
    WMTSURLList = []
    for row in csvCursor:
      WMTSURLList.append(row)

    response = urllib2.urlopen(WMTSURLList[self.WMTSDia.comboBox_2.currentIndex()][1])
    xmlDoc = xml.dom.minidom.parse(response)
    root = xmlDoc.documentElement
    layerList =  root.getElementsByTagName('Layer')

    wmtsTitleList = []
    wmtsIdentifierList = []
    wmtsFormatList = []

    for layer in layerList:
      owsTitleList = layer.getElementsByTagName('ows:Title')
      owsIdentifier = layer.getElementsByTagName('ows:Identifier')
      imgformatList = layer.getElementsByTagName('Format')

      wmtsTitleList.append(owsTitleList[0].childNodes[0].data)
      wmtsIdentifierList.append(owsIdentifier[0].childNodes[0].data)
      wmtsFormatList.append(imgformatList[0].childNodes[0].data)
      #self.WMTSDia.comboBox.insertItem(i, owsTitleList[0].childNodes[0].data) 
      #i+=1

    self.WMTSDia.tableWidget_4.insertRow( self.WMTSDia.tableWidget_4.rowCount() )
    self.WMTSDia.tableWidget_4.setItem(self.WMTSDia.tableWidget_4.rowCount()-1, 1, QtGui.QTableWidgetItem(wmtsTitleList[self.WMTSDia.comboBox.currentIndex()]))
    self.WMTSDia.tableWidget_4.setItem(self.WMTSDia.tableWidget_4.rowCount()-1, 0, QtGui.QTableWidgetItem(wmtsIdentifierList[self.WMTSDia.comboBox.currentIndex()]))
    wmtsUrl = 'contextualWMSLegend=0&crs=EPSG:3857&dpiMode=7&featureCount=10&format=' + wmtsFormatList[self.WMTSDia.comboBox.currentIndex()] + '&layers=' + wmtsIdentifierList[self.WMTSDia.comboBox.currentIndex()] + '&styles=default&tileMatrixSet=GoogleMapsCompatible&url=' + WMTSURLList[self.WMTSDia.comboBox_2.currentIndex()][1]
    #sm = '111' +WMTSURLList[self.WMTSDia.comboBox_2.currentIndex()][1]
    #QMessageBox.information(self.iface.mainWindow(), "mes".decode('utf-8'), sm)
    self.WMTSDia.tableWidget_4.setItem(self.WMTSDia.tableWidget_4.rowCount()-1, 2, QtGui.QTableWidgetItem(wmtsUrl))

  def loadWMTS_2(self):
    if self.WMTSDia.tableWidget_4.currentRow() != -1:
      #urlWithParams = 'contextualWMSLegend=0&crs=EPSG:3857&dpiMode=7&featureCount=10&format=image/jpeg&layers=JM20K_1904&styles=default&tileMatrixSet=GoogleMapsCompatible&url=http://gis.sinica.edu.tw/tileserver/wmts'
      urlWithParams = self.WMTSDia.tableWidget_4.item(self.WMTSDia.tableWidget_4.currentRow(), 2).text()
      rlayer = QgsRasterLayer(urlWithParams, self.WMTSDia.tableWidget_4.item(self.WMTSDia.tableWidget_4.currentRow(), 1).text(), 'wms')
      QgsMapLayerRegistry.instance().addMapLayer(rlayer)   

  def WMTScls(self):
    self.WMTSDia.comboBox.clear()

  def getWMTSList(self):
    #QMessageBox.information(self.iface.mainWindow(), "mes".decode('utf-8'), self.WMTSDia.lineEdit_4.text())
    
    self.WMTSDia.comboBox.clear()
    i=0
    filePath = rootPath + 'DefaultWMTS_Url.csv'
    WMTSURLListfile = open(filePath, 'r')
    #WMTSURLListfile = open('C:/data/DefaultWMTS_Url.csv', 'r')
    csvCursor = csv.reader(WMTSURLListfile)
    WMTSURLList = []
    for row in csvCursor:
      WMTSURLList.append(row)

    #for i in range(len(WMTSURLList)):
      #self.WMTSDia.comboBox_2.insertItem(i, WMTSURLList[i][0].decode('utf-8'))

    response = urllib2.urlopen(WMTSURLList[self.WMTSDia.comboBox_2.currentIndex()][1])
    xmlDoc = xml.dom.minidom.parse(response)
    root = xmlDoc.documentElement
    layerList =  root.getElementsByTagName('Layer')
    #QMessageBox.information(self.iface.mainWindow(), "mes", layerList[0].childNodes[0].data)
    #for content in contentList:
      #layerList   = contentList.getElementsByTagName('Layer')
      #QMessageBox.information(self.iface.mainWindow(), "mes", "111")
      #self.WMTSDia.comboBox.insertItem(i, owsTitilList[i].childNodes[0].data)
    for layer in layerList:
      owsTitleList = layer.getElementsByTagName('ows:Title')
      #owsIdentifier = layer.getElementsByTagName('ows:Identifier')
      #imgformatList = layer.getElementsByTagName('Format')
      self.WMTSDia.comboBox.insertItem(i, owsTitleList[0].childNodes[0].data) 
      i+=1

  def openWMTSDia(self):
    
    #for i in range(self.WMTSDia.tableWidget_3.rowCount()-1, -1, -1):
      #self.WMTSDia.tableWidget_3.removeRow(i)
    self.WMTSDia.comboBox_2.clear()
    filePath = rootPath + 'DefaultWMTS_Url.csv'
    WMTSURLListfile = open(filePath, 'r')
    #WMTSURLListfile = open('C:/data/DefaultWMTS_Url.csv', 'r')
    csvCursor = csv.reader(WMTSURLListfile)
    WMTSURLList = []
    for row in csvCursor:
      WMTSURLList.append(row)

    for i in range(len(WMTSURLList)):
      self.WMTSDia.comboBox_2.insertItem(i, WMTSURLList[i][0].decode('utf-8'))
      #self.WMTSDia.tableWidget_3.insertRow( self.WMTSDia.tableWidget_3.rowCount() )
      #self.WMTSDia.tableWidget_3.setItem(self.WMTSDia.tableWidget_3.rowCount()-1, 0, QtGui.QTableWidgetItem(WMTSList[i][0].decode('utf-8')))
      #self.WMTSDia.tableWidget_3.setItem(self.WMTSDia.tableWidget_3.rowCount()-1, 1, QtGui.QTableWidgetItem(WMTSList[i][1].decode('utf-8')))
      #self.WMTSDia.tableWidget_3.setItem(self.WMTSDia.tableWidget_3.rowCount()-1, 2, QtGui.QTableWidgetItem(WMTSList[i][2].decode('utf-8')))

    for i in range(self.WMTSDia.tableWidget_4.rowCount()-1, -1, -1):
      self.WMTSDia.tableWidget_4.removeRow(i)
    filePath = rootPath + 'DefaultWMTS_Layer.csv'
    WMTSDefaultListFile = open(filePath, 'r')
    #WMTSDefaultListFile = open('C:/data/DefaultWMTS_Layer.csv', 'r')
    csvCursor = csv.reader(WMTSDefaultListFile)
    WMTSDefaultList = []
    for row in csvCursor:
      WMTSDefaultList.append(row)

    for i in range(len(WMTSDefaultList)):
      self.WMTSDia.tableWidget_4.insertRow( self.WMTSDia.tableWidget_4.rowCount() )
      self.WMTSDia.tableWidget_4.setItem(self.WMTSDia.tableWidget_4.rowCount()-1, 0, QtGui.QTableWidgetItem(WMTSDefaultList[i][0].decode('utf-8')))
      self.WMTSDia.tableWidget_4.setItem(self.WMTSDia.tableWidget_4.rowCount()-1, 1, QtGui.QTableWidgetItem(WMTSDefaultList[i][1].decode('utf-8')))
      self.WMTSDia.tableWidget_4.setItem(self.WMTSDia.tableWidget_4.rowCount()-1, 2, QtGui.QTableWidgetItem(WMTSDefaultList[i][2].decode('utf-8')))
    
    self.WMTSDia.show()

  def gpx2shp_show(self):
    self.gpx2shpDia.show()

    
  def getTownCode(self, countyID):
    self.cadastreDia.comboBox_3.clear()
    self.cadastreDia.comboBox_2.clear()
    self.cadastreDia.listWidget.clear()
    self.cadastreDia.tableWidget.clearContents()
    self.cadastreDia.tableWidget_2.clearContents()
    self.cadastreDia.tableWidget_3.clearContents()
    self.cadastreDia.tableWidget_4.clearContents()

    self.cadastreDia.comboBox_2.insertItem(0, '請選擇鄉鎮'.decode('utf-8'))
    countyToTownUrl = 'http://maps.nlsc.gov.tw/T09/pro/setArea.jsp?city=' + countyID
    response = urllib2.urlopen(countyToTownUrl)
    xmlDoc = xml.dom.minidom.parse(response)
    root = xmlDoc.documentElement
    nameList = root.getElementsByTagName('name')
    countyIDList = root.getElementsByTagName('id')

    countyList = []
    for i in range(0, len(root.getElementsByTagName('name')), 1):
      name = nameList[i]
      countyID = countyIDList[i]
      county = countyID.childNodes[0].data + '-' + name.childNodes[0].data
      countyList.append(county)

    countyList.sort()
    for i in range(0, len(countyList), 1):    
      self.cadastreDia.comboBox_2.insertItem(i+1, countyList[i])

  def countyToTown(self):
    #QMessageBox.information(self.iface.mainWindow(), "html", self.cadastreDia.comboBox.currentText())
    self.cadastreDia.listWidget.clear()
    self.cadastreDia.listWidget_2.clear()    
    self.cadastreDia.comboBox_5.clear()

    if self.cadastreDia.comboBox.currentIndex() == 0:
      self.cadastreDia.comboBox_2.clear()
      self.cadastreDia.comboBox_2.setEnabled(False)
      self.cadastreDia.comboBox_3.clear()
      self.cadastreDia.comboBox_3.setEnabled(False)

    else:
      self.getTownCode(self.cadastreDia.comboBox.currentText()[0])
      self.cadastreDia.comboBox_2.setEnabled(True)
      #self.cadastreDia.comboBox.setCurrentIndex(0)

  def townToCadastre(self):
    self.cadastreDia.listWidget.clear()
    self.cadastreDia.listWidget_2.clear()    
    self.cadastreDia.comboBox_5.clear()

    if self.cadastreDia.comboBox_2.currentIndex() == 0:
      self.cadastreDia.comboBox_3.clear()
      self.cadastreDia.comboBox_3.setEnabled(False)
      #self.cadastreDia.listWidget_2.clear()
    else:
      townID = self.cadastreDia.comboBox_2.currentText()[0] + self.cadastreDia.comboBox_2.currentText()[1] + self.cadastreDia.comboBox_2.currentText()[2]
      self.getCadastreCode(self.cadastreDia.comboBox.currentText()[0], townID)
      self.cadastreDia.comboBox_3.setEnabled(True)

  def cadastreToNo(self):
    self.cadastreDia.listWidget.clear()
    self.cadastreDia.listWidget_2.clear()
    self.cadastreDia.comboBox_5.clear()

  def getCadastreCode(self, countyID, townID):
    self.cadastreDia.comboBox_3.clear()
    self.cadastreDia.listWidget.clear()
    townToCadastreUrl = 'http://maps.nlsc.gov.tw/T09/pro/setSection.jsp?city=' + countyID.encode('utf-8') + '&area=' + townID.encode('utf-8')
    #QMessageBox.information(self.iface.mainWindow(), "html",   townToCadastreUrl)
    response = urllib2.urlopen(townToCadastreUrl)
    xmlDoc = xml.dom.minidom.parse(response)
    root = xmlDoc.documentElement
    nameList = root.getElementsByTagName('name')
    countyIDList = root.getElementsByTagName('id')
    officeIDList = root.getElementsByTagName('office')

    cadastreNameList=[]
    for i in range(0, len(root.getElementsByTagName('name')), 1):
      name = nameList[i]
      countyID = countyIDList[i]
      officeID = officeIDList[i]
      cadastreName = officeID.childNodes[0].data + countyID.childNodes[0].data + '-' + name.childNodes[0].data
      cadastreNameList.append(cadastreName)
   
    cadastreNameList.sort()

    for i in range(0, len(cadastreNameList), 1):    
      self.cadastreDia.comboBox_3.insertItem(i, cadastreNameList[i])

  def changeCRS(self):

    if self.cadastreDia.comboBox_4.currentIndex()==1:
      #crs = QgsCoordinateReferenceSystem(4326, QgsCoordinateReferenceSystem.EpsgCrsId)
      crs=QgsCoordinateReferenceSystem("epsg:4326")
      self.cadastreDia.lineEdit_2.setText("121.612359")
      self.cadastreDia.lineEdit_3.setText("25.04219")

    if self.cadastreDia.comboBox_4.currentIndex()==0:
      #crs = QgsCoordinateReferenceSystem(3826, QgsCoordinateReferenceSystem.EpsgCrsId) 
      crs=QgsCoordinateReferenceSystem("epsg:3826")    
      self.cadastreDia.lineEdit_2.setText("311791.151")
      self.cadastreDia.lineEdit_3.setText("2770590.391")      


  def changeQueryMode(self):
    #urii = "http://localhost/c.php?LD=AA&SCNO=0001&PO=00010000"
    #self.iface.addVectorLayer(urii, "WFSLayerName", "ogr")

    if self.cadastreDia.checkBox.isChecked():
      self.cadastreDia.lineEdit_2.setEnabled(False)
      self.cadastreDia.lineEdit_3.setEnabled(False)
      self.pointEmitter = QgsMapToolEmitPoint(self.iface.mapCanvas())
      QObject.connect( self.pointEmitter, SIGNAL("canvasClicked(const QgsPoint, Qt::MouseButton)"), self.clickNow_3)
      self.iface.mapCanvas().setMapTool( self.pointEmitter ) 
    else:
      self.cadastreDia.lineEdit_2.setEnabled(True)
      self.cadastreDia.lineEdit_3.setEnabled(True)      
      self.iface.mapCanvas().unsetMapTool( self.pointEmitter )

  def clickNow_3(self, event):
      self.cadastreDia.lineEdit_2.setText(str(event.x()))
      self.cadastreDia.lineEdit_3.setText(str(event.y()))

  '''
  def loadMulti(self):
    if self.cadastreDia.checkBox_2.isChecked():
      self.cadastreDia.lineEdit_4.setEnabled(False)
      self.cadastreDia.pushButton_4.setEnabled(False)
      self.cadastreDia.pushButton_5.setEnabled(True)
      self.cadastreDia.label_8.setEnabled(False)
      self.cadastreDia.groupBox.setEnabled(False)
      self.cadastreDia.tabWidget_2.setEnabled(False)
      self.cadastre_reset()
      self.cadastreDia.listWidget.setSelectionMode(QtGui.QAbstractItemView.MultiSelection)
      for i in range(self.cadastreDia.listWidget.count()):
        item = self.cadastreDia.listWidget.item(i)
        self.cadastreDia.listWidget.setItemSelected(item, False)  

    else:
      self.cadastreDia.lineEdit_4.setEnabled(True)
      self.cadastreDia.pushButton_4.setEnabled(True)
      self.cadastreDia.pushButton_5.setEnabled(False)
      self.cadastreDia.label_8.setEnabled(True)
      self.cadastreDia.groupBox.setEnabled(True)
      self.cadastreDia.tabWidget_2.setEnabled(True)
      self.cadastreDia.listWidget.setSelectionMode(QtGui.QAbstractItemView.SingleSelection)
      for i in range(self.cadastreDia.listWidget.count()):
        item = self.cadastreDia.listWidget.item(i)
        self.cadastreDia.listWidget.setItemSelected(item, False)      
  '''
  def loadMultiCadastre(self):

    ### 讀取php所在位址 ###
    filePath = rootPath + 'cadastreService.csv'
    #QMessageBox.information(self.iface.mainWindow(), "X", filePath)
    urlPathfile = open(filePath, 'r')
    csvCursor = csv.reader(urlPathfile)
    urlPathList = []
    for row in csvCursor:
        urlPathList.append(row)

    unit = self.cadastreDia.comboBox_3.currentText()[0] + self.cadastreDia.comboBox_3.currentText()[1] 
    sec  = self.cadastreDia.comboBox_3.currentText()[2] + self.cadastreDia.comboBox_3.currentText()[3] + self.cadastreDia.comboBox_3.currentText()[4] + self.cadastreDia.comboBox_3.currentText()[5] 

    no = []
    for i in range(0, self.cadastreDia.listWidget_2.count(), 1):  
      no.append(self.cadastreDia.listWidget_2.item(i).text())
      #self.cadastreDia.comboBox_5.insertItem(i, self.cadastreDia.listWidget_2.item(i).text())
    #no = self.cadastreDia.listWidget.selectedItems()

    #QMessageBox.information(self.iface.mainWindow(), "num".decode('utf-8'), sec)
    #no   = self.cadastreDia.lineEdit_4.text()

    url_1 = urlPathList[0][1] + 'QueryByUnit.php?unit=' + unit 
    response_1 = urllib2.urlopen(url_1)
    html_1 = response_1.read().decode('utf-8')
    j_1 = json.loads(html_1)
    j_1_dict = {}

    j_1_keys = range(len(j_1['RESPONSE'][0]['SECTION']))
    for i in j_1_keys:
      j_1_dict[i] = j_1['RESPONSE'][0]['SECTION'][i]['SEC']

    j_1_dict_invert = {v: k for k, v in j_1_dict.items()}

    #AA06_str = j_reason_1['RESPONSE'][0]['DATA'][j_1_dict_invert.get(sec)]['NAME']
    ### check if feature exist ###


    #####
    for i in range(0, len(no), 1):
      uri = urlPathList[0][1] + 'landWFS3.php?LD=' + unit + '&SCNO=' + sec + '&PO=' + no[i]
      
      nameBase = unit + sec + j_1['RESPONSE'][0]['SECTION'][j_1_dict_invert.get(sec)]['NAME']
      WFSLayerName = nameBase + '-' +  no[i]

      response = urllib2.urlopen(uri)
      html = response.read().decode('utf-8')

      #self.iface.addVectorLayer(uri, '', "ogr") 
      #self.iface.activeLayer().setLayerName(WFSLayerName)
      #QMessageBox.information(self.iface.mainWindow(), "錯誤".decode('utf-8'), uri.decode('utf-8'))

      self.iface.addVectorLayer(uri, '', "ogr") 
      self.iface.activeLayer().setLayerName(WFSLayerName)

      shpName = "%s%s%s%s"%(rootPath, 'temp/', WFSLayerName, '.shp')
      #QMessageBox.information(self.iface.mainWindow(), "name".decode('utf-8'), shpName)

      _writer = QgsVectorFileWriter.writeAsVectorFormat(self.iface.activeLayer(), shpName, "utf-8", self.iface.activeLayer().crs(), "ESRI Shapefile")
      QgsMapLayerRegistry.instance().removeMapLayer(self.iface.activeLayer().id())
      self.iface.addVectorLayer(shpName, WFSLayerName, "ogr")

      pr = self.iface.activeLayer().dataProvider()

      features = self.iface.activeLayer().getFeatures() #returns QgsFeature object
      for feature in features:
        geom = feature.geometry()

      pr.addAttributes( [ QgsField("Name", QVariant.String), QgsField("No", QVariant.String) ] )
      self.iface.activeLayer().updateFields() 

      with edit(self.iface.activeLayer()):   
        for feat in self.iface.activeLayer().getFeatures():
          self.iface.activeLayer().deleteFeature(feat.id())             

      pt = QgsFeature()
      pt.setGeometry(geom)
      attr = []
      attr.append('1')
      attr.append(nameBase)
      attr.append(no[i])
      pt.setAttributes(attr)
      pr.addFeatures([pt])

      self.iface.activeLayer().updateExtents()


      self.canvas.zoomToFullExtent()
      msg = WFSLayerName + '載入完成'.decode('utf-8')
      self.iface.mainWindow().statusBar().showMessage(msg)

    self.cadastrePosition(unit, sec, no[0])

  def updateCadastreInfo(self):
    unit = self.cadastreDia.comboBox_3.currentText()[0] + self.cadastreDia.comboBox_3.currentText()[1] 
    sec  = self.cadastreDia.comboBox_3.currentText()[2] + self.cadastreDia.comboBox_3.currentText()[3] + self.cadastreDia.comboBox_3.currentText()[4] + self.cadastreDia.comboBox_3.currentText()[5]     
    no   = self.cadastreDia.comboBox_5.currentText()
    self.cadastrePosition(unit, sec, no)

  def cadastrePosition(self, unit, sec, no):

    ### 讀取php所在位址 ###
    filePath = rootPath + 'cadastreService.csv'
    #QMessageBox.information(self.iface.mainWindow(), "X", filePath)
    urlPathfile = open(filePath, 'r')
    csvCursor = csv.reader(urlPathfile)
    urlPathList = []
    for row in csvCursor:
        urlPathList.append(row)

    #unit = self.cadastreDia.comboBox_3.currentText()[0] + self.cadastreDia.comboBox_3.currentText()[1] 
    #sec  = self.cadastreDia.comboBox_3.currentText()[2] + self.cadastreDia.comboBox_3.currentText()[3] + self.cadastreDia.comboBox_3.currentText()[4] + self.cadastreDia.comboBox_3.currentText()[5] 
    #no   = self.cadastreDia.lineEdit_4.text()

    ### check if feature exist ###
    uri = urlPathList[0][1] + 'landWFS3.php?LD=' + unit + '&SCNO=' + sec + '&PO=' + no
    response = urllib2.urlopen(uri)
    html = response.read().decode('utf-8')

    if html.find('COP') != -1:
      pass
      #QMessageBox.information(self.iface.mainWindow(), "錯誤".decode('utf-8'), "查無此地號地籍圖".decode('utf-8'))

    else:

      ### 土地標示部 LandDescription ###
      url_1 =  urlPathList[0][1] + 'LandDescription.php?unit=' + unit + '&sec=' + sec + '&no=' + no
      #QMessageBox.information(self.iface.mainWindow(),"x",  url_1)

      response_1 = urllib2.urlopen(url_1)
      html_1 = response_1.read().decode('utf-8')

      if html_1.find('COP') != -1:
        #QMessageBox.information(self.iface.mainWindow(), "錯誤".decode('utf-8'), "查無此地號地籍土地標示部".decode('utf-8'))
        pass

      else:
        j_1 = json.loads(html_1)

        county_r = j_1['RESPONSE'][0]['RALID']['AA45']
        town_r = j_1['RESPONSE'][0]['RALID']['AA46']
        unit_r = j_1['RESPONSE'][0]['UNIT']
        sec_r = j_1['RESPONSE'][0]['SEC']
        no_r = j_1['RESPONSE'][0]['NO']

        townID_r = county_r+town_r

        townToCadastreUrl = 'http://maps.nlsc.gov.tw/T09/pro/setSection.jsp?city=' + county_r.encode('utf-8') + '&area=' + townID_r.encode('utf-8')

        #QMessageBox.information(self.iface.mainWindow(), "html",   townToCadastreUrl)
        response = urllib2.urlopen(townToCadastreUrl)
        xmlDoc = xml.dom.minidom.parse(response)
        root = xmlDoc.documentElement
        nameList = root.getElementsByTagName('name')
        idList = root.getElementsByTagName('id')
        #officeIDList = root.getElementsByTagName('office')

        nameNameList=[]
        ididList=[]
        for i in range(0, len(root.getElementsByTagName('name')), 1):
          ididList.append(idList[i].childNodes[0].data)
          nameNameList.append(nameList[i].childNodes[0].data)
        
        nameBase = unit_r + sec_r + nameNameList[ididList.index(sec_r.encode('utf-8'))]
        WFSLayerName = nameBase + '-' +  no_r

        #QMessageBox.information(self.iface.mainWindow(), "錯誤".decode('utf-8'), uri.decode('utf-8'))
        response = urllib2.urlopen(uri)
        html = response.read().decode('utf-8')

        #QMessageBox.information(self.iface.mainWindow(), "錯誤".decode('utf-8'), WFSLayerName[WFSLayerName.find('-'):WFSLayerName.find('_')])

        #self.iface.addVectorLayer(uri, '', "ogr") 
        #self.iface.activeLayer().setLayerName('WFSLayerName')

        #shpName = "%s%s%s%s"%(rootPath, 'temp/', WFSLayerName, '.shp')
        #QMessageBox.information(self.iface.mainWindow(), "name".decode('utf-8'), shpName)

        #_writer = QgsVectorFileWriter.writeAsVectorFormat(self.iface.activeLayer(), shpName, "utf-8", self.iface.activeLayer().crs(), "ESRI Shapefile")
        #QgsMapLayerRegistry.instance().removeMapLayer(self.iface.activeLayer().id())
        #self.iface.addVectorLayer(shpName, WFSLayerName, "ogr")
        

        #self.iface.setActiveLayer(target_layer)         
        #pr = self.iface.activeLayer().dataProvider()

        #features = self.iface.activeLayer().getFeatures() #returns QgsFeature object
        #for feature in features:
          #geom = feature.geometry()

        #pr.addAttributes( [ QgsField("Name", QVariant.String), QgsField("No", QVariant.String) ] )
        #self.iface.activeLayer().updateFields() 

        #with edit(self.iface.activeLayer()):   
          #for feat in self.iface.activeLayer().getFeatures():
            #self.iface.activeLayer().deleteFeature(feat.id())             

        #pt = QgsFeature()
        #pt.setGeometry(geom)
        #attr = []
        #attr.append('1')
        #attr.append(nameBase)
        #attr.append(no)
        #pt.setAttributes(attr)
        #pr.addFeatures([pt])

        #self.iface.activeLayer().updateExtents()


        #self.canvas.setExtent(self.iface.activeLayer().extent())
        #msg = WFSLayerName + '載入完成'.decode('utf-8')
        #self.iface.mainWindow().statusBar().showMessage(msg)
        #QMessageBox.information(self.iface.mainWindow(), '載入完成'.decode('utf-8'),  msg)
        

        if j_1['RESPONSE'][0]['RALID']!=NULL:

          ### 登記日期_年, 月, 日 ###
          AA05 = j_1['RESPONSE'][0]['RALID']['AA05']
          AA05_str = AA05[0:3] + '年'.decode('utf-8') + AA05[3:5] + '月'.decode('utf-8') + AA05[5:7] + '日'.decode('utf-8')        

          ### 登記原因 ####
          AA06 = j_1['RESPONSE'][0]['RALID']['AA06']

          url_reason_1 =  urlPathList[0][1] + 'QueryReason.php?UNIT=' + unit
          response_reason_1 = urllib2.urlopen(url_reason_1)
          html_reason_1 = response_reason_1.read().decode('utf-8')
          j_reason_1 = json.loads(html_reason_1)

          reason_1_dict = {}

          reason_1_keys = range(len(j_reason_1['RESPONSE'][0]['DATA']))
          for i in reason_1_keys:
            reason_1_dict[i] = j_reason_1['RESPONSE'][0]['DATA'][i]['CODE']

          reason_1_dict_invert = {v: k for k, v in reason_1_dict.items()}
          #QMessageBox.information(self.iface.mainWindow(),"dict",  str(len(reason_2_dict)))
          #QMessageBox.information(self.iface.mainWindow(),"dict",  reason_2_dict[0][0])

          AA06_str = j_reason_1['RESPONSE'][0]['DATA'][reason_1_dict_invert.get(AA06)]['NAME']

          ### 面積 ###
          AA10 = j_1['RESPONSE'][0]['RALID']['AA10'] 

          ### 使用分區 ###
          AA11 = j_1['RESPONSE'][0]['RALID']['AA11']

          url_useZone_1 =  urlPathList[0][1] + 'QueryZone.php'
          response_useZone_1 = urllib2.urlopen(url_useZone_1)
          html_useZone_1 = response_useZone_1.read().decode('utf-8')
          j_useZone_1 = json.loads(html_useZone_1)

          useZone_1_dict = {}

          useZone_1_keys = range(len(j_useZone_1['RESPONSE']))
          for i in useZone_1_keys:
            useZone_1_dict[i] = j_useZone_1['RESPONSE'][i]['CODE']

          useZone_1_dict_invert = {v: k for k, v in useZone_1_dict.items()}
          #QMessageBox.information(self.iface.mainWindow(),"dict",  str(len(reason_2_dict)))
          #QMessageBox.information(self.iface.mainWindow(),"dict",  reason_2_dict[0][0])
          if useZone_1_dict_invert.get(AA11)!=None:
            AA11_str = j_useZone_1['RESPONSE'][useZone_1_dict_invert.get(AA11)]['NAME']
          else:
            AA11_str = ''

          ### 使用地類別 ###
          AA12 = j_1['RESPONSE'][0]['RALID']['AA12']

          ### 公告地現值 ###
          AA16 = j_1['RESPONSE'][0]['RALID']['AA16']

          ### 公告地價 ###
          AA17 = j_1['RESPONSE'][0]['RALID']['AA17']

          ### 縣市 ###
          AA45 = j_1['RESPONSE'][0]['RALID']['AA45']
          AA45_str = ''

          url_city_1 =  urlPathList[0][1] + 'QueryCity.php'
          response_city_1 = urllib2.urlopen(url_city_1)
          html_city_1 = response_city_1.read().decode('utf-8')
          j_city_1 = json.loads(html_city_1)

          city_1_dict = {}

          city_1_keys = range(len(j_city_1['RESPONSE']))
          for i in city_1_keys:
            city_1_dict[i] = j_city_1['RESPONSE'][i]['CODE']

          city_1_dict_invert = {v: k for k, v in city_1_dict.items()}
          #QMessageBox.information(self.iface.mainWindow(),"dict",  str(len(reason_2_dict)))
          #QMessageBox.information(self.iface.mainWindow(),"dict",  reason_2_dict[0][0])
          if city_1_dict_invert.get(AA45)!=None:
            AA45_str = j_city_1['RESPONSE'][city_1_dict_invert.get(AA45)]['NAME']
  
          ### 鄉鎮市區 ###
          AA46 = j_1['RESPONSE'][0]['RALID']['AA46']

          url_town_1 =  urlPathList[0][1] + 'QueryTown.php?city=' + AA45
          #QMessageBox.information(self.iface.mainWindow(),"dict",  url_town_1)
          response_town_1 = urllib2.urlopen(url_town_1)
          html_town_1 = response_town_1.read().decode('utf-8')
          j_town_1 = json.loads(html_town_1)

          town_1_dict = {}
          AA46_str = '' 

          town_1_keys = range(len(j_town_1['RESPONSE'][0]['TOWN']))
          for i in town_1_keys:
            town_1_dict[i] = j_town_1['RESPONSE'][0]['TOWN'][i]['CODE']

          town_1_dict_invert = {v: k for k, v in town_1_dict.items()}
          #QMessageBox.information(self.iface.mainWindow(),"dict",  str(len(reason_2_dict)))
          #QMessageBox.information(self.iface.mainWindow(),"dict",  reason_2_dict[0][0])
          if town_1_dict_invert.get(AA46)!=None:
            AA46_str = j_town_1['RESPONSE'][0]['TOWN'][town_1_dict_invert.get(AA46)]['NAME']

          ### 圖幅號 ###
          AA23 = j_1['RESPONSE'][0]['RALID']['AA23']

          ### 地上建物建號數量 ###
          BUILDINGCOUNT = j_1['RESPONSE'][0]['RALID']['BUILDINGCOUNT']

          url_1_1 =  urlPathList[0][1] + 'QueryReason.php?UNIT=' + unit
          #url_1_1 = 'http://140.109.161.72/QueryReason.php?UNIT=' + unit
          #QMessageBox.information(self.iface.mainWindow(),"x",  url_1)

          self.cadastreDia.tableWidget_2.setItem(0,  0, QtGui.QTableWidgetItem(nameBase))
          self.cadastreDia.tableWidget_2.setItem(0,  1, QtGui.QTableWidgetItem(no))
          self.cadastreDia.tableWidget_2.setItem(0,  2, QtGui.QTableWidgetItem(AA05_str))
          self.cadastreDia.tableWidget_2.setItem(0,  3, QtGui.QTableWidgetItem(AA06_str))
          self.cadastreDia.tableWidget_2.setItem(0,  4, QtGui.QTableWidgetItem(AA10))
          self.cadastreDia.tableWidget_2.setItem(0,  5, QtGui.QTableWidgetItem(AA11_str))    
          self.cadastreDia.tableWidget_2.setItem(0,  6, QtGui.QTableWidgetItem(AA12))
          self.cadastreDia.tableWidget_2.setItem(0,  7, QtGui.QTableWidgetItem(AA16))
          self.cadastreDia.tableWidget_2.setItem(0,  8, QtGui.QTableWidgetItem(AA17))
          self.cadastreDia.tableWidget_2.setItem(0,  9, QtGui.QTableWidgetItem(AA45_str))
          self.cadastreDia.tableWidget_2.setItem(0, 10, QtGui.QTableWidgetItem(AA46_str))
          self.cadastreDia.tableWidget_2.setItem(0, 11, QtGui.QTableWidgetItem(AA23))
          self.cadastreDia.tableWidget_2.setItem(0, 12, QtGui.QTableWidgetItem(BUILDINGCOUNT))

          self.cadastreDia.tableWidget_2.resizeColumnsToContents()
   
      ### 地籍土地所有權部 LandOwnership ###
      self.cadastreDia.tableWidget.setItem(0, 0, QtGui.QTableWidgetItem(self.cadastreDia.comboBox_3.currentText()))
      self.cadastreDia.tableWidget.setItem(0, 1, QtGui.QTableWidgetItem(no))

      url_2 =  urlPathList[0][1] + 'LandOwnership.php?UNIT=' + unit + '&SEC=' + sec + '&NO=' + no + '&OFFSET=1&LIMIT=10'
      #url_2 = 'http://140.109.161.72/LandOwnership.php?UNIT=' + unit + '&SEC=' + sec + '&NO=' + no + '&OFFSET=1&LIMIT=10'
      #QMessageBox.information(self.iface.mainWindow(),"x",  url_2)

      response_2 = urllib2.urlopen(url_2)
      html_2 = response_2.read().decode('utf-8')

      if html_2.find('COP') != -1:
        #QMessageBox.information(self.iface.mainWindow(), "錯誤".decode('utf-8'), "查無此地號地籍土地所有權部".decode('utf-8'))
        pass

      else:      
        j_2 = json.loads(html_2)

        if j_2['RETURNROWS']!=0:
          #j_3_count = len(j_3['RESPONSE'][0]['RCLOR'])
          j_2_count = len(j_2['RESPONSE'])
          rowPosition = self.cadastreDia.tableWidget.rowCount()

          self.cadastreDia.tableWidget.setColumnCount(j_2_count)

          for i in range(0, j_2_count, 1):

            if j_2['RESPONSE']!=NULL: 
              if len(j_2['RESPONSE'][i]['RBLOW'])!=0:

                #登記日期_年, 月, 日  
                BB05 = j_2['RESPONSE'][i]['RBLOW'][0]['BB05']
                BB05_str = BB05[0:3] + '年'.decode('utf-8') + BB05[3:5] + '月'.decode('utf-8') + BB05[5:7] + '日'.decode('utf-8')

                #登記原因
                BB06 = j_2['RESPONSE'][i]['RBLOW'][0]['BB06']

                url_reason_2 =  urlPathList[0][1] + 'QueryReason.php?UNIT=' + unit
                response_reason_2 = urllib2.urlopen(url_reason_2)
                html_reason_2 = response_reason_2.read().decode('utf-8')
                j_reason_2 = json.loads(html_reason_2)

                reason_2_dict = {}

                reason_2_keys = range(len(j_reason_2['RESPONSE'][0]['DATA']))
                for p in reason_2_keys:
                  reason_2_dict[p] = j_reason_2['RESPONSE'][0]['DATA'][p]['CODE']


                reason_2_dict_invert = {v: k for k, v in reason_2_dict.items()}
                #QMessageBox.information(self.iface.mainWindow(),"dict",  str(len(reason_2_dict)))
                #QMessageBox.information(self.iface.mainWindow(),"dict",  reason_2_dict[0][0])

                BB06_str = j_reason_2['RESPONSE'][0]['DATA'][reason_2_dict_invert.get(BB06)]['NAME']
                #BB06_str = j_reason_2['RESPONSE'][0]['DATA'][int(BB06)]['NAME']

                #登記原因發生日期
                BB07 = j_2['RESPONSE'][i]['RBLOW'][0]['BB07']
                BB07_str = BB07[0:3] + '年'.decode('utf-8') + BB07[3:5] + '月'.decode('utf-8') + BB07[5:7] + '日'.decode('utf-8')

                #權利範圍類別
                url_rights_2 =  urlPathList[0][1] + 'QueryRights.php'
                response_rights_2 = urllib2.urlopen(url_rights_2)
                html_rights_2 = response_rights_2.read().decode('utf-8')
                j_rights_2 = json.loads(html_rights_2)

                BB15_1 = j_2['RESPONSE'][i]['RBLOW'][0]['BB15_1']

                #rights_2 = {'A': 0, 'B': 1, 'C': 2, 'Z': 3}
                #rights_2_dict = j_righst_2['RESPONSE']

                rights_2_dict = {}
                rights_2_keys = range(len(j_rights_2['RESPONSE']))
                for m in rights_2_keys:
                  rights_2_dict[m] = j_rights_2['RESPONSE'][m]['CODE']

                #rights_2_dict_invert = {}
                rights_2_dict_invert = {v: k for k, v in rights_2_dict.items()}

                if rights_2_dict_invert.get(BB15_1)!=None:
                  BB15_1_str = j_rights_2['RESPONSE'][rights_2_dict_invert.get(BB15_1)]['NAME']
                else:
                  BB15_1_str=''

                #權利範圍分母
                BB15_2 = j_2['RESPONSE'][i]['RBLOW'][0]['BB15_2']

                #權利範圍分子
                BB15_3 = j_2['RESPONSE'][i]['RBLOW'][0]['BB15_3']

                #權狀年期
                BB03 = j_2['RESPONSE'][i]['RBLOW'][0]['BB03']
                if BB03 !=NULL:
                  BB03_str = BB03[0:3] + '年'.decode('utf-8') + BB03[3:5] + '月'.decode('utf-8') + BB03[5:7] + '日'.decode('utf-8')
                else:
                   BB03_str = BB03

                #權狀字
                BB04_1 = j_2['RESPONSE'][i]['RBLOW'][0]['BB04_1']

                #權狀號
                BB04_2 = j_2['RESPONSE'][i]['RBLOW'][0]['BB04_2']

                #申報地價
                BB21 = j_2['RESPONSE'][i]['RBLOW'][0]['BB21']

                self.cadastreDia.tableWidget.setItem( 0, i, QtGui.QTableWidgetItem(nameBase))
                self.cadastreDia.tableWidget.setItem( 1, i, QtGui.QTableWidgetItem(no))
                self.cadastreDia.tableWidget.setItem( 2, i, QtGui.QTableWidgetItem(BB05_str))
                self.cadastreDia.tableWidget.setItem( 3, i, QtGui.QTableWidgetItem(BB06_str))
                self.cadastreDia.tableWidget.setItem( 4, i, QtGui.QTableWidgetItem(BB07_str))
                self.cadastreDia.tableWidget.setItem( 5, i, QtGui.QTableWidgetItem(BB15_1_str))    
                self.cadastreDia.tableWidget.setItem( 6, i, QtGui.QTableWidgetItem(BB15_2))
                self.cadastreDia.tableWidget.setItem( 7, i, QtGui.QTableWidgetItem(BB15_3))
                self.cadastreDia.tableWidget.setItem( 8, i, QtGui.QTableWidgetItem(BB03))
                self.cadastreDia.tableWidget.setItem( 9, i, QtGui.QTableWidgetItem(BB04_1))
                self.cadastreDia.tableWidget.setItem(10, i, QtGui.QTableWidgetItem(BB04_2))
                self.cadastreDia.tableWidget.setItem(11, i, QtGui.QTableWidgetItem(BB04_2))

            else:
              self.cadastreDia.tableWidget.setColumnCount(1)

          self.cadastreDia.tableWidget.resizeColumnsToContents()




      ### 地籍土地他項權利部 LandOtherRights ###
      self.cadastreDia.tableWidget_3.setItem(0, 0, QtGui.QTableWidgetItem(self.cadastreDia.comboBox_3.currentText()))
      self.cadastreDia.tableWidget_3.setItem(0, 1, QtGui.QTableWidgetItem(no))
    
      url_3 = urlPathList[0][1] + 'LandOtherRights.php?UNIT=' + unit + '&SEC=' + sec + '&NO=' + no + '&OFFSET=1&LIMIT=10'
      #QMessageBox.information(self.iface.mainWindow(), "url_3",  url_3)

      response_3 = urllib2.urlopen(url_3)
      html_3 = response_3.read().decode('utf-8')

      if html_3.find('COP') != -1:
        #QMessageBox.information(self.iface.mainWindow(), "錯誤".decode('utf-8'), "查無此地號地籍土地所有權部".decode('utf-8'))
        pass

      else:
        j_3 = json.loads(html_3)

        if j_3['RETURNROWS']!=0:
          #j_3_count = len(j_3['RESPONSE'][0]['RCLOR'])
          j_3_count = len(j_3['RESPONSE'])
          rowPosition = self.cadastreDia.tableWidget_3.rowCount()

          self.cadastreDia.tableWidget_3.setColumnCount(j_3_count)

          for i in range(0, j_3_count, 1):
            #QMessageBox.information(self.iface.mainWindow(), "len".decode('utf-8'), str(len(j_3['RESPONSE'][i]['RCLOR'])))
            if j_3['RESPONSE']!=NULL: 
              if len(j_3['RESPONSE'][i]['RCLOR'])!=0:
                CC01 = j_3['RESPONSE'][i]['RCLOR'][0]['CC01']
                CC03 = j_3['RESPONSE'][i]['RCLOR'][0]['CC03']
                CC04_1 = j_3['RESPONSE'][i]['RCLOR'][0]['CC04_1']
                CC04_2 = j_3['RESPONSE'][i]['RCLOR'][0]['CC04_2']        

                ### 登記日期 ###
                CC05 = j_3['RESPONSE'][i]['RCLOR'][0]['CC05']
                CC05_str = CC05[0:3] + '年'.decode('utf-8') + CC05[3:5] + '月'.decode('utf-8') + CC05[5:7] + '日'.decode('utf-8')            

                ### 登記原因 ###
                CC06 = j_3['RESPONSE'][i]['RCLOR'][0]['CC06']

                url_reason_3 =  urlPathList[0][1] + 'QueryReason.php?UNIT=' + unit
                response_reason_3 = urllib2.urlopen(url_reason_3)
                html_reason_3 = response_reason_3.read().decode('utf-8')
                j_reason_3 = json.loads(html_reason_3)

                reason_3_dict = {}

                reason_3_keys = range(len(j_reason_3['RESPONSE'][0]['DATA']))
                for ii in reason_3_keys:
                  reason_3_dict[ii] = j_reason_3['RESPONSE'][0]['DATA'][ii]['CODE']

                reason_3_dict_invert = {v: k for k, v in reason_3_dict.items()}

                if rights_2_dict_invert.get(CC06)!=None:
                  CC06_str = j_reason_3['RESPONSE'][0]['DATA'][reason_3_dict_invert.get(CC06)]['NAME']
                else:
                  CC06_str=''
            
                ### 設定權利範圍類別 ###
                CC15_1 = j_3['RESPONSE'][i]['RCLOR'][0]['CC15_1']

                url_rights_3 =  urlPathList[0][1] + 'QueryRights.php'
                response_rights_3 = urllib2.urlopen(url_rights_3)
                html_rights_3 = response_rights_3.read().decode('utf-8')
                j_rights_3 = json.loads(html_rights_3)

                rights_3_dict = {}
                rights_3_keys = range(len(j_rights_3['RESPONSE']))
                for n in rights_3_keys:
                  rights_3_dict[n] = j_rights_3['RESPONSE'][n]['CODE']
  
                rights_3_dict_invert = {v: k for k, v in rights_3_dict.items()}

                if rights_3_dict_invert.get(CC15_1)!=None:
                  CC15_1_str = j_rights_3['RESPONSE'][rights_3_dict_invert.get(CC15_1)]['NAME']
                else:
                  CC15_1_str=''
            
                CC15_2 = j_3['RESPONSE'][i]['RCLOR'][0]['CC15_2']
                CC15_3 = j_3['RESPONSE'][i]['RCLOR'][0]['CC15_3']
                CC15_4 = j_3['RESPONSE'][i]['RCLOR'][0]['CC15_4']        
                CC16 = j_3['RESPONSE'][i]['RCLOR'][0]['CC16']

                ### 債權權利範圍類別 ###
                CC18_1 = j_3['RESPONSE'][i]['RCLOR'][0]['CC18_1']

                url_LoanRight_3 =  urlPathList[0][1] + 'QueryLoanRightsRange.php'
                response_LoanRight_3 = urllib2.urlopen(url_LoanRight_3)
                html_LoanRight_3 = response_LoanRight_3.read().decode('utf-8')
                j_LoanRight_3 = json.loads(html_LoanRight_3)

                LoanRight_3_dict = {}
                LoanRight_3_keys = range(len(j_LoanRight_3['RESPONSE']))
                for m in LoanRight_3_keys:
                  LoanRight_3_dict[m] = j_LoanRight_3['RESPONSE'][m]['CODE']

                LoanRight_3_dict_invert = {v: k for k, v in LoanRight_3_dict.items()}

                if LoanRight_3_dict_invert.get(CC18_1)!=None:
                  CC18_1_str = j_LoanRight_3['RESPONSE'][LoanRight_3_dict_invert.get(CC18_1)]['NAME']
                else:
                  CC18_1_str=''

                CC18_2 = j_3['RESPONSE'][i]['RCLOR'][0]['CC18_2']        
                CC18_3 = j_3['RESPONSE'][i]['RCLOR'][0]['CC18_3']  

                ### 權利種類 ###
                CC27 = j_3['RESPONSE'][i]['RCLOR'][0]['CC27']

                url_rightstype_3 =  urlPathList[0][1] + 'QueryRightsAndTypes.php'
                response_rightstype_3 = urllib2.urlopen(url_rightstype_3)
                html_rightstype_3 = response_rightstype_3.read().decode('utf-8')
                j_rightstype_3 = json.loads(html_rightstype_3)

                rightstype_3_dict = {}
                rightstype_3_keys = range(len(j_rightstype_3['RESPONSE']))
                for o in rightstype_3_keys:
                  rightstype_3_dict[o] = j_rightstype_3['RESPONSE'][o]['CODE']

                rightstype_3_dict_invert = {v: k for k, v in rightstype_3_dict.items()}

                if rightstype_3_dict_invert.get(CC27)!=None:
                  CC27_str = j_rightstype_3['RESPONSE'][rightstype_3_dict_invert.get(CC27)]['NAME']
                else:
                  CC27_str=''                  
            
                ### 標的種類 ###
                CC28_1 = j_3['RESPONSE'][i]['RCLOR'][0]['CC28_1']

                url_goaltype_3 =  urlPathList[0][1] + 'QueryRightsAndTypes.php'
                response_goaltype_3 = urllib2.urlopen(url_goaltype_3)
                html_goaltype_3 = response_goaltype_3.read().decode('utf-8')
                j_goaltype_3 = json.loads(html_goaltype_3)
 
                goaltype_3_dict = {}
                goaltype_3_keys = range(len(j_goaltype_3['RESPONSE']))
                for p in goaltype_3_keys:
                  goaltype_3_dict[p] = j_goaltype_3['RESPONSE'][p]['CODE']

                goaltype_3_dict_invert = {v: k for k, v in goaltype_3_dict.items()}

                if goaltype_3_dict_invert.get(CC28_1)!=None:
                  CC28_1_str = j_goaltype_3['RESPONSE'][goaltype_3_dict_invert.get(CC28_1)]['NAME']
                else:
                  CC28_1_str=''              

                self.cadastreDia.tableWidget_3.setItem(0,  i, QtGui.QTableWidgetItem(nameBase))
                self.cadastreDia.tableWidget_3.setItem(1,  i, QtGui.QTableWidgetItem(no))
                self.cadastreDia.tableWidget_3.setItem(2,  i, QtGui.QTableWidgetItem(CC01))
                self.cadastreDia.tableWidget_3.setItem(3,  i, QtGui.QTableWidgetItem(CC03))
                self.cadastreDia.tableWidget_3.setItem(4,  i, QtGui.QTableWidgetItem(CC04_1))
                self.cadastreDia.tableWidget_3.setItem(5,  i, QtGui.QTableWidgetItem(CC04_2))
                self.cadastreDia.tableWidget_3.setItem(6,  i, QtGui.QTableWidgetItem(CC05_str))
                self.cadastreDia.tableWidget_3.setItem(7,  i, QtGui.QTableWidgetItem(CC06_str))
                self.cadastreDia.tableWidget_3.setItem(8,  i, QtGui.QTableWidgetItem(CC15_1_str))
                self.cadastreDia.tableWidget_3.setItem(9,  i, QtGui.QTableWidgetItem(CC15_2))
                self.cadastreDia.tableWidget_3.setItem(10, i, QtGui.QTableWidgetItem(CC15_3))
                self.cadastreDia.tableWidget_3.setItem(11, i, QtGui.QTableWidgetItem(CC15_4))
                self.cadastreDia.tableWidget_3.setItem(12, i, QtGui.QTableWidgetItem(CC16))
                self.cadastreDia.tableWidget_3.setItem(13, i, QtGui.QTableWidgetItem(CC18_1_str))
                self.cadastreDia.tableWidget_3.setItem(14, i, QtGui.QTableWidgetItem(CC18_2))
                self.cadastreDia.tableWidget_3.setItem(15, i, QtGui.QTableWidgetItem(CC18_3))
                self.cadastreDia.tableWidget_3.setItem(16, i, QtGui.QTableWidgetItem(CC27_str))
                self.cadastreDia.tableWidget_3.setItem(17, i, QtGui.QTableWidgetItem(CC28_1_str))

            else:
              self.cadastreDia.tableWidget_3.setColumnCount(1)
              

                   
          self.cadastreDia.tableWidget_3.resizeColumnsToContents()

        ### 地籍建物標示部 BuildingDescription ###
        self.cadastreDia.tableWidget_4.setItem(0, 0, QtGui.QTableWidgetItem(self.cadastreDia.comboBox_3.currentText()))
        self.cadastreDia.tableWidget_4.setItem(0, 1, QtGui.QTableWidgetItem(no))    

        url_4 =  urlPathList[0][1] + 'BuildingDescription.php?unit=' + unit + '&sec=' + sec + '&no=' + no
        response_4 = urllib2.urlopen(url_4)
        html_4 = response_4.read().decode('utf-8')
 
        if html_4.find('COP') != -1:
          #QMessageBox.information(self.iface.mainWindow(), "錯誤".decode('utf-8'), "查無此地號地籍建物標示部".decode('utf-8'))
          pass

        else:
          j_4 = json.loads(html_4)

          if j_4['RESPONSE'][0]['RDBID']!=NULL:
            DD05 = j_4['RESPONSE'][0]['RDBID']['DD05']  

            self.cadastreDia.tableWidget_4.setItem(0,  0, QtGui.QTableWidgetItem(nameBase))
            self.cadastreDia.tableWidget_4.setItem(0,  1, QtGui.QTableWidgetItem(no))
            self.cadastreDia.tableWidget_4.setItem(0,  2, QtGui.QTableWidgetItem(DD05))      

            self.cadastreDia.tableWidget_4.resizeColumnsToContents()
           #url_4 = 'http://140.109.161.72/BuildingDescription.php?unit=' + unit + '&sec=' + sec + '&no=' + no
           #QMessageBox.information(self.iface.mainWindow(),"x",  url_4)

   
    #self.cadastre_reset()
    self.cadastreDia.tabWidget.setCurrentIndex(2)

  def copyForm(self):

    if self.cadastreDia.tabWidget_2.currentIndex() == 0:
      rowCount = self.cadastreDia.tableWidget_2.rowCount()
      columnCount = self.cadastreDia.tableWidget_2.columnCount()

      #QMessageBox.information(self.iface.mainWindow(), "columnCount".decode('utf-8'), str(columnCount))
      #QMessageBox.information(self.iface.mainWindow(), "rowCount".decode('utf-8'), str(rowCount))

      clipboard = []

      for i in range(0, 1, 1):
        clipboard.append([])
        for j in range(0, rowCount, 1):
          clipboard[i].append(self.cadastreDia.tableWidget_2.verticalHeaderItem(j).text())

      for i in range(0, columnCount, 1):
        clipboard.append([])
        for j in range(0, rowCount, 1):
          if self.cadastreDia.tableWidget_4.item(j, i) != NULL:
            clipboard[i+1].append(self.cadastreDia.tableWidget_2.item(j, i).text())
          else:
            clipboard[i+1].append('')

      tempStr=''
      for j in range(0, rowCount, 1):
        tempStr += '\n'
        for i in range(0, len(clipboard), 1):
          tempStr += clipboard[i][j]
          tempStr += '\t'

      sys_clip = QtGui.QApplication.clipboard()
      sys_clip.setText(tempStr)

      #QMessageBox.information(self.iface.mainWindow(), "len(clipboard)".decode('utf-8'), str(len(clipboard)))
      #QMessageBox.information(self.iface.mainWindow(), "len(clipboard[1])".decode('utf-8'), str(len(clipboard[1])))
      #QMessageBox.information(self.iface.mainWindow(), "clipboard".decode('utf-8'), tempStr)      
      #QMessageBox.information(self.iface.mainWindow(), "clipboard".decode('utf-8'), '複製完成!'.decode('utf-8'))

    if self.cadastreDia.tabWidget_2.currentIndex() == 1:
      rowCount = self.cadastreDia.tableWidget.rowCount()
      columnCount = self.cadastreDia.tableWidget.columnCount()

      #QMessageBox.information(self.iface.mainWindow(), "columnCount".decode('utf-8'), str(columnCount))
      #QMessageBox.information(self.iface.mainWindow(), "rowCount".decode('utf-8'), str(rowCount))

      clipboard = []

      for i in range(0, 1, 1):
        clipboard.append([])
        for j in range(0, rowCount, 1):
          clipboard[i].append(self.cadastreDia.tableWidget.verticalHeaderItem(j).text())

      for i in range(0, columnCount, 1):
        clipboard.append([])
        for j in range(0, rowCount, 1):
          if self.cadastreDia.tableWidget_4.item(j, i) != NULL:
            clipboard[i+1].append(self.cadastreDia.tableWidget.item(j, i).text())
          else:
            clipboard[i+1].append('')

      tempStr=''
      for j in range(0, rowCount, 1):
        tempStr += '\n'
        for i in range(0, len(clipboard), 1):
          tempStr += clipboard[i][j]
          tempStr += '\t'

      sys_clip = QtGui.QApplication.clipboard()
      sys_clip.setText(tempStr)

      #QMessageBox.information(self.iface.mainWindow(), "len(clipboard)".decode('utf-8'), str(len(clipboard)))
      #QMessageBox.information(self.iface.mainWindow(), "len(clipboard[1])".decode('utf-8'), str(len(clipboard[1])))
      #QMessageBox.information(self.iface.mainWindow(), "clipboard".decode('utf-8'), tempStr)      
      #QMessageBox.information(self.iface.mainWindow(), "clipboard".decode('utf-8'), '複製完成!'.decode('utf-8'))
    
    if self.cadastreDia.tabWidget_2.currentIndex() == 2:
      rowCount = self.cadastreDia.tableWidget_3.rowCount()
      columnCount = self.cadastreDia.tableWidget_3.columnCount()

      #QMessageBox.information(self.iface.mainWindow(), "columnCount".decode('utf-8'), str(columnCount))
      #QMessageBox.information(self.iface.mainWindow(), "rowCount".decode('utf-8'), str(rowCount))

      clipboard = []

      for i in range(0, 1, 1):
        clipboard.append([])
        for j in range(0, rowCount, 1):
          clipboard[i].append(self.cadastreDia.tableWidget_3.verticalHeaderItem(j).text())

      for i in range(0, columnCount, 1):
        clipboard.append([])
        for j in range(0, rowCount, 1):
          if self.cadastreDia.tableWidget_3.item(j, i) != NULL:
            clipboard[i+1].append(self.cadastreDia.tableWidget_3.item(j, i).text())
          else:
            clipboard[i+1].append('')

      tempStr=''
      for j in range(0, rowCount, 1):
        tempStr += '\n'
        for i in range(0, len(clipboard), 1):
          tempStr += clipboard[i][j]
          tempStr += '\t'

      sys_clip = QtGui.QApplication.clipboard()
      sys_clip.setText(tempStr)

      #QMessageBox.information(self.iface.mainWindow(), "len(clipboard)".decode('utf-8'), str(len(clipboard)))
      #QMessageBox.information(self.iface.mainWindow(), "len(clipboard[1])".decode('utf-8'), str(len(clipboard[1])))
      #QMessageBox.information(self.iface.mainWindow(), "clipboard".decode('utf-8'), tempStr)      
      #QMessageBox.information(self.iface.mainWindow(), "clipboard".decode('utf-8'), '複製完成!'.decode('utf-8')) 

    if self.cadastreDia.tabWidget_2.currentIndex() == 3:
      rowCount = self.cadastreDia.tableWidget_4.rowCount()
      columnCount = self.cadastreDia.tableWidget_4.columnCount()

      #QMessageBox.information(self.iface.mainWindow(), "columnCount".decode('utf-8'), str(columnCount))
      #QMessageBox.information(self.iface.mainWindow(), "rowCount".decode('utf-8'), str(rowCount))

      clipboard = []

      for i in range(0, 1, 1):
        clipboard.append([])
        for j in range(0, rowCount, 1):
          clipboard[i].append(self.cadastreDia.tableWidget_4.verticalHeaderItem(j).text())

      for i in range(0, columnCount, 1):
        clipboard.append([])
        for j in range(0, rowCount, 1):
          if self.cadastreDia.tableWidget_4.item(j, i) != NULL:
            clipboard[i+1].append(self.cadastreDia.tableWidget_4.item(j, i).text())
          else:
            clipboard[i+1].append('')

      tempStr=''
      for j in range(0, rowCount, 1):
        tempStr += '\n'
        for i in range(0, len(clipboard), 1):
          tempStr += clipboard[i][j]
          tempStr += '\t'

      sys_clip = QtGui.QApplication.clipboard()
      sys_clip.setText(tempStr)

      #QMessageBox.information(self.iface.mainWindow(), "len(clipboard)".decode('utf-8'), str(len(clipboard)))
      #QMessageBox.information(self.iface.mainWindow(), "len(clipboard[1])".decode('utf-8'), str(len(clipboard[1])))
      #QMessageBox.information(self.iface.mainWindow(), "clipboard".decode('utf-8'), tempStr)      
      #QMessageBox.information(self.iface.mainWindow(), "clipboard".decode('utf-8'), '複製完成!'.decode('utf-8'))    



  def loadWFS_XY_Position(self):
    #QMessageBox.information(self.iface.mainWindow(),"x",  " \"{}\" ='{}' ".format( '小段', self.positioningDia.comboBox_9.currentText().encode('utf-8') ).decode('utf-8'))
    if self.cadastreDia.comboBox_4.currentIndex()==0:
      srs = "TWD97"
    if self.cadastreDia.comboBox_4.currentIndex()==1:
      srs = "WGS84"

    filePath = rootPath + 'cadastreService.csv'
    #QMessageBox.information(self.iface.mainWindow(), "X", filePath)
    urlPathfile = open(filePath, 'r')
    csvCursor = csv.reader(urlPathfile)
    urlPathList = []
    for row in csvCursor:
        urlPathList.append(row)

    #url = "http://140.109.161.37/fs/landquery/LandQuerySec.php?x=" + self.cadastreDia.lineEdit_2.text() + "&y=" + self.cadastreDia.lineEdit_3.text() + "&srs=" + srs
    url = urlPathList[0][1] + 'LandQuerySecXY.php?x=' + self.cadastreDia.lineEdit_2.text() + "&y=" + self.cadastreDia.lineEdit_3.text() + "&srs=" + srs
    #QMessageBox.information(self.iface.mainWindow(),"x",  url)

    #j = urllib2.urlopen(url)
    response = urllib2.urlopen(url)
    html = response.read().decode('utf-8')
    j = json.loads(html)

    unit = j['RESPONSE'][0]['LAND'][0]['UNIT'] 
    sec = j['RESPONSE'][0]['LAND'][0]['SEC'] 
    no = j['RESPONSE'][0]['LAND'][0]['NO'] 

    self.cadastreDia.comboBox_5.clear()
    self.cadastreDia.comboBox_5.insertItem(0, no)
    

#####

    ### check if feat ure exist ###
    uri = urlPathList[0][1] + 'landWFS3.php?LD=' + unit + '&SCNO=' + sec + '&PO=' + no
    response = urllib2.urlopen(uri)
    html = response.read().decode('utf-8')

    if html.find('COP') != -1:
      QMessageBox.information(self.iface.mainWindow(), "錯誤".decode('utf-8'), "查無此地號地籍圖".decode('utf-8'))

    else:

      ### 土地標示部 LandDescription ###
      url_1 =  urlPathList[0][1] + 'LandDescription.php?unit=' + unit + '&sec=' + sec + '&no=' + no
      #QMessageBox.information(self.iface.mainWindow(),"x",  url_1)

      response_1 = urllib2.urlopen(url_1)
      html_1 = response_1.read().decode('utf-8')

      if html_1.find('COP') != -1:
        #QMessageBox.information(self.iface.mainWindow(), "錯誤".decode('utf-8'), "查無此地號地籍土地標示部".decode('utf-8'))
        pass

      else:
        j_1 = json.loads(html_1)

        county_r = j_1['RESPONSE'][0]['RALID']['AA45']
        town_r = j_1['RESPONSE'][0]['RALID']['AA46']
        unit_r = j_1['RESPONSE'][0]['UNIT']
        sec_r = j_1['RESPONSE'][0]['SEC']
        no_r = j_1['RESPONSE'][0]['NO']

        townID_r = county_r+town_r

        townToCadastreUrl = 'http://maps.nlsc.gov.tw/T09/pro/setSection.jsp?city=' + county_r.encode('utf-8') + '&area=' + townID_r.encode('utf-8')

        #QMessageBox.information(self.iface.mainWindow(), "html",   townToCadastreUrl)
        response = urllib2.urlopen(townToCadastreUrl)
        xmlDoc = xml.dom.minidom.parse(response)
        root = xmlDoc.documentElement
        nameList = root.getElementsByTagName('name')
        idList = root.getElementsByTagName('id')
        #officeIDList = root.getElementsByTagName('office')

        nameNameList=[]
        ididList=[]
        for i in range(0, len(root.getElementsByTagName('name')), 1):
          ididList.append(idList[i].childNodes[0].data)
          nameNameList.append(nameList[i].childNodes[0].data)
        
        nameBase = unit_r + sec_r + nameNameList[ididList.index(sec_r.encode('utf-8'))]
        WFSLayerName = nameBase + '-' +  no_r

        #QMessageBox.information(self.iface.mainWindow(), "錯誤".decode('utf-8'), uri.decode('utf-8'))
        response = urllib2.urlopen(uri)
        html = response.read().decode('utf-8')

        #QMessageBox.information(self.iface.mainWindow(), "錯誤".decode('utf-8'), WFSLayerName[WFSLayerName.find('-'):WFSLayerName.find('_')])
###

        self.iface.addVectorLayer(uri, '', "ogr") 
        self.iface.activeLayer().setLayerName('WFSLayerName')

        shpName = "%s%s%s%s"%(rootPath, 'temp/', WFSLayerName, '.shp')
        #QMessageBox.information(self.iface.mainWindow(), "name".decode('utf-8'), shpName)

        _writer = QgsVectorFileWriter.writeAsVectorFormat(self.iface.activeLayer(), shpName, "utf-8", self.iface.activeLayer().crs(), "ESRI Shapefile")
        QgsMapLayerRegistry.instance().removeMapLayer(self.iface.activeLayer().id())
        self.iface.addVectorLayer(shpName, WFSLayerName, "ogr")
        

        #self.iface.setActiveLayer(target_layer)         
        pr = self.iface.activeLayer().dataProvider()

        features = self.iface.activeLayer().getFeatures() #returns QgsFeature object
        for feature in features:
          geom = feature.geometry()

        pr.addAttributes( [ QgsField("Name", QVariant.String), QgsField("No", QVariant.String) ] )
        self.iface.activeLayer().updateFields() 

        with edit(self.iface.activeLayer()):   
          for feat in self.iface.activeLayer().getFeatures():
            self.iface.activeLayer().deleteFeature(feat.id())             

        pt = QgsFeature()
        pt.setGeometry(geom)
        attr = []
        attr.append('1')
        attr.append(nameBase)
        attr.append(no)
        pt.setAttributes(attr)
        pr.addFeatures([pt])

        self.iface.activeLayer().updateExtents()


###

        self.canvas.setExtent(self.iface.activeLayer().extent())
        msg = WFSLayerName + '載入完成'.decode('utf-8')
        self.iface.mainWindow().statusBar().showMessage(msg)
        #QMessageBox.information(self.iface.mainWindow(), '載入完成'.decode('utf-8'),  msg)
        self.cadastreDia.tabWidget.setCurrentIndex(2)

        if j_1['RESPONSE'][0]['RALID']!=NULL:

          ### 登記日期_年, 月, 日 ###
          AA05 = j_1['RESPONSE'][0]['RALID']['AA05']
          AA05_str = AA05[0:3] + '年'.decode('utf-8') + AA05[3:5] + '月'.decode('utf-8') + AA05[5:7] + '日'.decode('utf-8')        

          ### 登記原因 ####
          AA06 = j_1['RESPONSE'][0]['RALID']['AA06']

          url_reason_1 =  urlPathList[0][1] + 'QueryReason.php?UNIT=' + unit
          response_reason_1 = urllib2.urlopen(url_reason_1)
          html_reason_1 = response_reason_1.read().decode('utf-8')
          j_reason_1 = json.loads(html_reason_1)

          reason_1_dict = {}

          reason_1_keys = range(len(j_reason_1['RESPONSE'][0]['DATA']))
          for i in reason_1_keys:
            reason_1_dict[i] = j_reason_1['RESPONSE'][0]['DATA'][i]['CODE']

          reason_1_dict_invert = {v: k for k, v in reason_1_dict.items()}
          #QMessageBox.information(self.iface.mainWindow(),"dict",  str(len(reason_2_dict)))
          #QMessageBox.information(self.iface.mainWindow(),"dict",  reason_2_dict[0][0])

          AA06_str = j_reason_1['RESPONSE'][0]['DATA'][reason_1_dict_invert.get(AA06)]['NAME']

          ### 面積 ###
          AA10 = j_1['RESPONSE'][0]['RALID']['AA10'] 

          ### 使用分區 ###
          AA11 = j_1['RESPONSE'][0]['RALID']['AA11']

          url_useZone_1 =  urlPathList[0][1] + 'QueryZone.php'
          response_useZone_1 = urllib2.urlopen(url_useZone_1)
          html_useZone_1 = response_useZone_1.read().decode('utf-8')
          j_useZone_1 = json.loads(html_useZone_1)

          useZone_1_dict = {}

          useZone_1_keys = range(len(j_useZone_1['RESPONSE']))
          for i in useZone_1_keys:
            useZone_1_dict[i] = j_useZone_1['RESPONSE'][i]['CODE']

          useZone_1_dict_invert = {v: k for k, v in useZone_1_dict.items()}
          #QMessageBox.information(self.iface.mainWindow(),"dict",  str(len(reason_2_dict)))
          #QMessageBox.information(self.iface.mainWindow(),"dict",  reason_2_dict[0][0])
          if useZone_1_dict_invert.get(AA11)!=None:
            AA11_str = j_useZone_1['RESPONSE'][useZone_1_dict_invert.get(AA11)]['NAME']
          else:
            AA11_str = ''

          ### 使用地類別 ###
          AA12 = j_1['RESPONSE'][0]['RALID']['AA12']

          ### 公告地現值 ###
          AA16 = j_1['RESPONSE'][0]['RALID']['AA16']

          ### 公告地價 ###
          AA17 = j_1['RESPONSE'][0]['RALID']['AA17']

          ### 縣市 ###
          AA45 = j_1['RESPONSE'][0]['RALID']['AA45']
          AA45_str = ''

          url_city_1 =  urlPathList[0][1] + 'QueryCity.php'
          response_city_1 = urllib2.urlopen(url_city_1)
          html_city_1 = response_city_1.read().decode('utf-8')
          j_city_1 = json.loads(html_city_1)

          city_1_dict = {}

          city_1_keys = range(len(j_city_1['RESPONSE']))
          for i in city_1_keys:
            city_1_dict[i] = j_city_1['RESPONSE'][i]['CODE']

          city_1_dict_invert = {v: k for k, v in city_1_dict.items()}
          #QMessageBox.information(self.iface.mainWindow(),"dict",  str(len(reason_2_dict)))
          #QMessageBox.information(self.iface.mainWindow(),"dict",  reason_2_dict[0][0])
          if city_1_dict_invert.get(AA45)!=None:
            AA45_str = j_city_1['RESPONSE'][city_1_dict_invert.get(AA45)]['NAME']
  
          ### 鄉鎮市區 ###
          AA46 = j_1['RESPONSE'][0]['RALID']['AA46']

          url_town_1 =  urlPathList[0][1] + 'QueryTown.php?city=' + AA45
          #QMessageBox.information(self.iface.mainWindow(),"dict",  url_town_1)
          response_town_1 = urllib2.urlopen(url_town_1)
          html_town_1 = response_town_1.read().decode('utf-8')
          j_town_1 = json.loads(html_town_1)

          town_1_dict = {}
          AA46_str = '' 

          town_1_keys = range(len(j_town_1['RESPONSE'][0]['TOWN']))
          for i in town_1_keys:
            town_1_dict[i] = j_town_1['RESPONSE'][0]['TOWN'][i]['CODE']

          town_1_dict_invert = {v: k for k, v in town_1_dict.items()}
          #QMessageBox.information(self.iface.mainWindow(),"dict",  str(len(reason_2_dict)))
          #QMessageBox.information(self.iface.mainWindow(),"dict",  reason_2_dict[0][0])
          if town_1_dict_invert.get(AA46)!=None:
            AA46_str = j_town_1['RESPONSE'][0]['TOWN'][town_1_dict_invert.get(AA46)]['NAME']

          ### 圖幅號 ###
          AA23 = j_1['RESPONSE'][0]['RALID']['AA23']

          ### 地上建物建號數量 ###
          BUILDINGCOUNT = j_1['RESPONSE'][0]['RALID']['BUILDINGCOUNT']

          url_1_1 =  urlPathList[0][1] + 'QueryReason.php?UNIT=' + unit
          #url_1_1 = 'http://140.109.161.72/QueryReason.php?UNIT=' + unit
          #QMessageBox.information(self.iface.mainWindow(),"x",  url_1)

          self.cadastreDia.tableWidget_2.setItem(0,  0, QtGui.QTableWidgetItem(nameBase))
          self.cadastreDia.tableWidget_2.setItem(0,  1, QtGui.QTableWidgetItem(no))
          self.cadastreDia.tableWidget_2.setItem(0,  2, QtGui.QTableWidgetItem(AA05_str))
          self.cadastreDia.tableWidget_2.setItem(0,  3, QtGui.QTableWidgetItem(AA06_str))
          self.cadastreDia.tableWidget_2.setItem(0,  4, QtGui.QTableWidgetItem(AA10))
          self.cadastreDia.tableWidget_2.setItem(0,  5, QtGui.QTableWidgetItem(AA11_str))    
          self.cadastreDia.tableWidget_2.setItem(0,  6, QtGui.QTableWidgetItem(AA12))
          self.cadastreDia.tableWidget_2.setItem(0,  7, QtGui.QTableWidgetItem(AA16))
          self.cadastreDia.tableWidget_2.setItem(0,  8, QtGui.QTableWidgetItem(AA17))
          self.cadastreDia.tableWidget_2.setItem(0,  9, QtGui.QTableWidgetItem(AA45_str))
          self.cadastreDia.tableWidget_2.setItem(0, 10, QtGui.QTableWidgetItem(AA46_str))
          self.cadastreDia.tableWidget_2.setItem(0, 11, QtGui.QTableWidgetItem(AA23))
          self.cadastreDia.tableWidget_2.setItem(0, 12, QtGui.QTableWidgetItem(BUILDINGCOUNT))

          self.cadastreDia.tableWidget_2.resizeColumnsToContents()
   
      ### 地籍土地所有權部 LandOwnership ###
      self.cadastreDia.tableWidget.setItem(0, 0, QtGui.QTableWidgetItem(self.cadastreDia.comboBox_3.currentText()))
      self.cadastreDia.tableWidget.setItem(0, 1, QtGui.QTableWidgetItem(no))

      url_2 =  urlPathList[0][1] + 'LandOwnership.php?UNIT=' + unit + '&SEC=' + sec + '&NO=' + no + '&OFFSET=1&LIMIT=10'
      #url_2 = 'http://140.109.161.72/LandOwnership.php?UNIT=' + unit + '&SEC=' + sec + '&NO=' + no + '&OFFSET=1&LIMIT=10'
      #QMessageBox.information(self.iface.mainWindow(),"x",  url_2)

      response_2 = urllib2.urlopen(url_2)
      html_2 = response_2.read().decode('utf-8')

      if html_2.find('COP') != -1:
        #QMessageBox.information(self.iface.mainWindow(), "錯誤".decode('utf-8'), "查無此地號地籍土地所有權部".decode('utf-8'))
        pass

      else:      
        j_2 = json.loads(html_2)

        if j_2['RETURNROWS']!=0:
          #j_3_count = len(j_3['RESPONSE'][0]['RCLOR'])
          j_2_count = len(j_2['RESPONSE'])
          rowPosition = self.cadastreDia.tableWidget.rowCount()

          self.cadastreDia.tableWidget.setColumnCount(j_2_count)

          for i in range(0, j_2_count, 1):

            if j_2['RESPONSE']!=NULL: 
              if len(j_2['RESPONSE'][i]['RBLOW'])!=0:

                #登記日期_年, 月, 日  
                BB05 = j_2['RESPONSE'][i]['RBLOW'][0]['BB05']
                BB05_str = BB05[0:3] + '年'.decode('utf-8') + BB05[3:5] + '月'.decode('utf-8') + BB05[5:7] + '日'.decode('utf-8')

                #登記原因
                BB06 = j_2['RESPONSE'][i]['RBLOW'][0]['BB06']

                url_reason_2 =  urlPathList[0][1] + 'QueryReason.php?UNIT=' + unit
                response_reason_2 = urllib2.urlopen(url_reason_2)
                html_reason_2 = response_reason_2.read().decode('utf-8')
                j_reason_2 = json.loads(html_reason_2)

                reason_2_dict = {}

                reason_2_keys = range(len(j_reason_2['RESPONSE'][0]['DATA']))
                for p in reason_2_keys:
                  reason_2_dict[p] = j_reason_2['RESPONSE'][0]['DATA'][p]['CODE']


                reason_2_dict_invert = {v: k for k, v in reason_2_dict.items()}
                #QMessageBox.information(self.iface.mainWindow(),"dict",  str(len(reason_2_dict)))
                #QMessageBox.information(self.iface.mainWindow(),"dict",  reason_2_dict[0][0])

                BB06_str = j_reason_2['RESPONSE'][0]['DATA'][reason_2_dict_invert.get(BB06)]['NAME']
                #BB06_str = j_reason_2['RESPONSE'][0]['DATA'][int(BB06)]['NAME']

                #登記原因發生日期
                BB07 = j_2['RESPONSE'][i]['RBLOW'][0]['BB07']
                BB07_str = BB07[0:3] + '年'.decode('utf-8') + BB07[3:5] + '月'.decode('utf-8') + BB07[5:7] + '日'.decode('utf-8')

                #權利範圍類別
                url_rights_2 =  urlPathList[0][1] + 'QueryRights.php'
                response_rights_2 = urllib2.urlopen(url_rights_2)
                html_rights_2 = response_rights_2.read().decode('utf-8')
                j_rights_2 = json.loads(html_rights_2)

                BB15_1 = j_2['RESPONSE'][i]['RBLOW'][0]['BB15_1']

                #rights_2 = {'A': 0, 'B': 1, 'C': 2, 'Z': 3}
                #rights_2_dict = j_righst_2['RESPONSE']

                rights_2_dict = {}
                rights_2_keys = range(len(j_rights_2['RESPONSE']))
                for m in rights_2_keys:
                  rights_2_dict[m] = j_rights_2['RESPONSE'][m]['CODE']

                #rights_2_dict_invert = {}
                rights_2_dict_invert = {v: k for k, v in rights_2_dict.items()}

                if rights_2_dict_invert.get(BB15_1)!=None:
                  BB15_1_str = j_rights_2['RESPONSE'][rights_2_dict_invert.get(BB15_1)]['NAME']
                else:
                  BB15_1_str=''

                #權利範圍分母
                BB15_2 = j_2['RESPONSE'][i]['RBLOW'][0]['BB15_2']

                #權利範圍分子
                BB15_3 = j_2['RESPONSE'][i]['RBLOW'][0]['BB15_3']

                #權狀年期
                BB03 = j_2['RESPONSE'][i]['RBLOW'][0]['BB03']
                if BB03 !=NULL:
                  BB03_str = BB03[0:3] + '年'.decode('utf-8') + BB03[3:5] + '月'.decode('utf-8') + BB03[5:7] + '日'.decode('utf-8')
                else:
                   BB03_str = BB03

                #權狀字
                BB04_1 = j_2['RESPONSE'][i]['RBLOW'][0]['BB04_1']

                #權狀號
                BB04_2 = j_2['RESPONSE'][i]['RBLOW'][0]['BB04_2']

                #申報地價
                BB21 = j_2['RESPONSE'][i]['RBLOW'][0]['BB21']

                self.cadastreDia.tableWidget.setItem( 0, i, QtGui.QTableWidgetItem(nameBase))
                self.cadastreDia.tableWidget.setItem( 1, i, QtGui.QTableWidgetItem(no))
                self.cadastreDia.tableWidget.setItem( 2, i, QtGui.QTableWidgetItem(BB05_str))
                self.cadastreDia.tableWidget.setItem( 3, i, QtGui.QTableWidgetItem(BB06_str))
                self.cadastreDia.tableWidget.setItem( 4, i, QtGui.QTableWidgetItem(BB07_str))
                self.cadastreDia.tableWidget.setItem( 5, i, QtGui.QTableWidgetItem(BB15_1_str))    
                self.cadastreDia.tableWidget.setItem( 6, i, QtGui.QTableWidgetItem(BB15_2))
                self.cadastreDia.tableWidget.setItem( 7, i, QtGui.QTableWidgetItem(BB15_3))
                self.cadastreDia.tableWidget.setItem( 8, i, QtGui.QTableWidgetItem(BB03))
                self.cadastreDia.tableWidget.setItem( 9, i, QtGui.QTableWidgetItem(BB04_1))
                self.cadastreDia.tableWidget.setItem(10, i, QtGui.QTableWidgetItem(BB04_2))
                self.cadastreDia.tableWidget.setItem(11, i, QtGui.QTableWidgetItem(BB04_2))

            else:
              self.cadastreDia.tableWidget.setColumnCount(1)

          self.cadastreDia.tableWidget.resizeColumnsToContents()





      ### 地籍土地他項權利部 LandOtherRights ###
      self.cadastreDia.tableWidget_3.setItem(0, 0, QtGui.QTableWidgetItem(self.cadastreDia.comboBox_3.currentText()))
      self.cadastreDia.tableWidget_3.setItem(0, 1, QtGui.QTableWidgetItem(no))
    
      url_3 = urlPathList[0][1] + 'LandOtherRights.php?UNIT=' + unit + '&SEC=' + sec + '&NO=' + no + '&OFFSET=1&LIMIT=10'
      #QMessageBox.information(self.iface.mainWindow(), "url_3",  url_3)

      response_3 = urllib2.urlopen(url_3)
      html_3 = response_3.read().decode('utf-8')

      if html_3.find('COP') != -1:
        #QMessageBox.information(self.iface.mainWindow(), "錯誤".decode('utf-8'), "查無此地號地籍土地所有權部".decode('utf-8'))
        pass

      else:
        j_3 = json.loads(html_3)

        if j_3['RETURNROWS']!=0:
          #j_3_count = len(j_3['RESPONSE'][0]['RCLOR'])
          j_3_count = len(j_3['RESPONSE'])
          rowPosition = self.cadastreDia.tableWidget_3.rowCount()

          self.cadastreDia.tableWidget_3.setColumnCount(j_3_count)

          for i in range(0, j_3_count, 1):
            #QMessageBox.information(self.iface.mainWindow(), "len".decode('utf-8'), str(len(j_3['RESPONSE'][i]['RCLOR'])))
            if j_3['RESPONSE']!=NULL: 
              if len(j_3['RESPONSE'][i]['RCLOR'])!=0:
                CC01 = j_3['RESPONSE'][i]['RCLOR'][0]['CC01']
                CC03 = j_3['RESPONSE'][i]['RCLOR'][0]['CC03']
                CC04_1 = j_3['RESPONSE'][i]['RCLOR'][0]['CC04_1']
                CC04_2 = j_3['RESPONSE'][i]['RCLOR'][0]['CC04_2']        

                ### 登記日期 ###
                CC05 = j_3['RESPONSE'][i]['RCLOR'][0]['CC05']
                CC05_str = CC05[0:3] + '年'.decode('utf-8') + CC05[3:5] + '月'.decode('utf-8') + CC05[5:7] + '日'.decode('utf-8')            

                ### 登記原因 ###
                CC06 = j_3['RESPONSE'][i]['RCLOR'][0]['CC06']

                url_reason_3 =  urlPathList[0][1] + 'QueryReason.php?UNIT=' + unit
                response_reason_3 = urllib2.urlopen(url_reason_3)
                html_reason_3 = response_reason_3.read().decode('utf-8')
                j_reason_3 = json.loads(html_reason_3)

                reason_3_dict = {}

                reason_3_keys = range(len(j_reason_3['RESPONSE'][0]['DATA']))
                for ii in reason_3_keys:
                  reason_3_dict[ii] = j_reason_3['RESPONSE'][0]['DATA'][ii]['CODE']

                reason_3_dict_invert = {v: k for k, v in reason_3_dict.items()}

                if rights_2_dict_invert.get(CC06)!=None:
                  CC06_str = j_reason_3['RESPONSE'][0]['DATA'][reason_3_dict_invert.get(CC06)]['NAME']
                else:
                  CC06_str=''
            
                ### 設定權利範圍類別 ###
                CC15_1 = j_3['RESPONSE'][i]['RCLOR'][0]['CC15_1']

                url_rights_3 =  urlPathList[0][1] + 'QueryRights.php'
                response_rights_3 = urllib2.urlopen(url_rights_3)
                html_rights_3 = response_rights_3.read().decode('utf-8')
                j_rights_3 = json.loads(html_rights_3)

                rights_3_dict = {}
                rights_3_keys = range(len(j_rights_3['RESPONSE']))
                for n in rights_3_keys:
                  rights_3_dict[n] = j_rights_3['RESPONSE'][n]['CODE']
  
                rights_3_dict_invert = {v: k for k, v in rights_3_dict.items()}

                if rights_3_dict_invert.get(CC15_1)!=None:
                  CC15_1_str = j_rights_3['RESPONSE'][rights_3_dict_invert.get(CC15_1)]['NAME']
                else:
                  CC15_1_str=''
            
                CC15_2 = j_3['RESPONSE'][i]['RCLOR'][0]['CC15_2']
                CC15_3 = j_3['RESPONSE'][i]['RCLOR'][0]['CC15_3']
                CC15_4 = j_3['RESPONSE'][i]['RCLOR'][0]['CC15_4']        
                CC16 = j_3['RESPONSE'][i]['RCLOR'][0]['CC16']

                ### 債權權利範圍類別 ###
                CC18_1 = j_3['RESPONSE'][i]['RCLOR'][0]['CC18_1']

                url_LoanRight_3 =  urlPathList[0][1] + 'QueryLoanRightsRange.php'
                response_LoanRight_3 = urllib2.urlopen(url_LoanRight_3)
                html_LoanRight_3 = response_LoanRight_3.read().decode('utf-8')
                j_LoanRight_3 = json.loads(html_LoanRight_3)

                LoanRight_3_dict = {}
                LoanRight_3_keys = range(len(j_LoanRight_3['RESPONSE']))
                for m in LoanRight_3_keys:
                  LoanRight_3_dict[m] = j_LoanRight_3['RESPONSE'][m]['CODE']

                LoanRight_3_dict_invert = {v: k for k, v in LoanRight_3_dict.items()}

                if LoanRight_3_dict_invert.get(CC18_1)!=None:
                  CC18_1_str = j_LoanRight_3['RESPONSE'][LoanRight_3_dict_invert.get(CC18_1)]['NAME']
                else:
                  CC18_1_str=''

                CC18_2 = j_3['RESPONSE'][i]['RCLOR'][0]['CC18_2']        
                CC18_3 = j_3['RESPONSE'][i]['RCLOR'][0]['CC18_3']  

                ### 權利種類 ###
                CC27 = j_3['RESPONSE'][i]['RCLOR'][0]['CC27']

                url_rightstype_3 =  urlPathList[0][1] + 'QueryRightsAndTypes.php'
                response_rightstype_3 = urllib2.urlopen(url_rightstype_3)
                html_rightstype_3 = response_rightstype_3.read().decode('utf-8')
                j_rightstype_3 = json.loads(html_rightstype_3)

                rightstype_3_dict = {}
                rightstype_3_keys = range(len(j_rightstype_3['RESPONSE']))
                for o in rightstype_3_keys:
                  rightstype_3_dict[o] = j_rightstype_3['RESPONSE'][o]['CODE']

                rightstype_3_dict_invert = {v: k for k, v in rightstype_3_dict.items()}

                if rightstype_3_dict_invert.get(CC27)!=None:
                  CC27_str = j_rightstype_3['RESPONSE'][rightstype_3_dict_invert.get(CC27)]['NAME']
                else:
                  CC27_str=''                  
            
                ### 標的種類 ###
                CC28_1 = j_3['RESPONSE'][i]['RCLOR'][0]['CC28_1']

                url_goaltype_3 =  urlPathList[0][1] + 'QueryRightsAndTypes.php'
                response_goaltype_3 = urllib2.urlopen(url_goaltype_3)
                html_goaltype_3 = response_goaltype_3.read().decode('utf-8')
                j_goaltype_3 = json.loads(html_goaltype_3)
 
                goaltype_3_dict = {}
                goaltype_3_keys = range(len(j_goaltype_3['RESPONSE']))
                for p in goaltype_3_keys:
                  goaltype_3_dict[p] = j_goaltype_3['RESPONSE'][p]['CODE']

                goaltype_3_dict_invert = {v: k for k, v in goaltype_3_dict.items()}

                if goaltype_3_dict_invert.get(CC28_1)!=None:
                  CC28_1_str = j_goaltype_3['RESPONSE'][goaltype_3_dict_invert.get(CC28_1)]['NAME']
                else:
                  CC28_1_str=''              

                self.cadastreDia.tableWidget_3.setItem(0,  i, QtGui.QTableWidgetItem(nameBase))
                self.cadastreDia.tableWidget_3.setItem(1,  i, QtGui.QTableWidgetItem(no))
                self.cadastreDia.tableWidget_3.setItem(2,  i, QtGui.QTableWidgetItem(CC01))
                self.cadastreDia.tableWidget_3.setItem(3,  i, QtGui.QTableWidgetItem(CC03))
                self.cadastreDia.tableWidget_3.setItem(4,  i, QtGui.QTableWidgetItem(CC04_1))
                self.cadastreDia.tableWidget_3.setItem(5,  i, QtGui.QTableWidgetItem(CC04_2))
                self.cadastreDia.tableWidget_3.setItem(6,  i, QtGui.QTableWidgetItem(CC05_str))
                self.cadastreDia.tableWidget_3.setItem(7,  i, QtGui.QTableWidgetItem(CC06_str))
                self.cadastreDia.tableWidget_3.setItem(8,  i, QtGui.QTableWidgetItem(CC15_1_str))
                self.cadastreDia.tableWidget_3.setItem(9,  i, QtGui.QTableWidgetItem(CC15_2))
                self.cadastreDia.tableWidget_3.setItem(10, i, QtGui.QTableWidgetItem(CC15_3))
                self.cadastreDia.tableWidget_3.setItem(11, i, QtGui.QTableWidgetItem(CC15_4))
                self.cadastreDia.tableWidget_3.setItem(12, i, QtGui.QTableWidgetItem(CC16))
                self.cadastreDia.tableWidget_3.setItem(13, i, QtGui.QTableWidgetItem(CC18_1_str))
                self.cadastreDia.tableWidget_3.setItem(14, i, QtGui.QTableWidgetItem(CC18_2))
                self.cadastreDia.tableWidget_3.setItem(15, i, QtGui.QTableWidgetItem(CC18_3))
                self.cadastreDia.tableWidget_3.setItem(16, i, QtGui.QTableWidgetItem(CC27_str))
                self.cadastreDia.tableWidget_3.setItem(17, i, QtGui.QTableWidgetItem(CC28_1_str))

            else:
              self.cadastreDia.tableWidget_3.setColumnCount(1)
              

                   
          self.cadastreDia.tableWidget_3.resizeColumnsToContents()

        ### 地籍建物標示部 BuildingDescription ###
        self.cadastreDia.tableWidget_4.setItem(0, 0, QtGui.QTableWidgetItem(self.cadastreDia.comboBox_3.currentText()))
        self.cadastreDia.tableWidget_4.setItem(0, 1, QtGui.QTableWidgetItem(no))    

        url_4 =  urlPathList[0][1] + 'BuildingDescription.php?unit=' + unit + '&sec=' + sec + '&no=' + no
        response_4 = urllib2.urlopen(url_4)
        html_4 = response_4.read().decode('utf-8')
 
        if html_4.find('COP') != -1:
          #QMessageBox.information(self.iface.mainWindow(), "錯誤".decode('utf-8'), "查無此地號地籍建物標示部".decode('utf-8'))
          pass

        else:
          j_4 = json.loads(html_4)

          if j_4['RESPONSE'][0]['RDBID']!=NULL:
            DD05 = j_4['RESPONSE'][0]['RDBID']['DD05']  

            self.cadastreDia.tableWidget_4.setItem(0,  0, QtGui.QTableWidgetItem(nameBase))
            self.cadastreDia.tableWidget_4.setItem(0,  1, QtGui.QTableWidgetItem(no))
            self.cadastreDia.tableWidget_4.setItem(0,  2, QtGui.QTableWidgetItem(DD05))      

            self.cadastreDia.tableWidget_4.resizeColumnsToContents()
           #url_4 = 'http://140.109.161.72/BuildingDescription.php?unit=' + unit + '&sec=' + sec + '&no=' + no
           #QMessageBox.information(self.iface.mainWindow(),"x",  url_4)

   
    self.cadastre_reset()
    self.cadastreDia.tabWidget.setCurrentIndex(2)

    
  def loadWFS(self):

    # get cadastre NO List
    filePath = rootPath + 'cadastreService.csv'
    #QMessageBox.information(self.iface.mainWindow(), "X", filePath)
    urlPathfile = open(filePath, 'r')
    csvCursor = csv.reader(urlPathfile)
    urlPathList = []
    for row in csvCursor:
        urlPathList.append(row)

    unit = self.cadastreDia.comboBox_3.currentText()[0] + self.cadastreDia.comboBox_3.currentText()[1]
    sec = self.cadastreDia.comboBox_3.currentText()[2] + self.cadastreDia.comboBox_3.currentText()[3] + self.cadastreDia.comboBox_3.currentText()[4] + self.cadastreDia.comboBox_3.currentText()[5]

    url_1 =  urlPathList[0][1] + 'LandQuerySec.php?UNIT=' + unit + '&SEC=' + sec + '&ZONE='
    #QMessageBox.information(self.iface.mainWindow(), url_1, url_1)

    response_1 = urllib2.urlopen(url_1)
    html_1 = response_1.read().decode('utf-8')
    j_1 = json.loads(html_1)

    if j_1['RESPONSE'][0]['NO']!=NULL:
      no = j_1['RESPONSE'][0]['NO']
    #QMessageBox.information(self.iface.mainWindow(), url_1, str(len(no)))
    #QMessageBox.information(self.iface.mainWindow(), url_1, url_1)

      no.sort()
      self.cadastreDia.listWidget.clear()
      for i in range(0, len(no), 1):
        self.cadastreDia.listWidget.addItem(no[i])

    else:
      QMessageBox.information(self.iface.mainWindow(), "error",  '此地段查無地號'.decode('utf-8'))

  def cadastreItemDel(self):
    #QMessageBox.information(self.iface.mainWindow(), 'del', 'deldel')
    listItems = self.cadastreDia.listWidget_2.selectedItems()
    
    if not listItems: return        
    
    for item in listItems:
       self.cadastreDia.listWidget_2.takeItem(self.cadastreDia.listWidget_2.row(item))      

    itemList = []

    for i in range(0, self.cadastreDia.listWidget_2.count(), 1):
      itemList.append(self.cadastreDia.listWidget_2.item(i).text())

    items = list(set(itemList))
    
    self.cadastreDia.listWidget_2.clear()
    self.cadastreDia.comboBox_5.clear()

    for i in range(0, len(items), 1):
      #QMessageBox.information(self.iface.mainWindow(),"x",  str(i))
      self.cadastreDia.listWidget_2.addItem(items[i])

    for i in range(0, self.cadastreDia.listWidget_2.count(), 1):  
      self.cadastreDia.comboBox_5.insertItem(i, self.cadastreDia.listWidget_2.item(i).text())

  def addCadastreItem(self):

    out = self.cadastreDia.listWidget.findItems(self.cadastreDia.lineEdit.text(), QtCore.Qt.MatchExactly)
    #QMessageBox.information(self.iface.mainWindow(), "error",  str(len(out)))
    #if self.cadastreDia.lineEdit.text() !='':
    if len(out) != 0:
      self.cadastreDia.listWidget_2.addItem(self.cadastreDia.lineEdit.text())
      itemList = []

      for i in range(0, self.cadastreDia.listWidget_2.count(), 1):
        itemList.append(self.cadastreDia.listWidget_2.item(i).text())

      items = list(set(itemList))
    
      self.cadastreDia.listWidget_2.clear()
      self.cadastreDia.comboBox_5.clear()

      for i in range(0, len(items), 1):
        #QMessageBox.information(self.iface.mainWindow(),"x",  str(i))
        self.cadastreDia.listWidget_2.addItem(items[i])

      for i in range(0, self.cadastreDia.listWidget_2.count(), 1):  
        self.cadastreDia.comboBox_5.insertItem(i, self.cadastreDia.listWidget_2.item(i).text()) 

    else:
      QMessageBox.information(self.iface.mainWindow(), "error",  '輸入地號並不存在此地段!'.decode('utf-8'))

  def cadastreItemClicked(self):
    #QMessageBox.information(self.iface.mainWindow(),"x",  "click")
    #self.cadastreDia.lineEdit_4.clear()
    #self.cadastreDia.lineEdit_4.insert(self.cadastreDia.listWidget.currentItem().text())

    self.cadastreDia.listWidget_2.addItem(self.cadastreDia.listWidget.currentItem().text())
    itemList = []

    for i in range(0, self.cadastreDia.listWidget_2.count(), 1):
      itemList.append(self.cadastreDia.listWidget_2.item(i).text())

    items = list(set(itemList))
    
    self.cadastreDia.listWidget_2.clear()
    self.cadastreDia.comboBox_5.clear()

    for i in range(0, len(items), 1):
      #QMessageBox.information(self.iface.mainWindow(),"x",  str(i))
      self.cadastreDia.listWidget_2.addItem(items[i])

    for i in range(0, self.cadastreDia.listWidget_2.count(), 1):  
      self.cadastreDia.comboBox_5.insertItem(i, self.cadastreDia.listWidget_2.item(i).text())


  def ComboBox_3_change(self):
    #registry = QgsMapLayerRegistry.instance()
    #target_layer = registry.mapLayersByName( self.positioningDia.comboBox_2.currentText() + '事業區林班圖'.decode('utf-8') )[0]
    #self.iface.setActiveLayer(target_layer)

    legend = self.iface.legendInterface()
    layers = self.canvas.layers()
    for each_layer in layers:
      legend.setLayerVisible(each_layer, False)
    registry = QgsMapLayerRegistry.instance()

    filePath = rootPath + 'filePath.csv'
    #QMessageBox.information(self.iface.mainWindow(), "X", filePath)
    filePathfile = open(filePath, 'r')
    csvCursor = csv.reader(filePathfile)
    filePathList = []
    for row in csvCursor:
        filePathList.append(row)

    filePathName = self.mainDia.lineEdit.text() + filePathList[1][2].decode('utf-8')

    if os.path.isfile(filePathName) :    
      #QMessageBox.information(self.iface.mainWindow(), "mes", filePathName)
      if len(QgsMapLayerRegistry.instance().mapLayersByName(filePathList[1][1].decode('utf-8'))) == 0:
        i=0
        self.iface.addVectorLayer(filePathName, "", "ogr")  
        self.setSourceEncode()
    

      registry = QgsMapLayerRegistry.instance()
      #self.positioningDia.comboBox_2.currentText() + '事業區林班圖'.decode('utf-8')
      target_layer = registry.mapLayersByName( filePathList[1][1].decode('utf-8') )[0]
      #target_layer = registry.mapLayersByName( '第二輪檢訂事業區圖'.decode('utf-8') )[0]
      self.iface.setActiveLayer(target_layer)    
      legend.setLayerVisible(target_layer, True)  
      #expr = QgsExpression( " \"{}\" ='{}' ".format( 'LAND_NO0', self.positioningDia.comboBox_12.currentText().encode('utf-8') ).decode('utf-8') )
      #expr = QgsExpression( " \"{}\" ='{}' ".format                 ( 'CMPT', self.positioningDia.comboBox_3.currentText().encode('utf-8'), '事務所',  self.positioningDia.comboBox_7.currentText().encode('utf-8')).decode('utf-8'))    
      expr = QgsExpression( " \"{}\" ='{}' AND \"{}\" ='{}' ".format( filePathList[1][4], self.positioningDia.comboBox_3.currentText().encode('utf-8'), filePathList[1][3],  self.positioningDia.comboBox_2.currentText().encode('utf-8')).decode('utf-8'))    
      #QMessageBox.information(self.iface.mainWindow(),"x",  " \"{}\" ='{}' ".format( '小段', self.positioningDia.comboBox_9.currentText().encode('utf-8') ).decode('utf-8'))
      #it = target_layer.getFeatures( QgsFeatureRequest( expr ) )
    
      it = target_layer.getFeatures( QgsFeatureRequest( expr ) )
      ids = [i.id() for i in it]
    
      self.iface.activeLayer().removeSelection()
      target_layer.setSelectedFeatures( ids )
      self.canvas.zoomToSelected()

    else:
      msg = "找不到\" ".decode('utf-8') + filePathName + " \"圖層".decode('utf-8') + "\n請確認路徑".decode('utf-8') 
      QMessageBox.information(self.iface.mainWindow(), "錯誤".decode('utf-8'), msg)       


  def ComboBox_2_change(self):

    legend = self.iface.legendInterface()
    layers = self.canvas.layers()
    for each_layer in layers:
      legend.setLayerVisible(each_layer, False)
    registry = QgsMapLayerRegistry.instance()


    filePath = rootPath + 'filePath.csv'
    #QMessageBox.information(self.iface.mainWindow(), "X", filePath)
    filePathfile = open(filePath, 'r')
    csvCursor = csv.reader(filePathfile)
    filePathList = []
    for row in csvCursor:
        filePathList.append(row)

    filePathName = self.mainDia.lineEdit.text() + filePathList[1][2].decode('utf-8')

    if os.path.isfile(filePathName) :        
      #QMessageBox.information(self.iface.mainWindow(), "mes", filePathName)
      if len(QgsMapLayerRegistry.instance().mapLayersByName(filePathList[1][1].decode('utf-8'))) == 0:
        i=0
        self.iface.addVectorLayer(filePathName, "", "ogr")  
        self.setSourceEncode()
    

     #if self.positioningDia.comboBox_2.currentIndex() == 0:
        #self.positioningDia.comboBox_3.clear()
        #self.positioningDia.comboBox_3.setEnabled(False)

      registry = QgsMapLayerRegistry.instance()
      #self.positioningDia.comboBox_2.currentText() + '事業區林班圖'.decode('utf-8')
      target_layer = registry.mapLayersByName( filePathList[1][1].decode('utf-8') )[0]
      #target_layer = registry.mapLayersByName( '第二輪檢訂事業區圖'.decode('utf-8') )[0]
      self.iface.setActiveLayer(target_layer)
      legend.setLayerVisible(target_layer, True)        

      #expr = QgsExpression( " \"{}\" ='{}' ".format( 'WKNG_C', self.positioningDia.comboBox_2.currentText().encode('utf-8') ).decode('utf-8') ) 
      expr = QgsExpression( " \"{}\" ='{}' ".format( filePathList[1][3].decode('utf-8'), self.positioningDia.comboBox_2.currentText().encode('utf-8') ).decode('utf-8') ) 
      it = target_layer.getFeatures( QgsFeatureRequest( expr ) )
      ids = [i.id() for i in it]

      self.iface.activeLayer().removeSelection()
      target_layer.setSelectedFeatures( ids )
      self.canvas.zoomToSelected()

      self.positioningDia.comboBox_3.setEnabled(True)
      self.positioningDia.comboBox_3.clear()
      self.positioningDia.comboBox_3.insertItem(0, '請選擇林班'.decode('utf-8'))

      #fni = self.iface.activeLayer().fieldNameIndex('CMPT')

      #for i in range(0, len(filePathList[1]), 1):
        #QMessageBox.information(self.iface.mainWindow(), "錯誤11".decode('utf-8'), filePathList[1][i].decode('utf-8'))

      fni = self.iface.activeLayer().fieldNameIndex(filePathList[1][4].decode('utf-8'))
      unique_values = self.iface.activeLayer().dataProvider().uniqueValues(fni)
      i=0
      for value in unique_values:
        #attrs_1 = feat.attributes()[idx_1]
        if value != NULL:
          self.positioningDia.comboBox_3.insertItem(i+1, str(value))
          i+=1
        #QMessageBox.information(self.iface.mainWindow(), "X", str(value))'''
      self.positioningDia.comboBox_3.setCurrentIndex(0)

    else:
      msg = "找不到\" ".decode('utf-8') + filePathName + " \"圖層".decode('utf-8') + "\n請確認路徑".decode('utf-8') 
      QMessageBox.information(self.iface.mainWindow(), "錯誤".decode('utf-8'), msg)  
            

  def ComboBox_change(self):
    #QMessageBox.information(self.iface.mainWindow(), "X", "it works")
    #if self.positioningDia.comboBox.currentIndex() == 0:
    self.positioningDia.comboBox_2.clear()
    self.positioningDia.comboBox_3.clear()
    self.positioningDia.comboBox_2.setEnabled(True)
    self.positioningDia.comboBox_3.setEnabled(False)

    legend = self.iface.legendInterface()
    layers = self.canvas.layers()
    for each_layer in layers:
      legend.setLayerVisible(each_layer, False)
    registry = QgsMapLayerRegistry.instance()


    filePath = rootPath + 'filePath.csv'
    #QMessageBox.information(self.iface.mainWindow(), "X", filePath)
    filePathfile = open(filePath, 'r')
    csvCursor = csv.reader(filePathfile)
    filePathList = []
    for row in csvCursor:
        filePathList.append(row)

    filePathName = self.mainDia.lineEdit.text() + filePathList[0][2].decode('utf-8')

    if os.path.isfile(filePathName) :      
      #QMessageBox.information(self.iface.mainWindow(), "mes", filePathName)
      if len(QgsMapLayerRegistry.instance().mapLayersByName(filePathList[0][1].decode('utf-8'))) == 0:
        i=0
        self.iface.addVectorLayer(filePathName, "", "ogr")  
        self.setSourceEncode()

      registry = QgsMapLayerRegistry.instance()
      target_layer = registry.mapLayersByName( filePathList[0][1].decode('utf-8') )[0]
      self.iface.setActiveLayer(target_layer)    
      legend.setLayerVisible(target_layer, True)     

      #QMessageBox.information(self.iface.mainWindow(), "錯誤".decode('utf-8'),   filePathList[0][1].decode('utf-8'))

      self.positioningDia.comboBox_2.clear()
      self.positioningDia.comboBox_2.insertItem(0, '請選擇事業區'.decode('utf-8'))


  #      self.positioningDia.comboBox_3.clear()
  #      self.positioningDia.comboBox_3.insertItem(0, '請選擇林班'.decode('utf-8'))
  #      self.positioningDia.comboBox_3.setCurrentIndex(0)
    
      #strr = self.positioningDia.comboBox.currentText() + '處'.decode('utf-8')
      #QMessageBox.information(self.iface.mainWindow(), "錯誤".decode('utf-8'),  strr)

      #expr = QgsExpression( " \"{}\" ='{}{}'' ".format( 'DIST_C', self.positioningDia.comboBox.currentText().encode('utf-8'), '處' ).decode('utf-8') )


      #fni = self.iface.activeLayer().fieldNameIndex('DIST_C')
      fni = self.iface.activeLayer().fieldNameIndex(filePathList[0][3].decode('utf-8'))
      valueList=[]
      unique_values = self.iface.activeLayer().dataProvider().uniqueValues(fni)
      for value in unique_values:
        if value != NULL:
          valueList.append(value)
          #i+=1

      #expr = QgsExpression( " \"{}\" ='{}' ".format( 'DIST_C', valueList[self.positioningDia.comboBox.currentIndex()-1].encode('utf-8') ).decode('utf-8') )
      expr = QgsExpression( " \"{}\" ='{}' ".format( filePathList[0][3].decode('utf-8'), valueList[self.positioningDia.comboBox.currentIndex()-1].encode('utf-8') ).decode('utf-8') )
      #QMessageBox.information(self.iface.mainWindow(), "錯誤".decode('utf-8'),  'DIST_C', value[self.positioningDia.comboBox.currentIndex()] )
      it = target_layer.getFeatures( QgsFeatureRequest( expr ) )
      #idx_1 = self.iface.activeLayer().fieldNameIndex('WKNG_C'.decode('utf-8'))
      idx_1 = self.iface.activeLayer().fieldNameIndex(filePathList[0][4].decode('utf-8'))
      valueList_2 =[j.attributes()[idx_1] for j in it]

      it = target_layer.getFeatures( QgsFeatureRequest( expr ) )
      ids = [i.id() for i in it]
      self.iface.activeLayer().removeSelection()
      target_layer.setSelectedFeatures( ids )
      self.canvas.zoomToSelected()    

      uniqueValue = set(valueList_2)
      i=0
      self.positioningDia.comboBox_2.clear()
      for v in uniqueValue:
        if v != NULL:
          self.positioningDia.comboBox_2.insertItem(i+1, v)
          i+=1

      self.positioningDia.comboBox_2.setCurrentIndex(0)

    else:
      msg = "找不到\" ".decode('utf-8') + filePathName + " \"圖層".decode('utf-8') + "\n請確認路徑".decode('utf-8') 
      QMessageBox.information(self.iface.mainWindow(), "錯誤".decode('utf-8'), msg) 

  def getGPXName(self):
    gpxFileName = QFileDialog.getOpenFileName(None, u"請選擇GPX檔案", self.mainDia.lineEdit.text(), "GPX files (*.gpx)")
    self.gpx2shpDia.lineEdit.clear()
    self.gpx2shpDia.lineEdit.insert(gpxFileName)

  def getCSVName(self):
    csvFileName = QFileDialog.getOpenFileName(None, u"請選擇CSV檔案", self.mainDia.lineEdit.text(), "CSV files (*.csv)")
    self.csv2shpDia.lineEdit.clear()
    self.csv2shpDia.lineEdit.insert(csvFileName)
    #QMessageBox.information(self.iface.mainWindow(), "X", csvFileName)

  def getGPX2SHPName(self):
    shpFileName = QFileDialog.getSaveFileName(None, u"圖層另存為", self.mainDia.lineEdit.text(), "SHP files (*.shp)")
    self.gpx2shpDia.lineEdit_2.clear()
    self.gpx2shpDia.lineEdit_2.insert(shpFileName)

  def gpx2shp(self):

    global layerPath
    global layeridName
    if self.gpx2shpDia.radioButton.isChecked(): #waypoint
      layerPath = self.gpx2shpDia.lineEdit.text() + '|layerid=0'
      layeridName='waypoint'
    elif self.gpx2shpDia.radioButton_2.isChecked(): #route_point
      layerPath = self.gpx2shpDia.lineEdit.text() + '|layerid=3'
      layeridName='route_point'      
    elif self.gpx2shpDia.radioButton_3.isChecked(): #track_point
      layerPath = self.gpx2shpDia.lineEdit.text() + '|layerid=4'
      layeridName='track_point'      
    elif self.gpx2shpDia.radioButton_4.isChecked(): #route
      layerPath = self.gpx2shpDia.lineEdit.text() + '|layerid=1'
      layeridName='route'      
    elif self.gpx2shpDia.radioButton_5.isChecked(): #track
      layerPath = self.gpx2shpDia.lineEdit.text() + '|layerid=2'
      layeridName='track'      

    layerName =  self.gpx2shpDia.lineEdit.text()+layeridName
    self.iface.addVectorLayer(layerPath, layerName, "ogr")

    extent = self.iface.activeLayer().extent()
    self.canvas.setExtent(extent)    


    # decide crs

    if self.gpx2shpDia.comboBox.currentIndex()==1 : #twd97
      #crs = "point?crs=epsg:3826"
      crs=QgsCoordinateReferenceSystem("epsg:3826")
    if self.gpx2shpDia.comboBox.currentIndex()==0 : #wgs84
      #crs = "point?crs=epsg:4326"    
      crs=QgsCoordinateReferenceSystem("epsg:4326")
  
    _writer = QgsVectorFileWriter.writeAsVectorFormat(self.iface.activeLayer(), self.gpx2shpDia.lineEdit_2.text(), "utf-8", crs, "ESRI Shapefile")

    outfile = "輸出檔案:".decode('utf-8') + self.gpx2shpDia.lineEdit_2.text()
    QMessageBox.information(self.iface.mainWindow(), u"轉換完成", outfile )
    
    QgsMapLayerRegistry.instance().removeMapLayers( [self.iface.activeLayer().id()] )
    layer=QgsVectorLayer(self.gpx2shpDia.lineEdit_2.text() , self.gpx2shpDia.lineEdit_2.text(), "ogr")
    QgsMapLayerRegistry.instance().addMapLayers([layer])


    


  def getSHPName(self):
    shpFileName = QFileDialog.getSaveFileName(None, u"圖層另存為", self.mainDia.lineEdit.text(), "SHP files (*.shp)")
    self.csv2shpDia.lineEdit_2.clear()
    self.csv2shpDia.lineEdit_2.insert(shpFileName)
    #QMessageBox.information(self.iface.mainWindow(), "X", shpFileName)

  def csv2shp(self):
    ########################################################
    #                                                      #
    # CSV file to shapefile                                #
    #                                                      #
    # 1. read csv file                                     #
    # 2. decide coordinate                                 #
    # 3. decide point, line or polygon                     #
    #   3-1 point   : fill all attr                        #
    #   3-2 line    : fill part attr                       #    
    #   3-3 polygon : fill part attr                       #        
    #                                                      #
    ########################################################
 
    #1
    file = open(self.csv2shpDia.lineEdit.text(), 'r')
    csvCursor = csv.reader(file)
    personDF = []
    for row in csvCursor:
      personDF.append(row)


    #2
    global crs_
    global crs

    if self.csv2shpDia.comboBox.currentIndex()==0 : #twd97  
      crs_ = "Point?crs=epsg:3826"
      crs = QgsCoordinateReferenceSystem("epsg:3826")
    if self.csv2shpDia.comboBox.currentIndex()==1 : #wgs84
      crs_ = "Point?crs=epsg:4326"
      crs = QgsCoordinateReferenceSystem("epsg:4326")


    #3-1 
    if self.csv2shpDia.radioButton.isChecked():

      fileName = self.csv2shpDia.lineEdit.text() + '_points'
      layer =  QgsVectorLayer(crs_,  fileName, "memory")
      layer.setCrs(crs)
      pr = layer.dataProvider() 

      # fix first 2 field name: X, Y
      pr.addAttributes( [ QgsField(personDF[0][0], QVariant.Double),
                          QgsField(personDF[0][1], QVariant.Double) ] )

      # decide other field name
      for i in range(len(personDF[0])-2):
        res = pr.addAttributes([QgsField(personDF[0][i+2], QVariant.String)])      

      layer.updateFields()

      pt = QgsFeature()

      for i in range(len(personDF)-1): #point
        point = QgsPoint(float(personDF[i+1][0]), float(personDF[i+1][1]))
        pt.setGeometry(QgsGeometry.fromPoint(point))

        # fill all attr
        attr = []
        attr.append(str(personDF[i+1][0]))
        attr.append(str(personDF[i+1][1]))            

        for j in range(len(personDF[0])-2):
          attr.append(str(personDF[i+1][j+2]))

        pt.setAttributes(attr)

        pr.addFeatures([pt])
        # update extent of the layer
        layer.updateExtents()


      _writer = QgsVectorFileWriter.writeAsVectorFormat(layer,self.csv2shpDia.lineEdit_2.text(), "utf-8", crs, "ESRI Shapefile")

      if self.csv2shpDia.lineEdit_2.text() =='':
        outfile = "輸出至暫存記憶體".decode('utf-8')
      else:
        outfile = "輸出檔案:".decode('utf-8') + self.csv2shpDia.lineEdit_2.text()

      QMessageBox.information(self.iface.mainWindow(), u"轉換完成", outfile )
      QgsMapLayerRegistry.instance().addMapLayers([layer])


    #3-2
    elif self.csv2shpDia.radioButton_2.isChecked(): #line
      
      if self.csv2shpDia.comboBox.currentIndex()==0 : #twd97
        crs_ = "LineString?crs=epsg:3826"
        crs = QgsCoordinateReferenceSystem(3826)
      if self.csv2shpDia.comboBox.currentIndex()==1 : #wgs84
        crs_ = "LineString?crs=epsg:4326"
        crs = QgsCoordinateReferenceSystem(4326)
        
      fileName = self.csv2shpDia.lineEdit.text() + '_line'
      layer =  QgsVectorLayer(crs_,  fileName, "memory")
      layer.setCrs(crs)
      pr = layer.dataProvider() 

      # add field: Part
      pr.addAttributes( [ QgsField(personDF[0][2], QVariant.String) ] )

      # decide other field name
      #for i in range(len(personDF[0])-2):
        #res = pr.addAttributes([QgsField(personDF[0][i+2], QVariant.String)])      

      layer.updateFields()
      line = QgsFeature()

      # decide how many part
      partList = []
      for i in range(len(personDF)-1): 
        partList.append(personDF[i+1][2])

      myset = list(set(partList))

      # put different part point into pointList[][]
      pointList = []
      for i in range(len(myset)):
        pointList.append([])

        for j in range(len(personDF)-1): 
          if personDF[j+1][2] == myset[i]:
            pointList[i].append(QgsPoint(float(personDF[j+1][0]), float(personDF[j+1][1])))

      for i in range(len(myset)):
        line.setGeometry(QgsGeometry.fromPolyline(pointList[i]))
        # fill all attr
        attr = []
        attr.append(str(myset[i]))
        line.setAttributes(attr)

        pr.addFeatures([line])
        # update extent of the layer
        layer.updateExtents()


      _writer = QgsVectorFileWriter.writeAsVectorFormat(layer,self.csv2shpDia.lineEdit_2.text(),"utf-8",None,"ESRI Shapefile")

      if self.csv2shpDia.lineEdit_2.text() =='':
        outfile = "輸出至暫存記憶體".decode('utf-8')
      else:
        outfile = "輸出檔案:".decode('utf-8') + self.csv2shpDia.lineEdit_2.text()

      QMessageBox.information(self.iface.mainWindow(), u"轉換完成", outfile )
      QgsMapLayerRegistry.instance().addMapLayers([layer])




    #3-3
    elif self.csv2shpDia.radioButton_3.isChecked(): #polygon
      # decide crs
      if self.csv2shpDia.comboBox.currentIndex()==0 : #twd97
        crs_ = "Polygon?crs=epsg:3826"
        crs = QgsCoordinateReferenceSystem(3826)
      if self.csv2shpDia.comboBox.currentIndex()==1 : #wgs84
        crs_ = "Polygon?crs=epsg:4326"
        crs = QgsCoordinateReferenceSystem(4326)

      fileName = self.csv2shpDia.lineEdit.text() + '_polygon'
      layer =  QgsVectorLayer(crs_,  fileName, "memory")
      layer.setCrs(crs)
      pr = layer.dataProvider() 

      # add field: Part
      pr.addAttributes( [ QgsField(personDF[0][2], QVariant.String) ] )

      # decide other field name
      #for i in range(len(personDF[0])-2):
        #res = pr.addAttributes([QgsField(personDF[0][i+2], QVariant.String)])      

      layer.updateFields()
      polygon = QgsFeature()

      # decide how many part
      partList = []
      for i in range(len(personDF)-1): 
        partList.append(personDF[i+1][2])

      myset = list(set(partList))

      # put different part point into pointList[][]
      pointList = []
      for i in range(len(myset)):
        pointList.append([])

        for j in range(len(personDF)-1): 
          if personDF[j+1][2] == myset[i]:
            pointList[i].append(QgsPoint(float(personDF[j+1][0]), float(personDF[j+1][1])))

      for i in range(len(myset)):
        polygon.setGeometry(QgsGeometry.fromPolygon([pointList[i]]))
        # fill all attr
        attr = []
        attr.append(str(myset[i]))
        polygon.setAttributes(attr)

        pr.addFeatures([polygon])
        # update extent of the layer
        layer.updateExtents()

      _writer = QgsVectorFileWriter.writeAsVectorFormat(layer,self.csv2shpDia.lineEdit_2.text(),"utf-8",None,"ESRI Shapefile")
      
      if self.csv2shpDia.lineEdit_2.text() =='':
        outfile = "輸出至暫存記憶體".decode('utf-8')
      else:
        outfile = "輸出檔案:".decode('utf-8') + self.csv2shpDia.lineEdit_2.text()

      QMessageBox.information(self.iface.mainWindow(), u"轉換完成", outfile )
      QgsMapLayerRegistry.instance().addMapLayers([layer])


  def importWMTSList(self):
    xmlFileName = QFileDialog.getOpenFileName(None, u"請選擇XML檔案", self.mainDia.lineEdit.text(), "XML files (*.xml)")
    #QMessageBox.information(self.iface.mainWindow(), "X", xmlFileName)
    #aa="C:/Users/rchss_/Desktop/123.xml"

    manage_connections_dialog_import = QgsManageConnectionsDialog(
    mode=QgsManageConnectionsDialog.Import,
    type=QgsManageConnectionsDialog.WMS,
    fileName=xmlFileName)

    #manage_connections_dialog_import.show()
    #manage_connections_dialog_import.show()
    manage_connections_dialog_import.selectAll()
    #manage_connections_dialog_import.clearSelection()
    manage_connections_dialog_import.doExportImport()
    QMessageBox.information(self.iface.mainWindow(), "匯入完成".decode('utf-8'), "所有WMTS服務清單已匯入完畢".decode('utf-8'))

  def ComboBox_8_change(self):
  
    self.positioningDia.comboBox_9.setEnabled(True)
    self.positioningDia.comboBox_9.clear()
    
    self.positioningDia.comboBox_9.insertItem(0, '請選擇小段'.decode('utf-8'))
    self.positioningDia.comboBox_9.setCurrentIndex(0)
    
    registry = QgsMapLayerRegistry.instance()
    target_layer = registry.mapLayersByName( '國有林地籍圖'.decode('utf-8') )[0]
    self.iface.setActiveLayer(target_layer)
    
    expr = QgsExpression( " \"{}\" ='{}' ".format( '段', self.positioningDia.comboBox_8.currentText().encode('utf-8') ).decode('utf-8') )
    #QMessageBox.information(self.iface.mainWindow(),"x",  " \"{}\" ='{}' ".format( '段', self.positioningDia.comboBox_8.currentText().encode('utf-8') ).decode('utf-8'))
    it = target_layer.getFeatures( QgsFeatureRequest( expr ) )
    idx_1 = self.iface.activeLayer().fieldNameIndex('小段'.decode('utf-8'))
    
    valueList =[j.attributes()[idx_1] for j in it]
    
    it = target_layer.getFeatures( QgsFeatureRequest( expr ) )
    ids = [i.id() for i in it]

    self.iface.activeLayer().removeSelection()
    target_layer.setSelectedFeatures( ids )
    self.canvas.zoomToSelected()
    
    uniqueValue = set(valueList)
    i=0
    self.positioningDia.comboBox_9.clear()
    for v in uniqueValue:
      if v != NULL:
        self.positioningDia.comboBox_9.insertItem(i+1, v)
        i+=1
    
      
  def ComboBox_7_change(self):
  
    self.positioningDia.comboBox_8.setEnabled(True)
    self.positioningDia.comboBox_9.setEnabled(False)
    self.positioningDia.comboBox_8.clear()
    self.positioningDia.comboBox_9.clear()
    
    self.positioningDia.comboBox_8.insertItem(0, '請選擇段'.decode('utf-8'))
    self.positioningDia.comboBox_8.setCurrentIndex(0)
    
    registry = QgsMapLayerRegistry.instance()
    target_layer = registry.mapLayersByName( '國有林地籍圖'.decode('utf-8') )[0]
    self.iface.setActiveLayer(target_layer)
    
    #expr = QgsExpression( " \"{}\" ='{}' ".format( '事務所', self.positioningDia.comboBox_7.currentText().encode('utf-8') ).decode('utf-8') )
    #expr = QgsExpression( " \"{}\" ='{}' ".format( '事務所', self.positioningDia.comboBox_7.currentText().encode('utf-8') ).decode('utf-8') )
    expr = QgsExpression( " \"{}\" ='{}' AND \"{}\" ='{}' ".format('鄉鎮市', self.positioningDia.comboBox_6.currentText().encode('utf-8'), '事務所',  self.positioningDia.comboBox_7.currentText().encode('utf-8')).decode('utf-8'))
    #QMessageBox.information(self.iface.mainWindow(),"x",  " \"{}\" ='{}' ".format( '事務所', self.positioningDia.comboBox_7.currentText().encode('utf-8') ).decode('utf-8'))
    it = target_layer.getFeatures( QgsFeatureRequest( expr ) )
    idx_1 = self.iface.activeLayer().fieldNameIndex('段'.decode('utf-8'))
    
    valueList =[j.attributes()[idx_1] for j in it]
    
    it = target_layer.getFeatures( QgsFeatureRequest( expr ) )
    ids = [i.id() for i in it]

    self.iface.activeLayer().removeSelection()
    target_layer.setSelectedFeatures( ids )
    self.canvas.zoomToSelected()
        
    uniqueValue = set(valueList)
    i=0
    self.positioningDia.comboBox_8.clear()
    for v in uniqueValue:
      self.positioningDia.comboBox_8.insertItem(i+1, v)
      i+=1
    
  def queryNo(self):

    registry = QgsMapLayerRegistry.instance()
    target_layer = registry.mapLayersByName( '國有林地籍圖'.decode('utf-8') )[0]
    self.iface.setActiveLayer(target_layer)
    
    expr = QgsExpression( " \"{}\" ='{}' AND \"{}\" ='{}' ".format('段', self.positioningDia.comboBox_8.currentText().encode('utf-8'), '地號',  self.positioningDia.lineEdit.text().encode('utf-8')).decode('utf-8'))
    #QMessageBox.information(self.iface.mainWindow(),"x",  " \"{}\" ='{}' ".format( '小段', self.positioningDia.comboBox_9.currentText().encode('utf-8') ).decode('utf-8'))
    it = target_layer.getFeatures( QgsFeatureRequest( expr ) )
    
    it = target_layer.getFeatures( QgsFeatureRequest( expr ) )
    ids = [i.id() for i in it]
    
    self.iface.activeLayer().removeSelection()
    target_layer.setSelectedFeatures( ids )
    self.canvas.zoomToSelected()
      
  def ComboBox_9_change(self):
    
    registry = QgsMapLayerRegistry.instance()
    target_layer = registry.mapLayersByName( '國有林地籍圖'.decode('utf-8') )[0]
    self.iface.setActiveLayer(target_layer)
    
    expr = QgsExpression( " \"{}\" ='{}' ".format( '小段', self.positioningDia.comboBox_9.currentText().encode('utf-8') ).decode('utf-8') )
    #QMessageBox.information(self.iface.mainWindow(),"x",  " \"{}\" ='{}' ".format( '小段', self.positioningDia.comboBox_9.currentText().encode('utf-8') ).decode('utf-8'))
    it = target_layer.getFeatures( QgsFeatureRequest( expr ) )
    
    it = target_layer.getFeatures( QgsFeatureRequest( expr ) )
    ids = [i.id() for i in it]
    
    self.iface.activeLayer().removeSelection()
    target_layer.setSelectedFeatures( ids )
    self.canvas.zoomToSelected()
    
  def ComboBox_6_change(self):
  
    self.positioningDia.comboBox_7.setEnabled(True)  
    self.positioningDia.comboBox_8.setEnabled(True)
    self.positioningDia.comboBox_9.setEnabled(False)
    self.positioningDia.comboBox_7.clear()
    self.positioningDia.comboBox_8.clear()
    self.positioningDia.comboBox_9.clear()
    
    self.positioningDia.comboBox_7.insertItem(0, '請選擇事務所'.decode('utf-8'))
    self.positioningDia.comboBox_7.setCurrentIndex(0)
    
    registry = QgsMapLayerRegistry.instance()
    target_layer = registry.mapLayersByName( '國有林地籍圖'.decode('utf-8') )[0]
    self.iface.setActiveLayer(target_layer)
    
    expr = QgsExpression( " \"{}\" ='{}' ".format( '鄉鎮市', self.positioningDia.comboBox_6.currentText().encode('utf-8') ).decode('utf-8') )
    #QMessageBox.information(self.iface.mainWindow(),"x",  " \"{}\" ='{}' ".format( '鄉鎮市', self.positioningDia.comboBox_6.currentText().encode('utf-8') ).decode('utf-8'))
    it = target_layer.getFeatures( QgsFeatureRequest( expr ) )
    idx_1 = self.iface.activeLayer().fieldNameIndex('事務所'.decode('utf-8'))
    valueList =[j.attributes()[idx_1] for j in it]
    
    it = target_layer.getFeatures( QgsFeatureRequest( expr ) )
    ids = [i.id() for i in it]

    self.iface.activeLayer().removeSelection()
    target_layer.setSelectedFeatures( ids )
    self.canvas.zoomToSelected()
        
    uniqueValue = set(valueList)
    i=0
    self.positioningDia.comboBox_7.clear()
    for v in uniqueValue:
      self.positioningDia.comboBox_7.insertItem(i+1, v)
      i+=1

    self.positioningDia.comboBox_8.insertItem(0, '請選擇段'.decode('utf-8'))
    self.positioningDia.comboBox_8.setCurrentIndex(0)
    self.iface.activeLayer().removeSelection()
    expr = QgsExpression( " \"{}\" ='{}' ".format( '鄉鎮市', self.positioningDia.comboBox_6.currentText().encode('utf-8') ).decode('utf-8') )
    #QMessageBox.information(self.iface.mainWindow(),"x",  " \"{}\" ='{}' ".format( '鄉鎮市', self.positioningDia.comboBox_6.currentText().encode('utf-8') ).decode('utf-8'))
    it = target_layer.getFeatures( QgsFeatureRequest( expr ) )
    idx_1 = self.iface.activeLayer().fieldNameIndex('段'.decode('utf-8'))
    
    valueList =[j.attributes()[idx_1] for j in it]
    
    it = target_layer.getFeatures( QgsFeatureRequest( expr ) )
    ids = [i.id() for i in it]

    self.iface.activeLayer().removeSelection()
    target_layer.setSelectedFeatures( ids )
    self.canvas.zoomToSelected()
        
    uniqueValue = set(valueList)
    i=0
    self.positioningDia.comboBox_8.clear()
    for v in uniqueValue:
      self.positioningDia.comboBox_8.insertItem(i+1, v)
      i+=1      
    
      
  def ComboBox_5_change(self):
    registry = QgsMapLayerRegistry.instance()
    target_layer = registry.mapLayersByName( '國有林地籍圖'.decode('utf-8') )[0]
    self.iface.setActiveLayer(target_layer)
    
    self.positioningDia.comboBox_6.setEnabled(True)
    self.positioningDia.comboBox_7.setEnabled(False)
    self.positioningDia.comboBox_8.setEnabled(False)
    self.positioningDia.comboBox_9.setEnabled(False)
    self.positioningDia.comboBox_6.clear()
    self.positioningDia.comboBox_7.clear()
    self.positioningDia.comboBox_8.clear()
    self.positioningDia.comboBox_9.clear()
    
    self.positioningDia.comboBox_6.insertItem(0, '請選擇鄉鎮'.decode('utf-8'))
    self.positioningDia.comboBox_6.setCurrentIndex(0)
    #self.positioningDia.comboBox_6.insertItem(0, '請選擇鄉鎮市'.decode('utf-8'))
    #self.positioningDia.comboBox_6.setCurrentIndex(0)

    #QMessageBox.information(self.iface.mainWindow(),"x",  self.positioningDia.comboBox_5.currentText())
    #QMessageBox.information(self.iface.mainWindow(), "x", " \"{}\" ='{}' ".format( '111', self.positioningDia.comboBox_5.currentText().encode('utf-8') ).decode('utf-8'))
    #expr = QgsExpression( "\"%s\"=%s"%"縣市",%self.positioningDia.comboBox_5.currentText() )
    #field = 'OBJECTID'
    #field = '地號'
    #expr = QgsExpression( " \"{}\" ='{}' ".format( '地號', '17' ).decode('utf-8') )
    expr = QgsExpression( " \"{}\" ='{}' ".format( '縣市', self.positioningDia.comboBox_5.currentText().encode('utf-8') ).decode('utf-8') )
    #expr = QgsExpression( " \"{}\" ='{}' ".format( field, '209112' ).decode('ascii') )
    #                     "\"STATE\"='{}' AND \"CITY\"='{}'".format( state, city )
    it = target_layer.getFeatures( QgsFeatureRequest( expr ) )
    idx_1 = self.iface.activeLayer().fieldNameIndex('鄉鎮市'.decode('utf-8'))    
    valueList =[j.attributes()[idx_1] for j in it]

    #it = target_layer.getFeatures( QgsFeatureRequest( expr ) )    
    #idx_2 = self.iface.activeLayer().fieldNameIndex('鄉鎮市'.decode('utf-8'))
    #valueList2 =[j.attributes()[idx_2] for j in it]

    it = target_layer.getFeatures( QgsFeatureRequest( expr ) )
    ids = [i.id() for i in it]

    self.iface.activeLayer().removeSelection()
    target_layer.setSelectedFeatures( ids )
    self.canvas.zoomToSelected()
    
    uniqueValue = set(valueList)
    i=0
    self.positioningDia.comboBox_6.clear()
    for v in uniqueValue:
      self.positioningDia.comboBox_6.insertItem(i+1, v)
      i+=1

    #uniqueValue2 = set(valueList2)
    #i=0
    #for v in uniqueValue2:
      #self.positioningDia.comboBox_6.insertItem(i+1, v)
      #i+=1    
    
  def positioning_lyr(self):
    #QMessageBox.information(self.iface.mainWindow(), "X", "load")
    self.iface.mapCanvas().unsetMapTool( self.pointEmitter )
    # set positioning dia
    
    #self.positioningDia.setFixedSize(385,168)
    self.positioningDia.comboBox_19.setCurrentIndex(0)
    self.positioningDia.groupBox.hide()
    self.positioningDia.groupBox_2.hide()
    self.positioningDia.groupBox_3.hide()
    self.positioningDia.tabWidget.hide()
    #self.positioningDia.groupBox_2.setGeometry(QtCore.QRect(20, 60, 341, 101))
    self.positioningDia.setFixedSize(385,58)
    self.positioningDia.show()
    self.mainDia.pushButton_10.setEnabled(False)


  def setSourceEncode(self):
    pass
    #for layer in QgsMapLayerRegistry.instance().mapLayers().values():
      #layer.setProviderEncoding(u'UTF-8')
      #layer.dataProvider().setEncoding(u'UTF-8')
      
  def zoomTo_comboBox_18(self):
    #self.iface.activeLayer().removeSelection()
    self.positioningDia.comboBox_4.setCurrentIndex(0)
    self.positioningDia.comboBox_13.setCurrentIndex(0)
    self.positioningDia.comboBox_14.setCurrentIndex(0)
    self.positioningDia.comboBox_15.setCurrentIndex(0)
    self.positioningDia.comboBox_16.setCurrentIndex(0)
    self.positioningDia.comboBox_17.setCurrentIndex(0)
    self.positioningDia.comboBox_20.setCurrentIndex(0)
    
    legend = self.iface.legendInterface()
    layers = self.canvas.layers()
    for each_layer in layers:
      legend.setLayerVisible(each_layer, False)
    registry = QgsMapLayerRegistry.instance()

    filePath = rootPath + 'filePath.csv'
    filePathfile = open(filePath, 'r')
    csvCursor = csv.reader(filePathfile)
    filePathList = []
    for row in csvCursor:
        filePathList.append(row)
    target_layer = registry.mapLayersByName( filePathList[5][1].decode('utf-8') )[0]

    self.iface.setActiveLayer(target_layer)
    legend.setLayerVisible(target_layer, True) 

    #expr = QgsExpression( "\"OBJECTID\"=%s"%str(self.positioningDia.comboBox_18.currentIndex()) )
    #expr = QgsExpression( "\"Name\"=\'%s\'"%str(self.positioningDia.comboBox_18.currentText().encode('utf-8') ).decode('utf-8') )
    expr = QgsExpression( " \"{}\" ='{}' ".format(filePathList[5][3],self.positioningDia.comboBox_18.currentText().encode('utf-8') ).decode('utf-8') )
    #QMessageBox.information(self.iface.mainWindow(), "X", "\"Name\"=\'%s\'"%str(self.positioningDia.comboBox_18.currentText().encode('utf-8') ).decode('utf-8'))
    it = target_layer.getFeatures( QgsFeatureRequest( expr ) )
    ids = [i.id() for i in it]
    target_layer.setSelectedFeatures( ids )
    self.canvas.zoomToSelected()

  def zoomTo_comboBox_14(self):
    #self.iface.activeLayer().removeSelection()  
    self.positioningDia.comboBox_4.setCurrentIndex(0)
    self.positioningDia.comboBox_13.setCurrentIndex(0)
    self.positioningDia.comboBox_18.setCurrentIndex(0)
    self.positioningDia.comboBox_15.setCurrentIndex(0)
    self.positioningDia.comboBox_16.setCurrentIndex(0)
    self.positioningDia.comboBox_17.setCurrentIndex(0)
    self.positioningDia.comboBox_20.setCurrentIndex(0)
    
    legend = self.iface.legendInterface()
    layers = self.canvas.layers()
    for each_layer in layers:
      legend.setLayerVisible(each_layer, False)
    registry = QgsMapLayerRegistry.instance()

    filePath = rootPath + 'filePath.csv'
    filePathfile = open(filePath, 'r')
    csvCursor = csv.reader(filePathfile)
    filePathList = []
    for row in csvCursor:
        filePathList.append(row)
    target_layer = registry.mapLayersByName( filePathList[6][1].decode('utf-8') )[0]    
    #target_layer = registry.mapLayersByName( '野生動物重要棲息環境'.decode('utf-8') )[0]
    self.iface.setActiveLayer(target_layer)
    legend.setLayerVisible(target_layer, True) 
    #expr = QgsExpression( "\"OBJECTID\"=%s"%str(self.positioningDia.comboBox_14.currentIndex()) )
    #expr = QgsExpression( "\"Name\"=\'%s\'"%str(self.positioningDia.comboBox_14.currentText().encode('utf-8') ).decode('utf-8') )
    expr = QgsExpression( " \"{}\" ='{}' ".format(filePathList[6][3],self.positioningDia.comboBox_14.currentText().encode('utf-8') ).decode('utf-8') )
    it = target_layer.getFeatures( QgsFeatureRequest( expr ) )
    ids = [i.id() for i in it]
    target_layer.setSelectedFeatures( ids )
    self.canvas.zoomToSelected()

  def zoomTo_comboBox_17(self):
    #self.iface.activeLayer().removeSelection()  
    self.positioningDia.comboBox_4.setCurrentIndex(0)
    self.positioningDia.comboBox_13.setCurrentIndex(0)
    self.positioningDia.comboBox_14.setCurrentIndex(0)
    self.positioningDia.comboBox_15.setCurrentIndex(0)
    self.positioningDia.comboBox_16.setCurrentIndex(0)
    self.positioningDia.comboBox_18.setCurrentIndex(0)
    self.positioningDia.comboBox_20.setCurrentIndex(0)
    legend = self.iface.legendInterface()
    layers = self.canvas.layers()
    for each_layer in layers:
      legend.setLayerVisible(each_layer, False)
    registry = QgsMapLayerRegistry.instance()
    
    filePath = rootPath + 'filePath.csv'
    filePathfile = open(filePath, 'r')
    csvCursor = csv.reader(filePathfile)
    filePathList = []
    for row in csvCursor:
        filePathList.append(row)
    target_layer = registry.mapLayersByName( filePathList[4][1].decode('utf-8') )[0]    
    #target_layer = registry.mapLayersByName( '自然保留區'.decode('utf-8') )[0]
    self.iface.setActiveLayer(target_layer)
    legend.setLayerVisible(target_layer, True)
    #expr = QgsExpression( "\"OBJECTID\"=%s"%str(self.positioningDia.comboBox_17.currentIndex()) )
    #expr = QgsExpression( "\"Name\"=\'%s\'"%str(self.positioningDia.comboBox_17.currentText().encode('utf-8') ).decode('utf-8') )
    expr = QgsExpression( " \"{}\" ='{}' ".format(filePathList[4][3],self.positioningDia.comboBox_17.currentText().encode('utf-8') ).decode('utf-8') )
    it = target_layer.getFeatures( QgsFeatureRequest( expr ) )
    ids = [i.id() for i in it]
    target_layer.setSelectedFeatures( ids )
    self.canvas.zoomToSelected()

  def zoomTo_comboBox_16(self):
    #self.iface.activeLayer().removeSelection()  
    self.positioningDia.comboBox_4.setCurrentIndex(0)
    self.positioningDia.comboBox_13.setCurrentIndex(0)
    self.positioningDia.comboBox_14.setCurrentIndex(0)
    self.positioningDia.comboBox_15.setCurrentIndex(0)
    self.positioningDia.comboBox_17.setCurrentIndex(0)
    self.positioningDia.comboBox_18.setCurrentIndex(0)
    self.positioningDia.comboBox_20.setCurrentIndex(0)
    legend = self.iface.legendInterface()
    layers = self.canvas.layers()
    for each_layer in layers:
      legend.setLayerVisible(each_layer, False)
    registry = QgsMapLayerRegistry.instance()

    filePath = rootPath + 'filePath.csv'
    filePathfile = open(filePath, 'r')
    csvCursor = csv.reader(filePathfile)
    filePathList = []
    for row in csvCursor:
        filePathList.append(row)
    target_layer = registry.mapLayersByName( filePathList[3][1].decode('utf-8') )[0]    
    #target_layer = registry.mapLayersByName( '自然保護區'.decode('utf-8') )[0]
    self.iface.setActiveLayer(target_layer)
    legend.setLayerVisible(target_layer, True)
    #expr = QgsExpression( "\"OBJECTID\"=%s"%str(self.positioningDia.comboBox_16.currentIndex()) )
    #expr = QgsExpression( "\"Name\"=\'%s\'"%str(self.positioningDia.comboBox_16.currentText().encode('utf-8') ).decode('utf-8') )
    #aa = " \"{}\" ='{}' ".format(filePathList[3][1],self.positioningDia.comboBox_16.currentText().encode('utf-8') ).decode('utf-8')
    #QMessageBox.information(self.iface.mainWindow(),"x", aa )  
    expr = QgsExpression( " \"{}\" ='{}' ".format(filePathList[3][3],self.positioningDia.comboBox_16.currentText().encode('utf-8') ).decode('utf-8') )
    it = target_layer.getFeatures( QgsFeatureRequest( expr ) )
    ids = [i.id() for i in it]
    target_layer.setSelectedFeatures( ids )
    self.canvas.zoomToSelected()

  def zoomTo_comboBox_15(self):
    #self.iface.activeLayer().removeSelection()  
    self.positioningDia.comboBox_4.setCurrentIndex(0)
    self.positioningDia.comboBox_13.setCurrentIndex(0)
    self.positioningDia.comboBox_14.setCurrentIndex(0)
    self.positioningDia.comboBox_16.setCurrentIndex(0)
    self.positioningDia.comboBox_17.setCurrentIndex(0)
    self.positioningDia.comboBox_18.setCurrentIndex(0)
    self.positioningDia.comboBox_20.setCurrentIndex(0)
    legend = self.iface.legendInterface()
    layers = self.canvas.layers()
    for each_layer in layers:
      legend.setLayerVisible(each_layer, False)
    registry = QgsMapLayerRegistry.instance()

    filePath = rootPath + 'filePath.csv'
    filePathfile = open(filePath, 'r')
    csvCursor = csv.reader(filePathfile)
    filePathList = []
    for row in csvCursor:
        filePathList.append(row)
    target_layer = registry.mapLayersByName( filePathList[10][1].decode('utf-8') )[0]    
    #target_layer = registry.mapLayersByName( '林業文化園區'.decode('utf-8') )[0]
    self.iface.setActiveLayer(target_layer)
    legend.setLayerVisible(target_layer, True)
    #expr = QgsExpression( "\"OBJECTID\"=%s"%str(self.positioningDia.comboBox_15.currentIndex()) )
    #expr = QgsExpression( "\"Name\"=\'%s\'"%str(self.positioningDia.comboBox_15.currentText().encode('utf-8') ).decode('utf-8') )
    expr = QgsExpression( " \"{}\" ='{}' ".format(filePathList[10][3],self.positioningDia.comboBox_15.currentText().encode('utf-8') ).decode('utf-8') )
    it = target_layer.getFeatures( QgsFeatureRequest( expr ) )
    ids = [i.id() for i in it]
    target_layer.setSelectedFeatures( ids )
    self.canvas.zoomToSelected()

  def zoomTo_comboBox_13(self):
    #self.iface.activeLayer().removeSelection()  
    self.positioningDia.comboBox_4.setCurrentIndex(0)
    self.positioningDia.comboBox_14.setCurrentIndex(0)
    self.positioningDia.comboBox_15.setCurrentIndex(0)
    self.positioningDia.comboBox_16.setCurrentIndex(0)
    self.positioningDia.comboBox_17.setCurrentIndex(0)
    self.positioningDia.comboBox_18.setCurrentIndex(0)
    self.positioningDia.comboBox_20.setCurrentIndex(0)
    legend = self.iface.legendInterface()
    layers = self.canvas.layers()
    for each_layer in layers:
      legend.setLayerVisible(each_layer, False)
    registry = QgsMapLayerRegistry.instance()

    filePath = rootPath + 'filePath.csv'
    filePathfile = open(filePath, 'r')
    csvCursor = csv.reader(filePathfile)
    filePathList = []
    for row in csvCursor:
        filePathList.append(row)
    target_layer = registry.mapLayersByName( filePathList[9][1].decode('utf-8') )[0]    
    #target_layer = registry.mapLayersByName( '平地森林園區'.decode('utf-8') )[0]
    self.iface.setActiveLayer(target_layer)
    legend.setLayerVisible(target_layer, True)
    #expr = QgsExpression( "\"OBJECTID\"=%s"%str(self.positioningDia.comboBox_13.currentIndex()) )
    #expr = QgsExpression( "\"Name\"=\'%s\'"%str(self.positioningDia.comboBox_13.currentText().encode('utf-8') ).decode('utf-8') )
    expr = QgsExpression( " \"{}\" ='{}' ".format(filePathList[9][3],self.positioningDia.comboBox_13.currentText().encode('utf-8') ).decode('utf-8') )
    it = target_layer.getFeatures( QgsFeatureRequest( expr ) )
    ids = [i.id() for i in it]
    target_layer.setSelectedFeatures( ids )
    self.canvas.zoomToSelected()

  def zoomTo_comboBox_4(self):
    #self.iface.activeLayer().removeSelection()  
    self.positioningDia.comboBox_13.setCurrentIndex(0)
    self.positioningDia.comboBox_14.setCurrentIndex(0)
    self.positioningDia.comboBox_15.setCurrentIndex(0)
    self.positioningDia.comboBox_16.setCurrentIndex(0)
    self.positioningDia.comboBox_17.setCurrentIndex(0)
    self.positioningDia.comboBox_18.setCurrentIndex(0)
    self.positioningDia.comboBox_20.setCurrentIndex(0)
    legend = self.iface.legendInterface()
    layers = self.canvas.layers()
    for each_layer in layers:
      legend.setLayerVisible(each_layer, False)
    registry = QgsMapLayerRegistry.instance()

    filePath = rootPath + 'filePath.csv'
    filePathfile = open(filePath, 'r')
    csvCursor = csv.reader(filePathfile)
    filePathList = []
    for row in csvCursor:
        filePathList.append(row)
    target_layer = registry.mapLayersByName( filePathList[8][1].decode('utf-8') )[0]    
    #target_layer = registry.mapLayersByName( '森林遊樂區範圍界'.decode('utf-8') )[0]
    self.iface.setActiveLayer(target_layer)
    legend.setLayerVisible(target_layer, True)
    #expr = QgsExpression( "\"OBJECTID\"=%s"%str(self.positioningDia.comboBox_4.currentIndex()) )
    #expr = QgsExpression( "\"Name\"=\'%s\'"%str(self.positioningDia.comboBox_4.currentText().encode('utf-8') ).decode('utf-8') )    
    expr = QgsExpression( " \"{}\" ='{}' ".format(filePathList[8][3],self.positioningDia.comboBox_4.currentText().encode('utf-8') ).decode('utf-8') )
    it = target_layer.getFeatures( QgsFeatureRequest( expr ) )
    ids = [i.id() for i in it]
    target_layer.setSelectedFeatures( ids )
    self.canvas.zoomToSelected()

  def zoomTo_comboBox_20(self):
    #self.iface.activeLayer().removeSelection()  
    self.positioningDia.comboBox_4.setCurrentIndex(0)
    self.positioningDia.comboBox_13.setCurrentIndex(0)
    self.positioningDia.comboBox_14.setCurrentIndex(0)
    self.positioningDia.comboBox_15.setCurrentIndex(0)
    self.positioningDia.comboBox_16.setCurrentIndex(0)
    self.positioningDia.comboBox_17.setCurrentIndex(0)
    self.positioningDia.comboBox_18.setCurrentIndex(0)
    legend = self.iface.legendInterface()
    layers = self.canvas.layers()
    for each_layer in layers:
      legend.setLayerVisible(each_layer, False)
    registry = QgsMapLayerRegistry.instance()

    filePath = rootPath + 'filePath.csv'
    filePathfile = open(filePath, 'r')
    csvCursor = csv.reader(filePathfile)
    filePathList = []
    for row in csvCursor:
        filePathList.append(row)
    #QMessageBox.information(self.iface.mainWindow(),"x", filePathList[7][1].decode('utf-8') )        
    target_layer = registry.mapLayersByName( filePathList[7][1].decode('utf-8') )[0]    
    #target_layer = registry.mapLayersByName( '國家公園1021'.decode('utf-8') )[0]
    self.iface.setActiveLayer(target_layer)
    legend.setLayerVisible(target_layer, True)

    #expr = QgsExpression( "\"Name\"=\'%s\'"%str(self.positioningDia.comboBox_20.currentText().encode('utf-8') ).decode('utf-8') )
    expr = QgsExpression( " \"{}\" ='{}' ".format(filePathList[7][3],self.positioningDia.comboBox_20.currentText().encode('utf-8') ).decode('utf-8') )
    #QMessageBox.information(self.iface.mainWindow(),"x", "\'Name\'=\'%s\'"%str(self.positioningDia.comboBox_20.currentText().encode('utf-8') ).decode('utf-8') )
    it = target_layer.getFeatures( QgsFeatureRequest( expr ) )
    ids = [i.id() for i in it]
    target_layer.setSelectedFeatures( ids )
    self.canvas.zoomToSelected()

  def ComboBox_10_change(self):
    registry = QgsMapLayerRegistry.instance()
    #target_layer = registry.mapLayersByName( '全台保安林分布圖'.decode('utf-8') )[0]
    filePath = rootPath + 'filePath.csv'
    filePathfile = open(filePath, 'r')
    csvCursor = csv.reader(filePathfile)
    filePathList = []
    for row in csvCursor:
        filePathList.append(row)
    target_layer = registry.mapLayersByName( filePathList[2][1].decode('utf-8') )[0]    
    self.iface.setActiveLayer(target_layer)

    self.positioningDia.comboBox_11.setEnabled(True)
    self.positioningDia.comboBox_12.setEnabled(False)
    self.positioningDia.comboBox_11.clear()
    self.positioningDia.comboBox_12.clear()

    self.positioningDia.comboBox_11.insertItem(0, '請選擇段號'.decode('utf-8'))
    self.positioningDia.comboBox_11.setCurrentIndex(0)

    #expr = QgsExpression( " \"{}\" ='{}' ".format( 'PF_ID', self.positioningDia.comboBox_10.currentText().encode('utf-8') ).decode('utf-8') )
    expr = QgsExpression( " \"{}\" ='{}' ".format( filePathList[2][3].decode('utf-8'), self.positioningDia.comboBox_10.currentText().encode('utf-8') ).decode('utf-8') )
    it = target_layer.getFeatures( QgsFeatureRequest( expr ) )
    #idx_1 = self.iface.activeLayer().fieldNameIndex('C_SECT'.decode('utf-8'))
    idx_1 = self.iface.activeLayer().fieldNameIndex(filePathList[2][4].decode('utf-8'))
    valueList =[j.attributes()[idx_1] for j in it]

    it = target_layer.getFeatures( QgsFeatureRequest( expr ) )
    ids = [i.id() for i in it]

    self.iface.activeLayer().removeSelection()
    target_layer.setSelectedFeatures( ids )
    self.canvas.zoomToSelected()
    
    #uniqueValue = set(valueList)
    #i=0
    #for v in uniqueValue:
      #if v != NULL:
        #self.positioningDia.comboBox_11.insertItem(i+1, v)
        #i+=1

  def ComboBox_11_change(self):
    registry = QgsMapLayerRegistry.instance()
    #target_layer = registry.mapLayersByName( '全台保安林分布圖'.decode('utf-8') )[0]
    filePath = rootPath + 'filePath.csv'
    filePathfile = open(filePath, 'r')
    csvCursor = csv.reader(filePathfile)
    filePathList = []
    for row in csvCursor:
        filePathList.append(row)
    target_layer = registry.mapLayersByName( filePathList[2][1].decode('utf-8') )[0]    
    self.iface.setActiveLayer(target_layer)    
  
    self.positioningDia.comboBox_12.setEnabled(True)
    self.positioningDia.comboBox_12.clear()

    self.positioningDia.comboBox_12.insertItem(0, '請選擇地號-母號'.decode('utf-8'))
    self.positioningDia.comboBox_12.setCurrentIndex(0)

    expr = QgsExpression( " \"{}\" ='{}' AND \"{}\" ='{}' ".format('PF_ID', self.positioningDia.comboBox_10.currentText().encode('utf-8').decode('utf-8'), 'C_SECT',  self.positioningDia.comboBox_11.currentText().encode('utf-8').decode('utf-8')))
    it = target_layer.getFeatures( QgsFeatureRequest( expr ) )
    idx_1 = self.iface.activeLayer().fieldNameIndex('LAND_NO0'.decode('utf-8'))
    valueList =[j.attributes()[idx_1] for j in it]

    it = target_layer.getFeatures( QgsFeatureRequest( expr ) )
    ids = [i.id() for i in it]

    self.iface.activeLayer().removeSelection()
    target_layer.setSelectedFeatures( ids )
    self.canvas.zoomToSelected()

    uniqueValue = set(valueList)
    i=0
    self.positioningDia.comboBox_12.clear()
    for v in uniqueValue:
      self.positioningDia.comboBox_12.insertItem(i+1, v)
      i+=1    

  def ComboBox_12_change(self):
    registry = QgsMapLayerRegistry.instance()
    #target_layer = registry.mapLayersByName( '全台保安林分布圖'.decode('utf-8') )[0]
    filePath = rootPath + 'filePath.csv'
    filePathfile = open(filePath, 'r')
    csvCursor = csv.reader(filePathfile)
    filePathList = []
    for row in csvCursor:
        filePathList.append(row)
    target_layer = registry.mapLayersByName( filePathList[2][1].decode('utf-8') )[0]    
    self.iface.setActiveLayer(target_layer)        

    #expr = QgsExpression( " \"{}\" ='{}' ".format( 'LAND_NO0', self.positioningDia.comboBox_12.currentText().encode('utf-8') ).decode('utf-8') )
    expr = QgsExpression( " \"{}\" ='{}' AND \"{}\" ='{}' AND \"{}\" ='{}'".format('PF_ID', self.positioningDia.comboBox_10.currentText().encode('utf-8').decode('utf-8'), 'C_SECT',  self.positioningDia.comboBox_11.currentText().encode('utf-8').decode('utf-8'), 'LAND_NO0', self.positioningDia.comboBox_12.currentText().encode('utf-8').decode('utf-8'))) 
    #QMessageBox.information(self.iface.mainWindow(),"x",  " \"{}\" ='{}' ".format( '小段', self.positioningDia.comboBox_9.currentText().encode('utf-8') ).decode('utf-8'))
    #it = target_layer.getFeatures( QgsFeatureRequest( expr ) )
    
    it = target_layer.getFeatures( QgsFeatureRequest( expr ) )
    ids = [i.id() for i in it]
    
    self.iface.activeLayer().removeSelection()
    target_layer.setSelectedFeatures( ids )
    self.canvas.zoomToSelected()




  def switchPositioningDia(self):
    #QMessageBox.information(self.iface.mainWindow(), "X", self.positioningDia.comboBox_19.currentText())    
    #self.iface.activeLayer().removeSelection()
    layers = self.canvas.layers()

    self.positioningDia.comboBox_6.setEnabled(False)
    self.positioningDia.comboBox_7.setEnabled(False)
    self.positioningDia.comboBox_8.setEnabled(False)
    self.positioningDia.comboBox_9.setEnabled(False)
    self.positioningDia.comboBox_6.clear()
    self.positioningDia.comboBox_7.clear()
    self.positioningDia.comboBox_8.clear()
    self.positioningDia.comboBox_9.clear()    
    
    self.positioningDia.comboBox.setCurrentIndex(0)
    self.positioningDia.comboBox_2.setCurrentIndex(0)
    self.positioningDia.comboBox_3.setCurrentIndex(0)
    
    self.positioningDia.comboBox_5.setCurrentIndex(0)
    self.positioningDia.comboBox_6.setCurrentIndex(0)
    self.positioningDia.comboBox_7.setCurrentIndex(0)
    self.positioningDia.comboBox_8.setCurrentIndex(0)
    self.positioningDia.comboBox_9.setCurrentIndex(0)
      
    self.positioningDia.comboBox_10.setCurrentIndex(0)
    self.positioningDia.comboBox_11.setCurrentIndex(0)
    self.positioningDia.comboBox_12.setCurrentIndex(0)
    
    self.positioningDia.comboBox_4.setCurrentIndex(0)
    self.positioningDia.comboBox_13.setCurrentIndex(0)
    self.positioningDia.comboBox_14.setCurrentIndex(0)
    self.positioningDia.comboBox_15.setCurrentIndex(0)
    self.positioningDia.comboBox_16.setCurrentIndex(0)
    self.positioningDia.comboBox_17.setCurrentIndex(0)
    self.positioningDia.comboBox_18.setCurrentIndex(0)

    if self.positioningDia.comboBox_19.currentIndex()==0:
      self.positioningDia.groupBox.hide()
      self.positioningDia.groupBox_2.hide()
      self.positioningDia.groupBox_3.hide()
      self.positioningDia.tabWidget.hide()
      self.positioningDia.groupBox_2.setGeometry(QtCore.QRect(20, 60, 341, 101))
      self.positioningDia.setFixedSize(385,58)

    if self.positioningDia.comboBox_19.currentIndex()==1:
      
    # 第二輪檢訂事業區圖 comboBox

      filePath = rootPath + 'filePath.csv'
      #QMessageBox.information(self.iface.mainWindow(), "X", filePath)
      filePathfile = open(filePath, 'r')
      csvCursor = csv.reader(filePathfile)
      filePathList = []
      for row in csvCursor:
          filePathList.append(row)

      filePathName = self.mainDia.lineEdit.text() + filePathList[0][2].decode('utf-8')

      if os.path.isfile(filePathName) :
        #QMessageBox.information(self.iface.mainWindow(), "mes", filePathName)
        if len(QgsMapLayerRegistry.instance().mapLayersByName(filePathList[0][1].decode('utf-8'))) == 0:
          i=0
          self.iface.addVectorLayer(filePathName, "", "ogr")    

          #self.iface.addVectorLayer('C:/data/governed/第二輪檢訂事業區圖.shp'.decode('utf-8'), "", "ogr")
          #self.setSourceEncode()
          self.positioningDia.comboBox.clear()
          self.positioningDia.comboBox.insertItem(0, '請選擇林區'.decode('utf-8'))

          #fni = self.iface.activeLayer().fieldNameIndex('DIST_C')
          fni = self.iface.activeLayer().fieldNameIndex(filePathList[0][3])
          unique_values = self.iface.activeLayer().dataProvider().uniqueValues(fni)
          for value in unique_values:
            #attrs_1 = feat.attributes()[idx_1]
            if value != NULL:
              self.positioningDia.comboBox.insertItem(i+1, value[0]+value[1])
              i+=1
            #QMessageBox.information(self.iface.mainWindow(), "X", str(value))
          self.positioningDia.comboBox.setCurrentIndex(0)

          legend = self.iface.legendInterface()
          layers = self.canvas.layers()
          for each_layer in layers:
            legend.setLayerVisible(each_layer, False)
          registry = QgsMapLayerRegistry.instance()
          target_layer = registry.mapLayersByName( filePathList[0][1].decode('utf-8') )[0]
          self.iface.setActiveLayer(target_layer)
          legend.setLayerVisible(target_layer, True)
          extent = target_layer.extent()
          self.canvas.setExtent(extent)
      
        self.positioningDia.groupBox.show()
        self.positioningDia.groupBox_2.hide()
        self.positioningDia.groupBox_3.hide()
        self.positioningDia.tabWidget.hide()
        self.positioningDia.groupBox_2.setGeometry(QtCore.QRect(20, 60, 341, 101))
        self.positioningDia.setFixedSize(385,166)

      else:
        msg = "找不到\" ".decode('utf-8') + filePathName + " \"圖層".decode('utf-8') + "\n請確認路徑".decode('utf-8') 
        QMessageBox.information(self.iface.mainWindow(), "錯誤".decode('utf-8'), msg)        
      
    
    if self.positioningDia.comboBox_19.currentIndex()==2:
      
    # 全台保安林分布圖 comboBox_10-12

      filePath = rootPath + 'filePath.csv'
      #QMessageBox.information(self.iface.mainWindow(), "X", filePath)
      filePathfile = open(filePath, 'r')
      csvCursor = csv.reader(filePathfile)
      filePathList = []
      for row in csvCursor:
          filePathList.append(row)

      filePathName = self.mainDia.lineEdit.text() + filePathList[2][2].decode('utf-8')

      if os.path.isfile(filePathName) : 
        #QMessageBox.information(self.iface.mainWindow(), "mes", filePathName)
        if len(QgsMapLayerRegistry.instance().mapLayersByName(filePathList[2][1].decode('utf-8'))) == 0:
          i=0
          self.iface.addVectorLayer(filePathName, "", "ogr")    
        
          self.setSourceEncode()
          self.positioningDia.comboBox_10.clear()
          self.positioningDia.comboBox_10.insertItem(0, '請選擇保安林編號'.decode('utf-8'))

          fni = self.iface.activeLayer().fieldNameIndex(filePathList[2][3].decode('utf-8'))
          unique_values = self.iface.activeLayer().dataProvider().uniqueValues(fni)
          for value in unique_values:
            #attrs_1 = feat.attributes()[idx_1]
            if value != NULL:
              self.positioningDia.comboBox_10.insertItem(i+1, value)
              i+=1
            #QMessageBox.information(self.iface.mainWindow(), "X", str(value))

          self.positioningDia.comboBox_10.setCurrentIndex(0)

          legend = self.iface.legendInterface()
          layers = self.canvas.layers()
          for each_layer in layers:
            legend.setLayerVisible(each_layer, False)
          registry = QgsMapLayerRegistry.instance()
          target_layer = registry.mapLayersByName( filePathList[2][1].decode('utf-8') )[0]
          #target_layer = registry.mapLayersByName( '全台保安林分布圖'.decode('utf-8') )[0]
          self.iface.setActiveLayer(target_layer)
          legend.setLayerVisible(target_layer, True)
          extent = target_layer.extent()
          self.canvas.setExtent(extent)
      
        self.positioningDia.comboBox_11.clear()
        self.positioningDia.comboBox_12.clear()
        self.positioningDia.groupBox.hide()
        self.positioningDia.groupBox_2.hide()
        self.positioningDia.groupBox_3.show()
        self.positioningDia.tabWidget.hide()
        self.positioningDia.groupBox_3.setGeometry(QtCore.QRect(20, 60, 341, 131))
        self.positioningDia.setFixedSize(385,203)

      else:
        msg = "找不到\" ".decode('utf-8') + filePathName + " \"圖層".decode('utf-8') + "\n請確認路徑".decode('utf-8') 
        QMessageBox.information(self.iface.mainWindow(), "錯誤".decode('utf-8'), msg)        
    
    
    if self.positioningDia.comboBox_19.currentIndex()==3:
      '''
      legend = self.iface.legendInterface()
      layers = self.canvas.layers()
      for each_layer in layers:
        legend.setLayerVisible(each_layer, False)
      registry = QgsMapLayerRegistry.instance()
      target_layer = registry.mapLayersByName( '森林遊樂區範圍界'.decode('utf-8') )[0]
      self.iface.setActiveLayer(target_layer)
      legend.setLayerVisible(target_layer, True)
      extent = target_layer.extent()
      self.canvas.setExtent(extent)
      '''
      # set dialog
      self.positioningDia.groupBox.hide()
      self.positioningDia.groupBox_2.hide()
      self.positioningDia.groupBox_3.hide()
      self.positioningDia.tabWidget.show()
      self.positioningDia.tabWidget.setGeometry(QtCore.QRect(20, 60, 491, 231))
      self.positioningDia.setFixedSize(524,306)



      
  #def reconnection_loginButton(self):
    #QObject.connect(self.mainDia.pushButton_11, SIGNAL("clicked()"), self.cadastreDia.show)
  
  def reconncetion_positioningButton(self):
    self.mainDia.pushButton_10.setEnabled(True)
    
  def reconncetion(self):
    QObject.connect(self.action, SIGNAL("activated()"), self.start)

  def reconnection_2(self):
    QObject.connect(self.action, SIGNAL("activated()"), self.start)  
   

  def unload(self):
    # remove the plugin menu item and icon
    self.iface.removePluginMenu("&TFB_Tool_plugin",self.action)
    self.iface.removeToolBarIcon(self.action)
    #QMessageBox.information(self.iface.mainWindow(), "X", "123456789")    
    self.writeDefaultPath()

'''
class CopySelectedCellsAction(QtGui.QAction):
    def __init__(self, table_widget):
        if not isinstance(table_widget, QtGui.QTableWidget):
            raise ValueError(str('CopySelectedCellsAction must be initialised with a QTableWidget. A %s was given.' % type(table_widget)))
        super(CopySelectedCellsAction, self).__init__("Copy", table_widget)
        self.setShortcut('Ctrl+C')
        self.triggered.connect(self.copy_cells_to_clipboard)
        self.table_widget = table_widget

    def copy_cells_to_clipboard(self):
        if len(self.table_widget.selectionModel().selectedIndexes()) > 0:
            # sort select indexes into rows and columns
            previous = self.table_widget.selectionModel().selectedIndexes()[0]
            columns = []
            rows = []
            for index in self.table_widget.selectionModel().selectedIndexes():
                if previous.column() != index.column():
                    columns.append(rows)
                    rows = []
                rows.append(index.data())
                previous = index
            columns.append(rows)
            print columns       

            # add rows and columns to clipboard            
            clipboard = ""
            nrows = len(columns[0])
            ncols = len(columns)
            for r in xrange(nrows):
                for c in xrange(ncols):
                    clipboard += columns[c][r]
                    if c != (ncols-1):
                        clipboard += '\t'
                clipboard += '\n'

            # copy to the system clipboard
            sys_clip = QtGui.QApplication.clipboard()
            sys_clip.setText(clipboard)
    '''