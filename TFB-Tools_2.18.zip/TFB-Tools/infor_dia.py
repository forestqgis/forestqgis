# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\RCHSS_GIS\Desktop\Q_Plugins\TFB-Tools\infor_dia.ui'
#
# Created: Wed May 23 09:38:17 2018
#      by: PyQt4 UI code generator 4.10.2
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog_11(object):
    def setupUi(self, Dialog_11):
        Dialog_11.setObjectName(_fromUtf8("Dialog_11"))
        Dialog_11.setEnabled(True)
        Dialog_11.resize(500, 354)
        self.groupBox_4 = QtGui.QGroupBox(Dialog_11)
        self.groupBox_4.setEnabled(True)
        self.groupBox_4.setGeometry(QtCore.QRect(20, 130, 451, 211))
        self.groupBox_4.setObjectName(_fromUtf8("groupBox_4"))
        self.label = QtGui.QLabel(self.groupBox_4)
        self.label.setEnabled(True)
        self.label.setGeometry(QtCore.QRect(20, 20, 151, 21))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Times New Roman"))
        font.setPointSize(9)
        self.label.setFont(font)
        self.label.setObjectName(_fromUtf8("label"))
        self.pushButton = QtGui.QPushButton(self.groupBox_4)
        self.pushButton.setEnabled(True)
        self.pushButton.setGeometry(QtCore.QRect(320, 40, 51, 23))
        self.pushButton.setCheckable(True)
        self.pushButton.setChecked(False)
        self.pushButton.setObjectName(_fromUtf8("pushButton"))
        self.pushButton_2 = QtGui.QPushButton(self.groupBox_4)
        self.pushButton_2.setEnabled(False)
        self.pushButton_2.setGeometry(QtCore.QRect(380, 40, 51, 23))
        self.pushButton_2.setObjectName(_fromUtf8("pushButton_2"))
        self.pushButton_5 = QtGui.QPushButton(self.groupBox_4)
        self.pushButton_5.setEnabled(False)
        self.pushButton_5.setGeometry(QtCore.QRect(380, 100, 51, 23))
        self.pushButton_5.setObjectName(_fromUtf8("pushButton_5"))
        self.pushButton_6 = QtGui.QPushButton(self.groupBox_4)
        self.pushButton_6.setEnabled(True)
        self.pushButton_6.setGeometry(QtCore.QRect(320, 100, 51, 23))
        self.pushButton_6.setCheckable(True)
        self.pushButton_6.setChecked(False)
        self.pushButton_6.setFlat(False)
        self.pushButton_6.setObjectName(_fromUtf8("pushButton_6"))
        self.label_3 = QtGui.QLabel(self.groupBox_4)
        self.label_3.setGeometry(QtCore.QRect(20, 80, 281, 21))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Times New Roman"))
        font.setPointSize(9)
        self.label_3.setFont(font)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.lineEdit_3 = QtGui.QLineEdit(self.groupBox_4)
        self.lineEdit_3.setEnabled(False)
        self.lineEdit_3.setGeometry(QtCore.QRect(20, 100, 291, 25))
        self.lineEdit_3.setObjectName(_fromUtf8("lineEdit_3"))
        self.pushButton_7 = QtGui.QPushButton(self.groupBox_4)
        self.pushButton_7.setEnabled(False)
        self.pushButton_7.setGeometry(QtCore.QRect(380, 160, 51, 23))
        self.pushButton_7.setObjectName(_fromUtf8("pushButton_7"))
        self.pushButton_8 = QtGui.QPushButton(self.groupBox_4)
        self.pushButton_8.setEnabled(True)
        self.pushButton_8.setGeometry(QtCore.QRect(320, 160, 51, 23))
        self.pushButton_8.setCheckable(True)
        self.pushButton_8.setChecked(False)
        self.pushButton_8.setFlat(False)
        self.pushButton_8.setObjectName(_fromUtf8("pushButton_8"))
        self.label_4 = QtGui.QLabel(self.groupBox_4)
        self.label_4.setGeometry(QtCore.QRect(20, 140, 271, 21))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Times New Roman"))
        font.setPointSize(9)
        self.label_4.setFont(font)
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.lineEdit_4 = QtGui.QLineEdit(self.groupBox_4)
        self.lineEdit_4.setEnabled(False)
        self.lineEdit_4.setGeometry(QtCore.QRect(20, 160, 291, 25))
        self.lineEdit_4.setObjectName(_fromUtf8("lineEdit_4"))
        self.comboBox = QtGui.QComboBox(self.groupBox_4)
        self.comboBox.setEnabled(True)
        self.comboBox.setGeometry(QtCore.QRect(20, 40, 291, 25))
        self.comboBox.setAcceptDrops(True)
        self.comboBox.setEditable(False)
        self.comboBox.setObjectName(_fromUtf8("comboBox"))
        self.label_2 = QtGui.QLabel(Dialog_11)
        self.label_2.setEnabled(True)
        self.label_2.setGeometry(QtCore.QRect(20, 20, 451, 81))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Times New Roman"))
        font.setPointSize(9)
        font.setBold(True)
        font.setWeight(75)
        self.label_2.setFont(font)
        self.label_2.setAutoFillBackground(True)
        self.label_2.setFrameShape(QtGui.QFrame.StyledPanel)
        self.label_2.setAlignment(QtCore.Qt.AlignCenter)
        self.label_2.setObjectName(_fromUtf8("label_2"))

        self.retranslateUi(Dialog_11)
        QtCore.QMetaObject.connectSlotsByName(Dialog_11)

    def retranslateUi(self, Dialog_11):
        Dialog_11.setWindowTitle(_translate("Dialog_11", "預載資訊", None))
        self.groupBox_4.setTitle(_translate("Dialog_11", "預載資訊", None))
        self.label.setText(_translate("Dialog_11", "圖層檔案名稱：filePath.csv", None))
        self.pushButton.setText(_translate("Dialog_11", "編輯", None))
        self.pushButton_2.setText(_translate("Dialog_11", "寫入", None))
        self.pushButton_5.setText(_translate("Dialog_11", "寫入", None))
        self.pushButton_6.setText(_translate("Dialog_11", "編輯", None))
        self.label_3.setText(_translate("Dialog_11", "地政司服務Web Server主機位址：cadastreService.csv", None))
        self.pushButton_7.setText(_translate("Dialog_11", "寫入", None))
        self.pushButton_8.setText(_translate("Dialog_11", "編輯", None))
        self.label_4.setText(_translate("Dialog_11", "農航所各版次正射影像服務帳號：wmsAccount.csv", None))
        self.label_2.setText(_translate("Dialog_11", "!! 警告 !!\n"
"!! 任意修改以下資訊將可能造成程式無法運作!!\n"
"!! 修改前請確定資訊正確!!", None))

