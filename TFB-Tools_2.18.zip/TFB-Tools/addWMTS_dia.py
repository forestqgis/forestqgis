# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\RCHSS_GIS\Desktop\dataOperation_v0.96\DataOperation\addWMTS_dia.ui'
#
# Created: Tue Apr 17 09:49:15 2018
#      by: PyQt4 UI code generator 4.10.2
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog_10(object):
    def setupUi(self, Dialog_10):
        Dialog_10.setObjectName(_fromUtf8("Dialog_10"))
        Dialog_10.resize(390, 156)
        self.groupBox_2 = QtGui.QGroupBox(Dialog_10)
        self.groupBox_2.setGeometry(QtCore.QRect(10, 20, 351, 91))
        self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
        self.lineEdit_4 = QtGui.QLineEdit(self.groupBox_2)
        self.lineEdit_4.setEnabled(True)
        self.lineEdit_4.setGeometry(QtCore.QRect(70, 20, 271, 25))
        self.lineEdit_4.setInputMethodHints(QtCore.Qt.ImhNone)
        self.lineEdit_4.setText(_fromUtf8(""))
        self.lineEdit_4.setEchoMode(QtGui.QLineEdit.Normal)
        self.lineEdit_4.setObjectName(_fromUtf8("lineEdit_4"))
        self.lineEdit_5 = QtGui.QLineEdit(self.groupBox_2)
        self.lineEdit_5.setEnabled(True)
        self.lineEdit_5.setGeometry(QtCore.QRect(70, 50, 271, 25))
        self.lineEdit_5.setText(_fromUtf8(""))
        self.lineEdit_5.setEchoMode(QtGui.QLineEdit.Normal)
        self.lineEdit_5.setObjectName(_fromUtf8("lineEdit_5"))
        self.label = QtGui.QLabel(self.groupBox_2)
        self.label.setGeometry(QtCore.QRect(10, 20, 61, 21))
        font = QtGui.QFont()
        font.setPointSize(9)
        self.label.setFont(font)
        self.label.setObjectName(_fromUtf8("label"))
        self.label_2 = QtGui.QLabel(self.groupBox_2)
        self.label_2.setGeometry(QtCore.QRect(10, 50, 61, 21))
        font = QtGui.QFont()
        font.setPointSize(9)
        self.label_2.setFont(font)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.pushButton = QtGui.QPushButton(Dialog_10)
        self.pushButton.setGeometry(QtCore.QRect(110, 120, 161, 25))
        self.pushButton.setObjectName(_fromUtf8("pushButton"))

        self.retranslateUi(Dialog_10)
        QtCore.QMetaObject.connectSlotsByName(Dialog_10)

    def retranslateUi(self, Dialog_10):
        Dialog_10.setWindowTitle(_translate("Dialog_10", "新增WMTS站台", None))
        self.groupBox_2.setTitle(_translate("Dialog_10", "請輸入資訊", None))
        self.label.setText(_translate("Dialog_10", "站台名稱", None))
        self.label_2.setText(_translate("Dialog_10", "URL", None))
        self.pushButton.setText(_translate("Dialog_10", "加入", None))

