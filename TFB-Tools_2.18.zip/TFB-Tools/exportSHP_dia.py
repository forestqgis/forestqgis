# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\RCHSS_GIS\Desktop\dataOperation_v0.9�j�r��\DataOperation\exportSHP_dia.ui'
#
# Created: Wed Mar 28 22:28:54 2018
#      by: PyQt4 UI code generator 4.10.2
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog_8(object):
    def setupUi(self, Dialog_8):
        Dialog_8.setObjectName(_fromUtf8("Dialog_8"))
        Dialog_8.resize(292, 418)
        self.label_4 = QtGui.QLabel(Dialog_8)
        self.label_4.setGeometry(QtCore.QRect(20, 20, 151, 21))
        font = QtGui.QFont()
        font.setPointSize(9)
        self.label_4.setFont(font)
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.label_3 = QtGui.QLabel(Dialog_8)
        self.label_3.setGeometry(QtCore.QRect(40, 330, 91, 21))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Times New Roman"))
        font.setPointSize(9)
        self.label_3.setFont(font)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.comboBox = QtGui.QComboBox(Dialog_8)
        self.comboBox.setGeometry(QtCore.QRect(160, 330, 91, 25))
        self.comboBox.setObjectName(_fromUtf8("comboBox"))
        self.comboBox.addItem(_fromUtf8(""))
        self.comboBox.addItem(_fromUtf8(""))
        self.pushButton = QtGui.QPushButton(Dialog_8)
        self.pushButton.setGeometry(QtCore.QRect(160, 370, 91, 31))
        self.pushButton.setObjectName(_fromUtf8("pushButton"))
        self.listWidget = QtGui.QListWidget(Dialog_8)
        self.listWidget.setGeometry(QtCore.QRect(20, 50, 231, 271))
        self.listWidget.setObjectName(_fromUtf8("listWidget"))
        self.checkBox = QtGui.QCheckBox(Dialog_8)
        self.checkBox.setGeometry(QtCore.QRect(40, 370, 121, 31))
        self.checkBox.setObjectName(_fromUtf8("checkBox"))

        self.retranslateUi(Dialog_8)
        QtCore.QMetaObject.connectSlotsByName(Dialog_8)

    def retranslateUi(self, Dialog_8):
        Dialog_8.setWindowTitle(_translate("Dialog_8", "匯出shapefile", None))
        self.label_4.setText(_translate("Dialog_8", "請選擇欲輸出圖層：", None))
        self.label_3.setText(_translate("Dialog_8", "請選擇坐標系統", None))
        self.comboBox.setItemText(0, _translate("Dialog_8", "TWD 97", None))
        self.comboBox.setItemText(1, _translate("Dialog_8", "WGS 84", None))
        self.pushButton.setText(_translate("Dialog_8", "匯出", None))
        self.checkBox.setText(_translate("Dialog_8", "僅儲存選取圖徵", None))

