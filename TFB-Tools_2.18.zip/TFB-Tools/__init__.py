def name():
  return "TFB-Tools"

def description():
  return "TFB-Tools_plugins"

def version():
  return "2.150"

def qgisMinimumVersion():
  return "2.18"

def authorName():
  return "kuma"
  
def classFactory(iface):
  from DataOperation import DataOperationPlugin
  return DataOperationPlugin(iface)