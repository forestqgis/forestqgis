# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\RCHSS_GIS\Desktop\dataOperation_v0.96\DataOperation\WMTS_dia.ui'
#
# Created: Tue Apr 17 07:32:12 2018
#      by: PyQt4 UI code generator 4.10.2
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog_6(object):
    def setupUi(self, Dialog_6):
        Dialog_6.setObjectName(_fromUtf8("Dialog_6"))
        Dialog_6.resize(443, 575)
        self.groupBox_4 = QtGui.QGroupBox(Dialog_6)
        self.groupBox_4.setGeometry(QtCore.QRect(10, 20, 421, 161))
        self.groupBox_4.setObjectName(_fromUtf8("groupBox_4"))
        self.label_3 = QtGui.QLabel(self.groupBox_4)
        self.label_3.setGeometry(QtCore.QRect(10, 20, 41, 23))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Times New Roman"))
        font.setPointSize(9)
        font.setBold(False)
        font.setWeight(50)
        self.label_3.setFont(font)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.pushButton_2 = QtGui.QPushButton(self.groupBox_4)
        self.pushButton_2.setGeometry(QtCore.QRect(290, 50, 91, 28))
        self.pushButton_2.setObjectName(_fromUtf8("pushButton_2"))
        self.comboBox = QtGui.QComboBox(self.groupBox_4)
        self.comboBox.setGeometry(QtCore.QRect(50, 90, 331, 25))
        self.comboBox.setObjectName(_fromUtf8("comboBox"))
        self.pushButton_3 = QtGui.QPushButton(self.groupBox_4)
        self.pushButton_3.setGeometry(QtCore.QRect(290, 120, 91, 28))
        self.pushButton_3.setObjectName(_fromUtf8("pushButton_3"))
        self.label_4 = QtGui.QLabel(self.groupBox_4)
        self.label_4.setGeometry(QtCore.QRect(10, 90, 41, 23))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Times New Roman"))
        font.setPointSize(9)
        font.setBold(False)
        font.setWeight(50)
        self.label_4.setFont(font)
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.pushButton_7 = QtGui.QPushButton(self.groupBox_4)
        self.pushButton_7.setGeometry(QtCore.QRect(90, 50, 91, 28))
        self.pushButton_7.setObjectName(_fromUtf8("pushButton_7"))
        self.comboBox_2 = QtGui.QComboBox(self.groupBox_4)
        self.comboBox_2.setGeometry(QtCore.QRect(50, 20, 331, 25))
        self.comboBox_2.setObjectName(_fromUtf8("comboBox_2"))
        self.pushButton_8 = QtGui.QPushButton(self.groupBox_4)
        self.pushButton_8.setGeometry(QtCore.QRect(190, 50, 91, 28))
        self.pushButton_8.setObjectName(_fromUtf8("pushButton_8"))
        self.groupBox = QtGui.QGroupBox(Dialog_6)
        self.groupBox.setGeometry(QtCore.QRect(10, 190, 421, 371))
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.tableWidget_4 = QtGui.QTableWidget(self.groupBox)
        self.tableWidget_4.setGeometry(QtCore.QRect(10, 30, 401, 291))
        self.tableWidget_4.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        self.tableWidget_4.setSelectionMode(QtGui.QAbstractItemView.SingleSelection)
        self.tableWidget_4.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
        self.tableWidget_4.setObjectName(_fromUtf8("tableWidget_4"))
        self.tableWidget_4.setColumnCount(3)
        self.tableWidget_4.setRowCount(0)
        item = QtGui.QTableWidgetItem()
        self.tableWidget_4.setHorizontalHeaderItem(0, item)
        item = QtGui.QTableWidgetItem()
        self.tableWidget_4.setHorizontalHeaderItem(1, item)
        item = QtGui.QTableWidgetItem()
        self.tableWidget_4.setHorizontalHeaderItem(2, item)
        self.pushButton_4 = QtGui.QPushButton(self.groupBox)
        self.pushButton_4.setGeometry(QtCore.QRect(320, 330, 91, 31))
        self.pushButton_4.setObjectName(_fromUtf8("pushButton_4"))
        self.pushButton_6 = QtGui.QPushButton(self.groupBox)
        self.pushButton_6.setGeometry(QtCore.QRect(10, 330, 101, 31))
        self.pushButton_6.setObjectName(_fromUtf8("pushButton_6"))

        self.retranslateUi(Dialog_6)
        QtCore.QMetaObject.connectSlotsByName(Dialog_6)

    def retranslateUi(self, Dialog_6):
        Dialog_6.setWindowTitle(_translate("Dialog_6", "連結地圖服務", None))
        self.groupBox_4.setTitle(_translate("Dialog_6", "自行輸入網址", None))
        self.label_3.setText(_translate("Dialog_6", "URL", None))
        self.pushButton_2.setText(_translate("Dialog_6", "取得圖層", None))
        self.pushButton_3.setText(_translate("Dialog_6", "加入列表", None))
        self.label_4.setText(_translate("Dialog_6", "圖層", None))
        self.pushButton_7.setText(_translate("Dialog_6", "新增站台", None))
        self.pushButton_8.setText(_translate("Dialog_6", "移除站台", None))
        self.groupBox.setTitle(_translate("Dialog_6", "圖層列表", None))
        item = self.tableWidget_4.horizontalHeaderItem(0)
        item.setText(_translate("Dialog_6", "圖層", None))
        item = self.tableWidget_4.horizontalHeaderItem(1)
        item.setText(_translate("Dialog_6", "標題", None))
        item = self.tableWidget_4.horizontalHeaderItem(2)
        item.setText(_translate("Dialog_6", "url", None))
        self.pushButton_4.setText(_translate("Dialog_6", "套疊圖層", None))
        self.pushButton_6.setText(_translate("Dialog_6", "從列表移除", None))

