# -*- coding: utf-8 -*-
from PyQt4 import QtCore, QtGui
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
#from qgis.gui import QgsFileWidget
from main_dia import Ui_Dialog
from positioning_dia import Ui_Dialog_2

from csv2shp_dia import Ui_Dialog_3
from cadastre_dia import Ui_Dialog_4
from WMTS_dia import Ui_Dialog_6
from gpx2shp_dia import Ui_Dialog_7
from exportSHP_dia import Ui_Dialog_8
from wms_dia import Ui_Dialog_9
from addWMTS_dia import Ui_Dialog_10
from infor_dia import Ui_Dialog_11
from msgBox_cadastre import Ui_Dialog_12

#from main_mainWindow import Ui_MainWindow


# create the widget

#class main_mainWindowGUI(QMainWindow, Ui_MainWindow):
    #def __init__(self, iface):     
        #QDialog.__init__(self, None, Qt.WindowStaysOnTopHint)
        #QMainWindow.__init__(self)
        #self.iface = iface
        #self.setupUi(self)

class mainGUI(QDockWidget, Ui_Dialog):
    def __init__(self, iface):     
        #QDialog.__init__(self, None, Qt.WindowStaysOnTopHint)
        QDialog.__init__(self)
        self.iface = iface
        self.setupUi(self)
        self.setGeometry(0, 0, 3572, 3524)
        #self.setGeometry(0, 0, 0, 0)
        #self.iface.mainWindow().addDockWidget(Qt.RightDockWidgetArea, self)

class positioningGUI(QDialog, Ui_Dialog_2):
    def __init__(self, iface):
        #QDialog.__init__(self, None, Qt.WindowStaysOnTopHint)     
        QDialog.__init__(self)
        self.iface = iface
        self.setupUi(self) 

class csv2shpGUI(QDialog, Ui_Dialog_3):
    def __init__(self, iface):     
        #QDialog.__init__(self, None, Qt.WindowStaysOnTopHint)
        QDialog.__init__(self)
        self.iface = iface
        self.setupUi(self)       

class cadastreGUI(QDialog, Ui_Dialog_4):
    def __init__(self, iface):     
        #QDialog.__init__(self, None, Qt.WindowStaysOnTopHint)
        QDialog.__init__(self)
        self.iface = iface
        self.setupUi(self)

class WMTSGUI(QDialog, Ui_Dialog_6):
    def __init__(self, iface):     
        #QDialog.__init__(self, None, Qt.WindowStaysOnTopHint)
        QDialog.__init__(self)
        self.iface = iface
        self.setupUi(self)        

class gpx2shpGUI(QDialog, Ui_Dialog_7):
    def __init__(self, iface):     
        #QDialog.__init__(self, None, Qt.WindowStaysOnTopHint)
        QDialog.__init__(self)
        self.iface = iface
        self.setupUi(self)          

class exportSHPGUI(QDialog, Ui_Dialog_8):
    def __init__(self, iface):     
        #QDialog.__init__(self, None, Qt.WindowStaysOnTopHint)
        QDialog.__init__(self)
        self.iface = iface
        self.setupUi(self)          


class wmsGUI(QDialog, Ui_Dialog_9):
    def __init__(self, iface):     
        #QDialog.__init__(self, None, Qt.WindowStaysOnTopHint)
        QDialog.__init__(self)
        self.iface = iface
        self.setupUi(self) 

class addWMTSGUI(QDialog, Ui_Dialog_10):
    def __init__(self, iface):     
        #QDialog.__init__(self, None, Qt.WindowStaysOnTopHint)
        QDialog.__init__(self)
        self.iface = iface
        self.setupUi(self)

class inforGUI(QDialog, Ui_Dialog_11):
    def __init__(self, iface):     
        #QDialog.__init__(self, None, Qt.WindowStaysOnTopHint)
        QDialog.__init__(self)
        self.iface = iface
        self.setupUi(self)        

class msgBox_cadastreGUI(QDialog, Ui_Dialog_12):
    def __init__(self, iface):     
        #QDialog.__init__(self, None, Qt.WindowStaysOnTopHint)
        QDialog.__init__(self)
        self.iface = iface
        self.setupUi(self)    