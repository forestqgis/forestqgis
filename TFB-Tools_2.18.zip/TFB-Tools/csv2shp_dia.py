# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\RCHSS_GIS\Desktop\Q_Plugins\TFB-Tools\csv2shp_dia.ui'
#
# Created: Mon May 14 18:12:24 2018
#      by: PyQt4 UI code generator 4.10.2
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog_3(object):
    def setupUi(self, Dialog_3):
        Dialog_3.setObjectName(_fromUtf8("Dialog_3"))
        Dialog_3.resize(404, 302)
        self.pushButton = QtGui.QPushButton(Dialog_3)
        self.pushButton.setGeometry(QtCore.QRect(150, 250, 91, 35))
        self.pushButton.setObjectName(_fromUtf8("pushButton"))
        self.groupBox_4 = QtGui.QGroupBox(Dialog_3)
        self.groupBox_4.setGeometry(QtCore.QRect(20, 20, 361, 101))
        self.groupBox_4.setObjectName(_fromUtf8("groupBox_4"))
        self.toolButton = QtGui.QToolButton(self.groupBox_4)
        self.toolButton.setGeometry(QtCore.QRect(320, 20, 25, 25))
        self.toolButton.setObjectName(_fromUtf8("toolButton"))
        self.label = QtGui.QLabel(self.groupBox_4)
        self.label.setGeometry(QtCore.QRect(10, 20, 71, 21))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Times New Roman"))
        font.setPointSize(9)
        self.label.setFont(font)
        self.label.setObjectName(_fromUtf8("label"))
        self.lineEdit = QtGui.QLineEdit(self.groupBox_4)
        self.lineEdit.setEnabled(False)
        self.lineEdit.setGeometry(QtCore.QRect(90, 20, 221, 25))
        self.lineEdit.setObjectName(_fromUtf8("lineEdit"))
        self.comboBox = QtGui.QComboBox(self.groupBox_4)
        self.comboBox.setGeometry(QtCore.QRect(170, 60, 131, 25))
        self.comboBox.setObjectName(_fromUtf8("comboBox"))
        self.comboBox.addItem(_fromUtf8(""))
        self.comboBox.addItem(_fromUtf8(""))
        self.label_3 = QtGui.QLabel(self.groupBox_4)
        self.label_3.setGeometry(QtCore.QRect(10, 60, 141, 21))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Times New Roman"))
        font.setPointSize(9)
        self.label_3.setFont(font)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.groupBox_5 = QtGui.QGroupBox(Dialog_3)
        self.groupBox_5.setGeometry(QtCore.QRect(20, 140, 361, 101))
        self.groupBox_5.setObjectName(_fromUtf8("groupBox_5"))
        self.toolButton_2 = QtGui.QToolButton(self.groupBox_5)
        self.toolButton_2.setGeometry(QtCore.QRect(320, 60, 25, 25))
        self.toolButton_2.setObjectName(_fromUtf8("toolButton_2"))
        self.lineEdit_2 = QtGui.QLineEdit(self.groupBox_5)
        self.lineEdit_2.setEnabled(False)
        self.lineEdit_2.setGeometry(QtCore.QRect(90, 60, 221, 25))
        self.lineEdit_2.setObjectName(_fromUtf8("lineEdit_2"))
        self.label_2 = QtGui.QLabel(self.groupBox_5)
        self.label_2.setGeometry(QtCore.QRect(10, 60, 71, 21))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Times New Roman"))
        font.setPointSize(9)
        self.label_2.setFont(font)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.radioButton_3 = QtGui.QRadioButton(self.groupBox_5)
        self.radioButton_3.setGeometry(QtCore.QRect(210, 30, 81, 20))
        self.radioButton_3.setObjectName(_fromUtf8("radioButton_3"))
        self.radioButton_2 = QtGui.QRadioButton(self.groupBox_5)
        self.radioButton_2.setGeometry(QtCore.QRect(110, 30, 81, 20))
        self.radioButton_2.setObjectName(_fromUtf8("radioButton_2"))
        self.radioButton = QtGui.QRadioButton(self.groupBox_5)
        self.radioButton.setGeometry(QtCore.QRect(10, 30, 81, 20))
        self.radioButton.setChecked(True)
        self.radioButton.setObjectName(_fromUtf8("radioButton"))

        self.retranslateUi(Dialog_3)
        QtCore.QMetaObject.connectSlotsByName(Dialog_3)

    def retranslateUi(self, Dialog_3):
        Dialog_3.setWindowTitle(_translate("Dialog_3", "CSV to shapefile", None))
        self.pushButton.setText(_translate("Dialog_3", "開始轉換", None))
        self.groupBox_4.setTitle(_translate("Dialog_3", "輸入", None))
        self.toolButton.setText(_translate("Dialog_3", "...", None))
        self.label.setText(_translate("Dialog_3", "輸入CSV", None))
        self.comboBox.setItemText(0, _translate("Dialog_3", "TWD 97", None))
        self.comboBox.setItemText(1, _translate("Dialog_3", "WGS 84", None))
        self.label_3.setText(_translate("Dialog_3", "請選擇輸入檔案坐標系統", None))
        self.groupBox_5.setTitle(_translate("Dialog_3", "輸出", None))
        self.toolButton_2.setText(_translate("Dialog_3", "...", None))
        self.label_2.setText(_translate("Dialog_3", "輸出SHP", None))
        self.radioButton_3.setText(_translate("Dialog_3", "多邊形", None))
        self.radioButton_2.setText(_translate("Dialog_3", "線", None))
        self.radioButton.setText(_translate("Dialog_3", "點", None))

