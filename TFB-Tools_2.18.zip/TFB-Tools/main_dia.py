# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'D:\�L�ȧ�_180908\1.81\TFB-Tools_v2.20\TFB-Tools\main_dia.ui'
#
# Created: Mon Nov 05 14:28:02 2018
#      by: PyQt4 UI code generator 4.10.2
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(288, 840)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Fixed, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(Dialog.sizePolicy().hasHeightForWidth())
        Dialog.setSizePolicy(sizePolicy)
        self.groupBox = QtGui.QGroupBox(Dialog)
        self.groupBox.setGeometry(QtCore.QRect(20, 420, 231, 191))
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.pushButton = QtGui.QPushButton(self.groupBox)
        self.pushButton.setEnabled(True)
        self.pushButton.setGeometry(QtCore.QRect(20, 30, 201, 41))
        self.pushButton.setObjectName(_fromUtf8("pushButton"))
        self.pushButton_2 = QtGui.QPushButton(self.groupBox)
        self.pushButton_2.setGeometry(QtCore.QRect(20, 80, 201, 41))
        self.pushButton_2.setObjectName(_fromUtf8("pushButton_2"))
        self.pushButton_3 = QtGui.QPushButton(self.groupBox)
        self.pushButton_3.setGeometry(QtCore.QRect(20, 130, 201, 41))
        self.pushButton_3.setObjectName(_fromUtf8("pushButton_3"))
        self.groupBox_2 = QtGui.QGroupBox(Dialog)
        self.groupBox_2.setGeometry(QtCore.QRect(20, 220, 231, 191))
        self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
        self.pushButton_4 = QtGui.QPushButton(self.groupBox_2)
        self.pushButton_4.setGeometry(QtCore.QRect(50, 30, 141, 41))
        self.pushButton_4.setObjectName(_fromUtf8("pushButton_4"))
        self.pushButton_5 = QtGui.QPushButton(self.groupBox_2)
        self.pushButton_5.setGeometry(QtCore.QRect(50, 80, 141, 41))
        self.pushButton_5.setObjectName(_fromUtf8("pushButton_5"))
        self.pushButton_6 = QtGui.QPushButton(self.groupBox_2)
        self.pushButton_6.setGeometry(QtCore.QRect(50, 130, 141, 41))
        self.pushButton_6.setObjectName(_fromUtf8("pushButton_6"))
        self.groupBox_3 = QtGui.QGroupBox(Dialog)
        self.groupBox_3.setGeometry(QtCore.QRect(20, 620, 231, 131))
        self.groupBox_3.setObjectName(_fromUtf8("groupBox_3"))
        self.pushButton_7 = QtGui.QPushButton(self.groupBox_3)
        self.pushButton_7.setGeometry(QtCore.QRect(20, 30, 191, 41))
        self.pushButton_7.setObjectName(_fromUtf8("pushButton_7"))
        self.pushButton_8 = QtGui.QPushButton(self.groupBox_3)
        self.pushButton_8.setGeometry(QtCore.QRect(20, 80, 191, 41))
        self.pushButton_8.setObjectName(_fromUtf8("pushButton_8"))
        self.groupBox_4 = QtGui.QGroupBox(Dialog)
        self.groupBox_4.setGeometry(QtCore.QRect(20, 60, 231, 151))
        self.groupBox_4.setObjectName(_fromUtf8("groupBox_4"))
        self.pushButton_10 = QtGui.QPushButton(self.groupBox_4)
        self.pushButton_10.setGeometry(QtCore.QRect(50, 30, 141, 41))
        self.pushButton_10.setObjectName(_fromUtf8("pushButton_10"))
        self.pushButton_11 = QtGui.QPushButton(self.groupBox_4)
        self.pushButton_11.setGeometry(QtCore.QRect(50, 90, 141, 41))
        self.pushButton_11.setObjectName(_fromUtf8("pushButton_11"))
        self.groupBox_5 = QtGui.QGroupBox(Dialog)
        self.groupBox_5.setGeometry(QtCore.QRect(20, 760, 261, 51))
        self.groupBox_5.setObjectName(_fromUtf8("groupBox_5"))
        self.label_13 = QtGui.QLabel(self.groupBox_5)
        self.label_13.setGeometry(QtCore.QRect(10, 22, 81, 21))
        font = QtGui.QFont()
        font.setPointSize(9)
        self.label_13.setFont(font)
        self.label_13.setObjectName(_fromUtf8("label_13"))
        self.lineEdit = QtGui.QLineEdit(self.groupBox_5)
        self.lineEdit.setGeometry(QtCore.QRect(90, 20, 101, 25))
        self.lineEdit.setObjectName(_fromUtf8("lineEdit"))
        self.pushButton_9 = QtGui.QPushButton(self.groupBox_5)
        self.pushButton_9.setGeometry(QtCore.QRect(200, 20, 51, 25))
        self.pushButton_9.setObjectName(_fromUtf8("pushButton_9"))
        self.pushButton_12 = QtGui.QPushButton(Dialog)
        self.pushButton_12.setGeometry(QtCore.QRect(230, 20, 24, 24))
        self.pushButton_12.setText(_fromUtf8(""))
        self.pushButton_12.setObjectName(_fromUtf8("pushButton_12"))
        self.pushButton_13 = QtGui.QPushButton(Dialog)
        self.pushButton_13.setGeometry(QtCore.QRect(180, 810, 101, 24))
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        self.pushButton_13.setFont(font)
        self.pushButton_13.setObjectName(_fromUtf8("pushButton_13"))

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "林務局圖資操作工具v1.30", None))
        self.groupBox.setTitle(_translate("Dialog", "內部影像底圖", None))
        self.pushButton.setText(_translate("Dialog", "1/25000經建版地形圖", None))
        self.pushButton_2.setText(_translate("Dialog", "正射影像", None))
        self.pushButton_3.setText(_translate("Dialog", "農航所各版次正射影像", None))
        self.groupBox_2.setTitle(_translate("Dialog", "轉檔", None))
        self.pushButton_4.setText(_translate("Dialog", "CSV to shapefile", None))
        self.pushButton_5.setText(_translate("Dialog", "GPX to shapefile", None))
        self.pushButton_6.setText(_translate("Dialog", "匯出 shapefile", None))
        self.groupBox_3.setTitle(_translate("Dialog", "其他", None))
        self.pushButton_7.setText(_translate("Dialog", "開啓主題圖", None))
        self.pushButton_8.setText(_translate("Dialog", "外部地圖服務", None))
        self.groupBox_4.setTitle(_translate("Dialog", "定位及查詢", None))
        self.pushButton_10.setText(_translate("Dialog", "快速定位", None))
        self.pushButton_11.setText(_translate("Dialog", "地籍圖查詢", None))
        self.groupBox_5.setTitle(_translate("Dialog", "資料目錄", None))
        self.label_13.setText(_translate("Dialog", "目前資料目錄", None))
        self.lineEdit.setText(_translate("Dialog", "P:\\", None))
        self.pushButton_9.setText(_translate("Dialog", "變更", None))
        self.pushButton_13.setText(_translate("Dialog", "教學網站連結", None))

